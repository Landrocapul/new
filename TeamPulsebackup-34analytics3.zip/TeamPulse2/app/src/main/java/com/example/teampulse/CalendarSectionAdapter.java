package com.example.teampulse;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.teampulse.databinding.ListItemProjectHeaderBinding;
import com.example.teampulse.databinding.ListItemProjectSectionBinding;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class CalendarSectionAdapter extends RecyclerView.Adapter<CalendarSectionAdapter.SectionViewHolder> {

    public static final int TYPE_HEADER = 0;
    public static final int TYPE_PROJECT_SECTION = 1;

    private final List<CalendarSectionItem> sections;
    private final Context context;

    public CalendarSectionAdapter(List<CalendarSectionItem> sections, Context context) {
        this.sections = sections;
        this.context = context;
    }

    @Override
    public int getItemViewType(int position) {
        return sections.get(position).getType();
    }

    @NonNull
    @Override
    public SectionViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        if (viewType == TYPE_HEADER) {
            View view = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.list_item_project_header, parent, false);
            return new HeaderViewHolder(view);
        } else {
            View view = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.list_item_project_section, parent, false);
            return new ProjectSectionViewHolder(view);
        }
    }

    @Override
    public void onBindViewHolder(@NonNull SectionViewHolder holder, int position) {
        CalendarSectionItem section = sections.get(position);
        holder.bind(section, context);
    }

    @Override
    public int getItemCount() {
        return sections.size();
    }

    abstract static class SectionViewHolder extends RecyclerView.ViewHolder {
        public SectionViewHolder(@NonNull View itemView) {
            super(itemView);
        }
        abstract void bind(CalendarSectionItem section, Context context);
    }

    static class HeaderViewHolder extends SectionViewHolder {
        private final ListItemProjectHeaderBinding binding;

        public HeaderViewHolder(@NonNull View itemView) {
            super(itemView);
            binding = ListItemProjectHeaderBinding.bind(itemView);
        }

        @Override
        void bind(CalendarSectionItem section, Context context) {
            binding.tvProjectTitle.setText(section.getTitle());
        }
    }

    static class ProjectSectionViewHolder extends SectionViewHolder {
        private final ListItemProjectSectionBinding binding;

        public ProjectSectionViewHolder(@NonNull View itemView) {
            super(itemView);
            binding = ListItemProjectSectionBinding.bind(itemView);
        }

        @Override
        void bind(CalendarSectionItem section, Context context) {
            binding.tvProjectTitle.setText(section.getTitle());
            
            // Setup horizontal RecyclerView for tasks
            CalendarTaskItemAdapter taskAdapter = new CalendarTaskItemAdapter(section.getTasks(), context);
            LinearLayoutManager layoutManager = new LinearLayoutManager(context, LinearLayoutManager.HORIZONTAL, false);
            binding.tasksHorizontalRecycler.setLayoutManager(layoutManager);
            binding.tasksHorizontalRecycler.setAdapter(taskAdapter);
        }
    }

    public static class CalendarSectionItem {
        private final int type;
        private final String title;
        private final List<MyTasksListItem> tasks;

        public CalendarSectionItem(int type, String title, List<MyTasksListItem> tasks) {
            this.type = type;
            this.title = title;
            this.tasks = tasks != null ? tasks : new ArrayList<>();
        }

        public int getType() {
            return type;
        }

        public String getTitle() {
            return title;
        }

        public List<MyTasksListItem> getTasks() {
            return tasks;
        }
    }
}
