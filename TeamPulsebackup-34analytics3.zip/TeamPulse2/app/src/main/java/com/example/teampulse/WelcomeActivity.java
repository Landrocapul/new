package com.example.teampulse;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager2.widget.ViewPager2;

import java.util.ArrayList;
import java.util.List;

public class WelcomeActivity extends AppCompatActivity {

    private ViewPager2 viewPagerOnboarding;
    private LinearLayout dotsIndicator;
    private TextView tvSkip;
    private OnboardingAdapter onboardingAdapter;
    private List<ImageView> dots;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome);

        // Check if user has seen onboarding before
        SharedPreferences prefs = getSharedPreferences("OnboardingPrefs", MODE_PRIVATE);
        boolean isFirstTime = prefs.getBoolean("isFirstTime", true);

        if (!isFirstTime) {
            // If not first time, go directly to sign in
            navigateToSignIn();
            return;
        }

        initViews();
        setupOnboarding();
        setupPageIndicators();
        setupViewPagerListener();
    }

    private void initViews() {
        viewPagerOnboarding = findViewById(R.id.viewPagerOnboarding);
        dotsIndicator = findViewById(R.id.dotsIndicator);
        tvSkip = findViewById(R.id.tvSkip);
    }

    private void setupOnboarding() {
        // List of onboarding page layouts
        List<Integer> layouts = new ArrayList<>();
        layouts.add(R.layout.onboarding_page1);
        layouts.add(R.layout.onboarding_page2);
        layouts.add(R.layout.onboarding_page3);
        layouts.add(R.layout.onboarding_page4);

        onboardingAdapter = new OnboardingAdapter(this, layouts);
        viewPagerOnboarding.setAdapter(onboardingAdapter);
    }

    private void setupPageIndicators() {
        dots = new ArrayList<>();
        dotsIndicator.removeAllViews();

        for (int i = 0; i < 4; i++) {
            ImageView dot = new ImageView(this);
            dot.setImageResource(R.drawable.ic_dot_inactive);
            
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
            );
            params.setMargins(8, 0, 8, 0);
            dot.setLayoutParams(params);
            
            dotsIndicator.addView(dot);
            dots.add(dot);
        }

        // Set first dot as active
        dots.get(0).setImageResource(R.drawable.ic_dot_active);
    }

    private void setupViewPagerListener() {
        viewPagerOnboarding.registerOnPageChangeCallback(new ViewPager2.OnPageChangeCallback() {
            @Override
            public void onPageSelected(int position) {
                updateDots(position);
                
                // Show/hide skip button based on page
                if (position == 3) {
                    // Last page - hide skip
                    tvSkip.setVisibility(View.GONE);
                } else {
                    // Other pages - show skip
                    tvSkip.setVisibility(View.VISIBLE);
                }
            }
        });

        // Skip button click listener
        tvSkip.setOnClickListener(v -> {
            // Mark onboarding as complete and navigate to sign in
            markOnboardingComplete();
            navigateToSignIn();
        });
    }

    private void updateDots(int currentPage) {
        for (int i = 0; i < dots.size(); i++) {
            if (i == currentPage) {
                dots.get(i).setImageResource(R.drawable.ic_dot_active);
            } else {
                dots.get(i).setImageResource(R.drawable.ic_dot_inactive);
            }
        }
    }

    public void navigateToSignIn() {
        Intent intent = new Intent(WelcomeActivity.this, SignInActivity.class);
        startActivity(intent);
        finish();
    }

    public void resetOnboardingAndNavigateToSignIn() {
        // Reset onboarding preference so user can see it again
        SharedPreferences prefs = getSharedPreferences("OnboardingPrefs", MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();
        editor.putBoolean("isFirstTime", true);
        editor.apply();
        
        navigateToSignIn();
    }

    private void markOnboardingComplete() {
        SharedPreferences prefs = getSharedPreferences("OnboardingPrefs", MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();
        editor.putBoolean("isFirstTime", false);
        editor.apply();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        // Mark onboarding as complete when user exits
        markOnboardingComplete();
    }
}
