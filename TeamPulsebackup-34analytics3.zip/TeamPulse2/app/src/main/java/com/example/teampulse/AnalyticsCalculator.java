package com.example.teampulse;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class AnalyticsCalculator {
    
    public static ProjectAnalytics calculateProjectAnalytics(Project project, List<Task> tasks, List<User> users) {
        ProjectAnalytics analytics = new ProjectAnalytics(project.getId(), project.getTitle());
        
        // Initialize member contributions
        Map<String, MemberContribution> contributionMap = new HashMap<>();
        
        // Add all team members to the contribution map
        if (project.getTeamMembers() != null) {
            for (String memberId : project.getTeamMembers()) {
                String memberName = getUserNameById(users, memberId);
                contributionMap.put(memberId, new MemberContribution(memberId, memberName));
            }
        }
        
        // Add project leader if not already included
        if (project.getLeaderId() != null && !contributionMap.containsKey(project.getLeaderId())) {
            String leaderName = project.getLeaderName() != null ? project.getLeaderName() : getUserNameById(users, project.getLeaderId());
            contributionMap.put(project.getLeaderId(), new MemberContribution(project.getLeaderId(), leaderName));
        }
        
        int totalProjectPoints = 0;
        int totalTasks = 0;
        int completedTasks = 0;
        
        // Process tasks
        if (tasks != null) {
            for (Task task : tasks) {
                if (task.getProjectId().equals(project.getId())) {
                    totalTasks++;
                    totalProjectPoints += task.getPoints();
                    
                    if (task.getStatus().equals(TaskStatus.DONE.name())) {
                        completedTasks++;
                        
                        // Update assignee's contribution
                        if (task.getAssigneeUid() != null && contributionMap.containsKey(task.getAssigneeUid())) {
                            MemberContribution contribution = contributionMap.get(task.getAssigneeUid());
                            contribution.incrementCompletedTasks();
                            contribution.addPoints(task.getPoints());
                        }
                    }
                    
                    // Update total tasks for assignee
                    if (task.getAssigneeUid() != null && contributionMap.containsKey(task.getAssigneeUid())) {
                        contributionMap.get(task.getAssigneeUid()).incrementTotalTasks();
                    }
                }
            }
        }
        
        // Calculate contribution percentages
        for (MemberContribution contribution : contributionMap.values()) {
            contribution.calculateContributionPercentage(totalProjectPoints);
        }
        
        // Set analytics data
        analytics.setMemberContributions(new ArrayList<>(contributionMap.values()));
        analytics.setTotalTasks(totalTasks);
        analytics.setCompletedTasks(completedTasks);
        analytics.setTotalProjectPoints(totalProjectPoints);
        analytics.setLastUpdated(String.valueOf(System.currentTimeMillis()));
        
        return analytics;
    }
    
    private static String getUserNameById(List<User> users, String userId) {
        if (users != null) {
            for (User user : users) {
                if (user.getUid().equals(userId)) {
                    return user.getName();
                }
            }
        }
        return "Unknown User";
    }
    
    public static List<MemberContribution> getTopContributors(ProjectAnalytics analytics, int limit) {
        List<MemberContribution> contributions = new ArrayList<>(analytics.getMemberContributions());
        contributions.sort((a, b) -> Integer.compare(b.getTotalPoints(), a.getTotalPoints()));
        
        if (contributions.size() > limit) {
            return contributions.subList(0, limit);
        }
        return contributions;
    }
    
    public static double getAverageContribution(ProjectAnalytics analytics) {
        if (analytics.getMemberContributions() == null || analytics.getMemberContributions().isEmpty()) {
            return 0.0;
        }
        
        double total = 0.0;
        for (MemberContribution contribution : analytics.getMemberContributions()) {
            total += contribution.getContributionPercentage();
        }
        
        return total / analytics.getMemberContributions().size();
    }
}
