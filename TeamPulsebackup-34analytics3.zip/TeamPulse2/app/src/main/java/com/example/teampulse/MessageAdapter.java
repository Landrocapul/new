package com.example.teampulse;

import android.content.Context;
import android.content.res.Configuration;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.Toast;

import androidx.constraintlayout.widget.ConstraintLayout;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.example.teampulse.databinding.ItemMessageBinding;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class MessageAdapter extends RecyclerView.Adapter<MessageAdapter.MessageViewHolder> {

    private final List<Message> messageList;
    private final String currentUserId;
    private final MessageActionListener actionListener;

    public MessageAdapter(List<Message> messageList, String currentUserId, MessageActionListener actionListener) {
        this.messageList = messageList;
        this.currentUserId = currentUserId;
        this.actionListener = actionListener;
    }

    @NonNull
    @Override
    public MessageViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        ItemMessageBinding binding = ItemMessageBinding.inflate(
                LayoutInflater.from(parent.getContext()), parent, false);
        return new MessageViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull MessageViewHolder holder, int position) {
        Message message = messageList.get(position);
        holder.bind(message, currentUserId, actionListener);
    }

    @Override
    public int getItemCount() {
        return messageList.size();
    }

    static class MessageViewHolder extends RecyclerView.ViewHolder {
        private final ItemMessageBinding binding;
        private Context context;

        public MessageViewHolder(@NonNull ItemMessageBinding itemBinding) {
            super(itemBinding.getRoot());
            binding = itemBinding;
            context = itemBinding.getRoot().getContext();
        }

        void bind(Message message, String currentUserId, MessageActionListener actionListener) {
            // Get context from the root view
            Context context = binding.getRoot().getContext();
            
            // Set message content
            binding.tvSenderName.setText(message.getSenderName());
            
            // Handle deleted messages
            if (message.isDeleted()) {
                binding.tvMessageText.setVisibility(View.GONE);
                binding.tvDeletedMessage.setVisibility(View.VISIBLE);
                binding.tvDeletedMessage.setText("This message was deleted");

                // Set appropriate text color based on message ownership
                boolean isCurrentUser = message.getSenderId() != null &&
                        message.getSenderId().equals(currentUserId);

                if (isCurrentUser) {
                    // For current user's deleted messages
                    binding.tvDeletedMessage.setTextColor(
                            ContextCompat.getColor(context, android.R.color.white)
                    );
                } else {
                    // For other users' deleted messages
                    binding.tvDeletedMessage.setTextColor(
                            ContextCompat.getColor(context, android.R.color.darker_gray)
                    );
                }

            } else {
                binding.tvMessageText.setVisibility(View.VISIBLE);
                binding.tvDeletedMessage.setVisibility(View.GONE);
                binding.tvMessageText.setText(message.getText());
            }
            
            // Show edited indicator if message was edited
            String timestampText = formatTimestamp(message.getTimestamp());
            if (message.isEdited()) {
                timestampText += " (edited)";
            }
            binding.tvTimestamp.setText(timestampText);
            
            bindStatusIcon(message, currentUserId);
            bindReplySnippet(message);

            // Determine if message is from current user
            boolean isCurrentUser = message.getSenderId() != null && 
                                 message.getSenderId().equals(currentUserId);
            
            // Set bubble appearance and alignment
            if (isCurrentUser) {
                // Current user's message - align right with primary color
                binding.messageBubble.setBackgroundResource(R.drawable.message_bubble_sent);
                binding.tvMessageText.setTextColor(ContextCompat.getColor(context, android.R.color.white));
                binding.tvReplySnippetSender.setTextColor(ContextCompat.getColor(context, android.R.color.white));
                binding.tvReplySnippetText.setTextColor(ContextCompat.getColor(context, android.R.color.white));
                binding.tvSenderName.setVisibility(View.GONE); // Hide sender name for current user
                
                // Update constraints for right alignment
                ConstraintLayout.LayoutParams params = (ConstraintLayout.LayoutParams) binding.messageBubble.getLayoutParams();
                params.horizontalBias = 1f; // Align to right
                binding.messageBubble.setLayoutParams(params);
                
                // Set message text gravity to end for sent messages
                binding.tvMessageText.setGravity(Gravity.START);
                
                // Align status to right
                ConstraintLayout.LayoutParams statusParams = (ConstraintLayout.LayoutParams) binding.statusContainer.getLayoutParams();
                statusParams.endToEnd = ConstraintLayout.LayoutParams.PARENT_ID;
                statusParams.startToStart = ConstraintLayout.LayoutParams.UNSET;
                binding.statusContainer.setLayoutParams(statusParams);
                binding.statusContainer.setGravity(Gravity.END);
            } else {
                // Other user's message - align left with surface color
                binding.messageBubble.setBackgroundResource(R.drawable.message_bubble_received);
                
                // Set text color based on theme
                int nightModeFlags = context.getResources().getConfiguration().uiMode 
                    & Configuration.UI_MODE_NIGHT_MASK;
                if (nightModeFlags == Configuration.UI_MODE_NIGHT_YES) {
                    // Dark theme - use white text
                    binding.tvMessageText.setTextColor(ContextCompat.getColor(context, android.R.color.white));
                } else {
                    // Light theme - use black text
                    binding.tvMessageText.setTextColor(ContextCompat.getColor(context, android.R.color.black));
                }
                
                binding.tvSenderName.setVisibility(View.VISIBLE); // Show sender name for others
                
                // Update constraints for left alignment
                ConstraintLayout.LayoutParams params = (ConstraintLayout.LayoutParams) binding.messageBubble.getLayoutParams();
                params.horizontalBias = 0f; // Align to left
                binding.messageBubble.setLayoutParams(params);
                
                // Set message text gravity to start for received messages
                binding.tvMessageText.setGravity(Gravity.START);
                
                // Align status to left
                ConstraintLayout.LayoutParams statusParams = (ConstraintLayout.LayoutParams) binding.statusContainer.getLayoutParams();
                statusParams.startToStart = ConstraintLayout.LayoutParams.PARENT_ID;
                statusParams.endToEnd = ConstraintLayout.LayoutParams.UNSET;
                binding.statusContainer.setLayoutParams(statusParams);
                binding.statusContainer.setGravity(Gravity.START);
            }

            // Set long click listener for message actions
            binding.getRoot().setOnLongClickListener(v -> {
                showMessageOptions(v, message, actionListener, currentUserId);
                return true;
            });


        }

        private String formatTimestamp(long timestamp) {
            SimpleDateFormat sdf = new SimpleDateFormat("hh:mm a", Locale.getDefault());
            return sdf.format(new Date(timestamp));
        }

        private void bindStatusIcon(Message message, String currentUserId) {
            if (message.getSenderId() == null || !message.getSenderId().equals(currentUserId)) {
                binding.ivStatus.setVisibility(View.GONE);
                return;
            }

            String status = message.getStatus();
            Context context = binding.getRoot().getContext();
            if ("read".equals(status)) {
                binding.ivStatus.setVisibility(View.VISIBLE);
                binding.ivStatus.setImageResource(R.drawable.ic_msg_read);
                binding.ivStatus.setColorFilter(ContextCompat.getColor(context, R.color.blue));
            } else if ("delivered".equals(status)) {
                binding.ivStatus.setVisibility(View.VISIBLE);
                binding.ivStatus.setImageResource(R.drawable.ic_msg_delivered);
                binding.ivStatus.setColorFilter(ContextCompat.getColor(context, R.color.gray));
            } else {
                binding.ivStatus.setVisibility(View.GONE);
            }
        }

        private void showMessageOptions(View view, Message message, MessageActionListener listener, String currentUserId) {
            PopupMenu popupMenu = new PopupMenu(view.getContext(), view);
            popupMenu.getMenuInflater().inflate(R.menu.message_options_menu, popupMenu.getMenu());
            
            boolean isCurrentUser = message.getSenderId() != null && message.getSenderId().equals(currentUserId);
            boolean isDeleted = message.isDeleted();
            
            // Show reply for all non-deleted messages
            popupMenu.getMenu().findItem(R.id.menu_reply).setVisible(!isDeleted);
            
            // Only show edit/delete for current user's messages that aren't deleted
            popupMenu.getMenu().findItem(R.id.menu_edit).setVisible(isCurrentUser && !isDeleted);
            popupMenu.getMenu().findItem(R.id.menu_delete).setVisible(isCurrentUser && !isDeleted);
            
            popupMenu.setOnMenuItemClickListener(item -> {
                int id = item.getItemId();
                if (id == R.id.menu_reply) {
                    listener.onReply(message);
                    return true;
                } else if (id == R.id.menu_edit) {
                    listener.onEdit(message);
                    return true;
                } else if (id == R.id.menu_delete) {
                    listener.onDelete(message);
                    return true;
                }
                return false;
            });
            
            popupMenu.show();
        }
        
        private void bindReplySnippet(Message message) {
            if (message.getReplyToMessageId() != null) {
                binding.replySnippetContainer.setVisibility(View.VISIBLE);
                binding.tvReplySnippetSender.setText(message.getReplyToSenderName() != null ? message.getReplyToSenderName() : "Unknown");
                binding.tvReplySnippetText.setText(message.getReplyPreviewText() != null ? message.getReplyPreviewText() : "");
            } else {
                binding.replySnippetContainer.setVisibility(View.GONE);
            }
        }
    }

    public interface MessageActionListener {
        void onReply(Message message);
        void onEdit(Message message);
        void onDelete(Message message);
    }
}
