package com.example.teampulse;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class MyTasksColumnFragment extends Fragment {

    private static final String ARG_TASKS = "tasks";
    private static final String ARG_PROJECT_MAP = "project_map";

    private List<Task> taskList;
    private Map<String, String> projectIdToTitleMap;

    public static MyTasksColumnFragment newInstance(List<Task> tasks, Map<String, String> projectMap) {
        MyTasksColumnFragment fragment = new MyTasksColumnFragment();
        Bundle args = new Bundle();
        args.putSerializable(ARG_TASKS, (Serializable) tasks);
        args.putSerializable(ARG_PROJECT_MAP, (Serializable) projectMap);
        fragment.setArguments(args);
        return fragment;
    }
    @SuppressWarnings("unchecked")
    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            taskList = (List<Task>) getArguments().getSerializable(ARG_TASKS);
            projectIdToTitleMap = (Map<String, String>) getArguments().getSerializable(ARG_PROJECT_MAP);
        }
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_my_tasks_column, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        RecyclerView recyclerView = view.findViewById(R.id.my_tasks_column_recycler_view);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

        if (taskList != null && !taskList.isEmpty()) {
            List<MyTasksListItem> groupedList = buildGroupedList(taskList);
            MyTasksAdapter adapter = new MyTasksAdapter(groupedList, getContext());
            recyclerView.setAdapter(adapter);
            recyclerView.setItemAnimator(new androidx.recyclerview.widget.DefaultItemAnimator());
        }
    }

    private List<MyTasksListItem> buildGroupedList(List<Task> tasks) {
        List<MyTasksListItem> items = new ArrayList<>();
        // Group tasks by project ID
        Map<String, List<Task>> tasksByProject = tasks.stream()
                .collect(Collectors.groupingBy(Task::getProjectId));

        // Create the final list with headers
        for (String projectId : tasksByProject.keySet()) {
            String projectTitle = projectIdToTitleMap.get(projectId);
            if (projectTitle != null) {
                items.add(new ProjectHeaderItem(projectTitle)); // Add header
                tasksByProject.get(projectId).forEach(task -> items.add(new TaskItem(task))); // Add tasks
            }
        }
        return items;
    }
}