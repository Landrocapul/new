package com.example.teampulse;

public class ProjectDeadlineItem implements MyTasksListItem {
    private final Project project;

    public ProjectDeadlineItem(Project project) {
        this.project = project;
    }

    public Project getProject() {
        return project;
    }
}
