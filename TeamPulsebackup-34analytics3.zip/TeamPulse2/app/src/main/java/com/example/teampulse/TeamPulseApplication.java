package com.example.teampulse;

import android.app.Application;

public class TeamPulseApplication extends Application {

    @Override
    public void onCreate() {
        super.onCreate();

        // Initialize the ThemeHelper
        ThemeHelper themeHelper = new ThemeHelper(this);

        // Apply the saved theme as soon as the app starts
        int savedTheme = themeHelper.getSavedTheme();
        themeHelper.applyTheme(savedTheme);
    }
}