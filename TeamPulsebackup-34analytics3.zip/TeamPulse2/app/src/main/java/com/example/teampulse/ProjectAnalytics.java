package com.example.teampulse;

import java.io.Serializable;
import java.util.List;

public class ProjectAnalytics implements Serializable {
    private String projectId;
    private String projectName;
    private List<MemberContribution> memberContributions;
    private int totalTasks;
    private int completedTasks;
    private int totalProjectPoints;
    private String lastUpdated;
    
    public ProjectAnalytics() {} // Empty constructor for Firestore
    
    public ProjectAnalytics(String projectId, String projectName) {
        this.projectId = projectId;
        this.projectName = projectName;
        this.totalTasks = 0;
        this.completedTasks = 0;
        this.totalProjectPoints = 0;
    }
    
    // Getters and Setters
    public String getProjectId() { return projectId; }
    public void setProjectId(String projectId) { this.projectId = projectId; }
    
    public String getProjectName() { return projectName; }
    public void setProjectName(String projectName) { this.projectName = projectName; }
    
    public List<MemberContribution> getMemberContributions() { return memberContributions; }
    public void setMemberContributions(List<MemberContribution> memberContributions) { this.memberContributions = memberContributions; }
    
    public int getTotalTasks() { return totalTasks; }
    public void setTotalTasks(int totalTasks) { this.totalTasks = totalTasks; }
    
    public int getCompletedTasks() { return completedTasks; }
    public void setCompletedTasks(int completedTasks) { this.completedTasks = completedTasks; }
    
    public int getTotalProjectPoints() { return totalProjectPoints; }
    public void setTotalProjectPoints(int totalProjectPoints) { this.totalProjectPoints = totalProjectPoints; }
    
    public String getLastUpdated() { return lastUpdated; }
    public void setLastUpdated(String lastUpdated) { this.lastUpdated = lastUpdated; }
    
    public double getOverallProgress() {
        if (totalTasks > 0) {
            return (double) completedTasks / totalTasks * 100;
        }
        return 0.0;
    }
}
