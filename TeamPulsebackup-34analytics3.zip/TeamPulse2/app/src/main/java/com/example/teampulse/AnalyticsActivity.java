package com.example.teampulse;

import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.content.ContextCompat;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;

import java.util.ArrayList;
import java.util.List;

public class AnalyticsActivity extends AppCompatActivity {

    private FirebaseFirestore db;
    private FirebaseAuth mAuth;
    private String projectId;
    private Project currentProject;
    private ProjectAnalytics currentAnalytics;
    private LinearLayout analyticsContainer;
    private Toolbar toolbar;
    private TextView projectNameText;
    private TextView totalTasksText;
    private TextView completedTasksText;
    private TextView overallProgressText;
    private ProgressBar overallProgressBar;
    private LinearLayout membersContainer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_analytics);

        // Initialize Firebase
        db = FirebaseFirestore.getInstance();
        mAuth = FirebaseAuth.getInstance();

        // Get project ID from intent
        projectId = getIntent().getStringExtra("PROJECT_ID");
        if (projectId == null) {
            Toast.makeText(this, "Error: Project ID not found", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        initializeViews();
        loadProjectData();
    }

    private void initializeViews() {
        toolbar = findViewById(R.id.toolbar);
        analyticsContainer = findViewById(R.id.analytics_container);
        projectNameText = findViewById(R.id.project_name_text);
        totalTasksText = findViewById(R.id.total_tasks_text);
        completedTasksText = findViewById(R.id.completed_tasks_text);
        overallProgressText = findViewById(R.id.overall_progress_text);
        overallProgressBar = findViewById(R.id.overall_progress_bar);
        membersContainer = findViewById(R.id.members_container);
        
        setupToolbar();
    }

    private void setupToolbar() {
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
            getSupportActionBar().setTitle("Project Analytics");
        }
        
        toolbar.setNavigationOnClickListener(v -> finish());
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void loadProjectData() {
        // Load project details
        db.collection("projects").document(projectId).get()
                .addOnSuccessListener(documentSnapshot -> {
                    currentProject = documentSnapshot.toObject(Project.class);
                    if (currentProject != null) {
                        projectNameText.setText(currentProject.getTitle());
                        loadTasksAndUsers();
                    }
                })
                .addOnFailureListener(e -> {
                    Toast.makeText(this, "Error loading project", Toast.LENGTH_SHORT).show();
                    finish();
                });
    }

    private void loadTasksAndUsers() {
        // Load tasks and users in parallel
        db.collection("projects").document(projectId).collection("tasks").get()
                .addOnSuccessListener(taskSnapshot -> {
                    List<Task> tasks = new ArrayList<>();
                    for (QueryDocumentSnapshot doc : taskSnapshot) {
                        Task task = doc.toObject(Task.class);
                        task.setId(doc.getId());
                        tasks.add(task);
                    }
                    
                    // Load users
                    db.collection("users").get()
                            .addOnSuccessListener(userSnapshot -> {
                                List<User> users = new ArrayList<>();
                                for (QueryDocumentSnapshot doc : userSnapshot) {
                                    User user = doc.toObject(User.class);
                                    users.add(user);
                                }
                                
                                // Calculate analytics
                                currentAnalytics = AnalyticsCalculator.calculateProjectAnalytics(currentProject, tasks, users);
                                displayAnalytics();
                            })
                            .addOnFailureListener(e -> {
                                Toast.makeText(this, "Error loading users", Toast.LENGTH_SHORT).show();
                            });
                })
                .addOnFailureListener(e -> {
                    Toast.makeText(this, "Error loading tasks", Toast.LENGTH_SHORT).show();
                });
    }

    private void displayAnalytics() {
        if (currentAnalytics == null) return;

        // Display project overview
        totalTasksText.setText(String.valueOf(currentAnalytics.getTotalTasks()));
        completedTasksText.setText(String.valueOf(currentAnalytics.getCompletedTasks()));
        overallProgressText.setText(String.format("%.1f%%", currentAnalytics.getOverallProgress()));
        
        // Update progress bar
        overallProgressBar.setProgress((int) currentAnalytics.getOverallProgress());

        // Display member contributions
        displayMemberContributions();
    }

    private void displayMemberContributions() {
        membersContainer.removeAllViews();

        if (currentAnalytics.getMemberContributions() == null) return;

        // Sort members by contribution percentage
        List<MemberContribution> contributions = new ArrayList<>(currentAnalytics.getMemberContributions());
        contributions.sort((a, b) -> Double.compare(b.getContributionPercentage(), a.getContributionPercentage()));

        for (MemberContribution contribution : contributions) {
            View memberView = createMemberContributionView(contribution);
            membersContainer.addView(memberView);
        }
    }

    private View createMemberContributionView(MemberContribution contribution) {
        com.google.android.material.card.MaterialCardView cardView = new com.google.android.material.card.MaterialCardView(this);
        LinearLayout.LayoutParams cardParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        );
        cardParams.setMargins(0, 0, 0, 16);
        cardView.setLayoutParams(cardParams);
        
        // Use theme-aware colors and proper MaterialCardView styling
        cardView.setCardBackgroundColor(ContextCompat.getColor(this, isDarkMode() ? R.color.dark_card : android.R.color.white));
        cardView.setCardElevation(4);
        cardView.setUseCompatPadding(true);

        // Main content layout
        LinearLayout mainLayout = new LinearLayout(this);
        mainLayout.setOrientation(LinearLayout.VERTICAL);
        mainLayout.setPadding(30, 30, 30, 30);

        // Header with name and rank badge
        LinearLayout headerLayout = new LinearLayout(this);
        headerLayout.setOrientation(LinearLayout.HORIZONTAL);
        headerLayout.setGravity(android.view.Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams headerParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        );
        headerLayout.setLayoutParams(headerParams);

        // Member name
        TextView nameText = new TextView(this);
        nameText.setText(contribution.getMemberName());
        nameText.setTextSize(16);
        nameText.setTypeface(null, android.graphics.Typeface.BOLD);
        nameText.setTextColor(ContextCompat.getColor(this, isDarkMode() ? R.color.dark_text_primary : android.R.color.black));
        LinearLayout.LayoutParams nameParams = new LinearLayout.LayoutParams(
                0,
                LinearLayout.LayoutParams.WRAP_CONTENT,
                1.0f
        );
        nameText.setLayoutParams(nameParams);

        // Rank badge
        TextView rankBadge = new TextView(this);
        int rank = getMemberRank(contribution);
        String rankText = "#" + rank;
        rankBadge.setText(rankText);
        rankBadge.setTextSize(12);
        rankBadge.setTypeface(null, android.graphics.Typeface.BOLD);
        rankBadge.setTextColor(getResources().getColor(android.R.color.white));
        rankBadge.setPadding(12, 4, 12, 4);
        
        // Set rank badge color
        if (rank == 1) {
            rankBadge.setBackgroundColor(getResources().getColor(android.R.color.holo_orange_dark));
        } else if (rank == 2) {
            rankBadge.setBackgroundColor(getResources().getColor(android.R.color.darker_gray));
        } else if (rank == 3) {
            rankBadge.setBackgroundColor(getResources().getColor(android.R.color.holo_orange_light));
        } else {
            rankBadge.setBackgroundColor(getResources().getColor(android.R.color.darker_gray));
        }

        headerLayout.addView(nameText);
        headerLayout.addView(rankBadge);

        // Stats row
        LinearLayout statsLayout = new LinearLayout(this);
        statsLayout.setOrientation(LinearLayout.HORIZONTAL);
        statsLayout.setGravity(android.view.Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams statsParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        );
        statsParams.setMargins(0, 12, 0, 12);
        statsLayout.setLayoutParams(statsParams);

        // Tasks completed
        TextView tasksText = new TextView(this);
        String tasksInfo = contribution.getCompletedTasks() + "/" + contribution.getTotalTasks() + " tasks";
        tasksText.setText(tasksInfo);
        tasksText.setTextSize(14);
        tasksText.setTextColor(ContextCompat.getColor(this, isDarkMode() ? R.color.dark_text_secondary : android.R.color.darker_gray));
        LinearLayout.LayoutParams tasksParams = new LinearLayout.LayoutParams(
                0,
                LinearLayout.LayoutParams.WRAP_CONTENT,
                1.0f
        );
        tasksText.setLayoutParams(tasksParams);

        // Points
        TextView pointsText = new TextView(this);
        String pointsInfo = contribution.getTotalPoints() + " pts";
        pointsText.setText(pointsInfo);
        pointsText.setTextSize(14);
        pointsText.setTextColor(ContextCompat.getColor(this, isDarkMode() ? R.color.dark_text_secondary : android.R.color.darker_gray));
        LinearLayout.LayoutParams pointsParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        );
        pointsText.setLayoutParams(pointsParams);

        // Contribution percentage
        TextView percentageText = new TextView(this);
        String percentageInfo = String.format("%.1f%%", contribution.getContributionPercentage());
        percentageText.setText(percentageInfo);
        percentageText.setTextSize(14);
        percentageText.setTypeface(null, android.graphics.Typeface.BOLD);
        percentageText.setTextColor(getResources().getColor(R.color.primary_color));
        LinearLayout.LayoutParams percentageParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        );
        percentageParams.setMargins(16, 0, 0, 0);
        percentageText.setLayoutParams(percentageParams);

        statsLayout.addView(tasksText);
        statsLayout.addView(pointsText);
        statsLayout.addView(percentageText);

        // Progress bar
        LinearLayout progressContainer = new LinearLayout(this);
        progressContainer.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams progressContainerParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                8
        );
        progressContainerParams.setMargins(0, 8, 0, 0);
        progressContainer.setLayoutParams(progressContainerParams);

        // Background progress bar
        View backgroundProgress = new View(this);
        LinearLayout.LayoutParams bgParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.MATCH_PARENT
        );
        backgroundProgress.setLayoutParams(bgParams);
        backgroundProgress.setBackgroundColor(ContextCompat.getColor(this, isDarkMode() ? R.color.dark_border : android.R.color.darker_gray));

        // Foreground progress bar
        View foregroundProgress = new View(this);
        int progressWidth = (int) (contribution.getContributionPercentage() / 100.0 * bgParams.width);
        LinearLayout.LayoutParams fgParams = new LinearLayout.LayoutParams(
                progressWidth,
                LinearLayout.LayoutParams.MATCH_PARENT
        );
        foregroundProgress.setLayoutParams(fgParams);
        foregroundProgress.setBackgroundColor(getResources().getColor(R.color.primary_color));

        progressContainer.addView(backgroundProgress);
        progressContainer.addView(foregroundProgress);

        mainLayout.addView(headerLayout);
        mainLayout.addView(statsLayout);
        mainLayout.addView(progressContainer);

        cardView.addView(mainLayout);
        return cardView;
    }

    private int getMemberRank(MemberContribution contribution) {
        if (currentAnalytics == null || currentAnalytics.getMemberContributions() == null) return 0;
        
        List<MemberContribution> contributions = new ArrayList<>(currentAnalytics.getMemberContributions());
        contributions.sort((a, b) -> Integer.compare(b.getTotalPoints(), a.getTotalPoints()));
        
        for (int i = 0; i < contributions.size(); i++) {
            if (contributions.get(i).getMemberId().equals(contribution.getMemberId())) {
                return i + 1;
            }
        }
        return 0;
    }

    private boolean isDarkMode() {
        int nightModeFlags = getResources().getConfiguration().uiMode & android.content.res.Configuration.UI_MODE_NIGHT_MASK;
        return nightModeFlags == android.content.res.Configuration.UI_MODE_NIGHT_YES;
    }
}
