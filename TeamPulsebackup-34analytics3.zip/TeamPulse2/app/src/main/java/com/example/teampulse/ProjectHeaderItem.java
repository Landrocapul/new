package com.example.teampulse;

public class ProjectHeaderItem implements MyTasksListItem {
    private final String projectTitle;

    public ProjectHeaderItem(String projectTitle) {
        this.projectTitle = projectTitle;
    }

    public String getProjectTitle() {
        return projectTitle;
    }
}