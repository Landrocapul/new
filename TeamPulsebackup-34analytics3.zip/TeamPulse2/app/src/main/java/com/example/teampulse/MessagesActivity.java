package com.example.teampulse;

import android.content.Context;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.os.Bundle;
import android.text.InputType;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;
import android.widget.ProgressBar;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.example.teampulse.databinding.ActivityMessagesBinding;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.ListenerRegistration;
import com.google.firebase.firestore.QueryDocumentSnapshot;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MessagesActivity extends AppCompatActivity {

    private ActivityMessagesBinding binding;
    private FirebaseFirestore db;
    private FirebaseAuth mAuth;
    private String currentUserId;
    private String currentUserRole = ""; // Add role tracking

    private List<MessageChatItem> chatList = new ArrayList<>();
    private MessageChatAdapter adapter;
    private ListenerRegistration projectsListener;
    private CustomBottomNavController navController;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMessagesBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        mAuth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();

        FirebaseUser currentUser = mAuth.getCurrentUser();
        if (currentUser == null) {
            finish();
            return;
        }
        currentUserId = currentUser.getUid();

        setupToolbar();
        setupRecyclerView();
        setupSwipeRefreshLayout();
        loadUserRole(); // Load user role before setting up navigation
        loadUserChats();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.messages_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.action_join_project) {
            showJoinProjectDialog();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void setupToolbar() {
        setSupportActionBar(binding.toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle("Messages");
            // Set message icon instead of back button
            getSupportActionBar().setDisplayHomeAsUpEnabled(false);
            binding.toolbar.setNavigationIcon(R.drawable.ic_message);
            binding.toolbar.setNavigationOnClickListener(v -> {
                // Optional: Add action if message icon is clicked
                // For now, it's just decorative
            });
        }
    }

    private void setupRecyclerView() {
        adapter = new MessageChatAdapter(chatList, this::onChatClicked);
        binding.rvChats.setLayoutManager(new LinearLayoutManager(this));
        binding.rvChats.setAdapter(adapter);
    }

    private void setupSwipeRefreshLayout() {
        // Set the colors for the refresh indicator
        binding.swipeRefreshLayout.setColorSchemeColors(
                ContextCompat.getColor(this, R.color.text_primary),
                ContextCompat.getColor(this, R.color.text_secondary)
        );
        
        // Set the refresh listener
        binding.swipeRefreshLayout.setOnRefreshListener(() -> {
            Log.d("MessagesActivity", "Pull to refresh triggered");
            loadUserChats();
        });
    }

    private void loadUserChats() {
        // Only show progress bar for initial load, not for refresh
        if (projectsListener == null) {
            binding.progressBar.setVisibility(View.VISIBLE);
        }
        binding.tvNoMessages.setVisibility(View.GONE);
        
        Log.d("MessagesActivity", "Loading chats for user: " + currentUserId);

        projectsListener = db.collection("projects")
                .addSnapshotListener((queryDocumentSnapshots, e) -> {
                    // Stop refresh animation
                    binding.swipeRefreshLayout.setRefreshing(false);
                    
                    if (e != null) {
                        Log.e("MessagesActivity", "Failed to load chats", e);
                        Toast.makeText(this, "Failed to load chats", Toast.LENGTH_SHORT).show();
                        binding.progressBar.setVisibility(View.GONE);
                        return;
                    }

                    chatList.clear();
                    
                    Log.d("MessagesActivity", "Projects snapshot size: " + 
                          (queryDocumentSnapshots != null ? queryDocumentSnapshots.size() : 0));
                    
                    if (queryDocumentSnapshots == null || queryDocumentSnapshots.isEmpty()) {
                        Log.d("MessagesActivity", "No projects found");
                        binding.progressBar.setVisibility(View.GONE);
                        binding.tvNoMessages.setVisibility(View.VISIBLE);
                        adapter.notifyDataSetChanged();
                        return;
                    }

                    for (QueryDocumentSnapshot doc : queryDocumentSnapshots) {
                        String projectId = doc.getId();
                        String projectName = doc.getString("title");
                        String leaderId = doc.getString("leaderId");
                        String teacherId = doc.getString("teacherId");
                        List<String> teamMembers = (List<String>) doc.get("teamMembers");

                        Log.d("MessagesActivity", "Project: " + projectName + 
                              ", Leader: " + leaderId + 
                              ", Teacher: " + teacherId + 
                              ", Team: " + teamMembers + 
                              ", Current User: " + currentUserId);

                        boolean isUserInProject = (leaderId != null && leaderId.equals(currentUserId)) ||
                                (teacherId != null && teacherId.equals(currentUserId)) ||
                                (teamMembers != null && teamMembers.contains(currentUserId));

                        Log.d("MessagesActivity", "Is user in project " + projectName + ": " + isUserInProject);

                        if (isUserInProject) {
                            MessageChatItem chatItem = new MessageChatItem();
                            chatItem.setProjectId(projectId);
                            chatItem.setProjectName(projectName != null ? projectName : "Unknown Project");
                            chatItem.setLeaderId(leaderId);
                            chatItem.setTeamMembers(teamMembers);
                            
                            chatList.add(chatItem);
                            Log.d("MessagesActivity", "Added project to chat list: " + projectName);
                            
                            // Load last message for this project
                            loadLastMessage(chatItem);
                        }
                    }

                    Log.d("MessagesActivity", "Final chat list size: " + chatList.size());
                    binding.progressBar.setVisibility(View.GONE);
                    if (chatList.isEmpty()) {
                        binding.tvNoMessages.setVisibility(View.VISIBLE);
                    } else {
                        binding.tvNoMessages.setVisibility(View.GONE);
                    }
                    adapter.notifyDataSetChanged();
                });
    }

    private void loadLastMessage(MessageChatItem chatItem) {
        Log.d("MessagesActivity", "Loading last message for project: " + chatItem.getProjectName());
        
        db.collection("projects").document(chatItem.getProjectId())
                .collection("messages")
                .orderBy("timestamp", com.google.firebase.firestore.Query.Direction.DESCENDING)
                .limit(1)
                .get()
                .addOnSuccessListener(messageSnapshots -> {
                    Log.d("MessagesActivity", "Message snapshots size for " + chatItem.getProjectName() + ": " + messageSnapshots.size());
                    
                    if (!messageSnapshots.isEmpty()) {
                        DocumentSnapshot messageDoc = messageSnapshots.getDocuments().get(0);
                        Message lastMessage = messageDoc.toObject(Message.class);
                        if (lastMessage != null) {
                            chatItem.setLastMessage(lastMessage.getText());
                            chatItem.setLastMessageTime(lastMessage.getTimestamp());
                            chatItem.setLastMessageSender(lastMessage.getSenderName());
                            
                            Log.d("MessagesActivity", "Last message loaded for " + chatItem.getProjectName() + 
                                  ": " + lastMessage.getText());
                            
                            // Check for unread messages
                            checkUnreadMessages(chatItem);
                        }
                    } else {
                        chatItem.setLastMessage("No messages yet");
                        chatItem.setLastMessageTime(0L);
                        chatItem.setLastMessageSender("");
                        chatItem.setUnreadCount(0);
                        
                        Log.d("MessagesActivity", "No messages found for project: " + chatItem.getProjectName());
                    }
                    
                    // Update adapter if this item exists in the list
                    int position = chatList.indexOf(chatItem);
                    if (position != -1) {
                        adapter.notifyItemChanged(position);
                    }
                })
                .addOnFailureListener(e -> {
                    Log.e("MessagesActivity", "Failed to load last message for " + chatItem.getProjectName(), e);
                    chatItem.setLastMessage("Failed to load message");
                    chatItem.setLastMessageTime(0L);
                    chatItem.setLastMessageSender("");
                    chatItem.setUnreadCount(0);
                });
    }

    private void checkUnreadMessages(MessageChatItem chatItem) {
        Log.d("MessagesActivity", "=== Checking unread messages for project: " + chatItem.getProjectName() + " ===");
        Log.d("MessagesActivity", "Current user ID: " + currentUserId);
        
        db.collection("projects").document(chatItem.getProjectId())
                .collection("messages")
                .get()
                .addOnSuccessListener(messageSnapshots -> {
                    int unreadCount = 0;
                    Log.d("MessagesActivity", "Found " + messageSnapshots.size() + " total messages");
                    
                    for (DocumentSnapshot doc : messageSnapshots) {
                        Message message = doc.toObject(Message.class);
                        if (message != null) {
                            Log.d("MessagesActivity", "--- Message Analysis ---");
                            Log.d("MessagesActivity", "Sender: " + message.getSenderId());
                            Log.d("MessagesActivity", "Current User: " + currentUserId);
                            Log.d("MessagesActivity", "Status: " + message.getStatus());
                            Log.d("MessagesActivity", "ReadBy: " + message.getReadBy());
                            
                            boolean isFromOtherUser = !message.getSenderId().equals(currentUserId);
                            boolean isNotReadByUser = message.getReadBy() == null || !message.getReadBy().contains(currentUserId);
                            
                            Log.d("MessagesActivity", "Is from other user: " + isFromOtherUser);
                            Log.d("MessagesActivity", "Is not read by user: " + isNotReadByUser);
                            Log.d("MessagesActivity", "Should count as unread: " + (isFromOtherUser && isNotReadByUser));
                            
                            if (isFromOtherUser && isNotReadByUser) {
                                unreadCount++;
                                Log.d("MessagesActivity", "🔔 UNREAD MESSAGE FOUND! Total: " + unreadCount);
                            }
                        }
                    }
                    
                    chatItem.setUnreadCount(unreadCount);
                    Log.d("MessagesActivity", "=== FINAL UNREAD COUNT for " + chatItem.getProjectName() + ": " + unreadCount + " ===");
                    
                    // Update adapter if this item exists in the list
                    int position = chatList.indexOf(chatItem);
                    if (position != -1) {
                        Log.d("MessagesActivity", "Updating adapter at position: " + position);
                        adapter.notifyItemChanged(position);
                    } else {
                        Log.w("MessagesActivity", "Chat item not found in list for update");
                    }
                })
                .addOnFailureListener(e -> {
                    Log.e("MessagesActivity", "Failed to check unread messages for " + chatItem.getProjectName(), e);
                });
    }

    private void onChatClicked(MessageChatItem chatItem) {
        Intent intent = new Intent(this, GroupChatActivity.class);
        intent.putExtra("PROJECT_ID", chatItem.getProjectId());
        startActivity(intent);
    }

    private void loadUserRole() {
        db.collection("users").document(currentUserId)
                .get()
                .addOnSuccessListener(userDoc -> {
                    if (userDoc.exists()) {
                        currentUserRole = userDoc.getString("role");
                        Log.d("MessagesActivity", "User role loaded: " + currentUserRole);
                        setupBottomNavigation(); // Setup navigation after role is loaded
                    } else {
                        Log.d("MessagesActivity", "User document not found, defaulting to student role");
                        currentUserRole = "student";
                        setupBottomNavigation();
                    }
                })
                .addOnFailureListener(e -> {
                    Log.e("MessagesActivity", "Error loading user role: " + e.getMessage());
                    currentUserRole = "student"; // Default to student
                    setupBottomNavigation();
                });
    }

    private void setupBottomNavigation() {
        ConstraintLayout bottomNav = findViewById(R.id.custom_bottom_nav);
        navController = new CustomBottomNavController(this, bottomNav);
        
        // Set up navigation listener
        navController.setOnNavigationListener(new CustomBottomNavController.OnNavigationListener() {
            @Override
            public void onNavigationItemSelected(int itemId) {
                handleNavigation(itemId);
            }
            
            @Override
            public void onNavigationItemReselected(int itemId) {
                // Handle reselection - scroll to top or refresh
                if (itemId == CustomBottomNavController.NAV_ANALYTICS) {
                    // Refresh messages
                    loadUserChats();
                }
            }
        });
        
        // Set current item to messages
        navController.setCurrentItem(CustomBottomNavController.NAV_ANALYTICS);
        
        // Show sample badges
        navController.showBadge(CustomBottomNavController.NAV_TASKS, 2);
        navController.showDotBadge(CustomBottomNavController.NAV_PROJECTS);
        
        // Animate entry
        navController.animateEntry();
    }
    
    private void handleNavigation(int itemId) {
        Intent intent = null;
        
        Log.d("MessagesActivity", "Navigation selected: " + itemId + ", user role: " + currentUserRole);
        
        // Normalize role to lowercase for comparison
        String normalizedRole = currentUserRole != null ? currentUserRole.toLowerCase() : "student";
        
        switch (itemId) {
            case CustomBottomNavController.NAV_HOME:
                if ("teacher".equals(normalizedRole)) {
                    Log.d("MessagesActivity", "Navigating to TeacherDashboardActivity");
                    intent = new Intent(getApplicationContext(), TeacherDashboardActivity.class);
                } else {
                    Log.d("MessagesActivity", "Navigating to DashboardActivity");
                    intent = new Intent(getApplicationContext(), DashboardActivity.class);
                }
                break;
                
            case CustomBottomNavController.NAV_PROJECTS:
                if ("teacher".equals(normalizedRole)) {
                    Log.d("MessagesActivity", "Navigating to TeacherProjectsActivity");
                    intent = new Intent(getApplicationContext(), TeacherProjectsActivity.class);
                } else {
                    Log.d("MessagesActivity", "Navigating to ProjectsActivity");
                    intent = new Intent(getApplicationContext(), ProjectsActivity.class);
                }
                break;
                
            case CustomBottomNavController.NAV_TASKS:
                if ("teacher".equals(normalizedRole)) {
                    Log.d("MessagesActivity", "Navigating to TeacherTasksActivity");
                    intent = new Intent(getApplicationContext(), TeacherTasksActivity.class);
                } else {
                    Log.d("MessagesActivity", "Navigating to MyTasksActivity");
                    intent = new Intent(getApplicationContext(), MyTasksActivity.class);
                }
                break;
                
            case CustomBottomNavController.NAV_ANALYTICS:
                Log.d("MessagesActivity", "Already in MessagesActivity - refreshing");
                // Already in MessagesActivity - just refresh
                loadUserChats();
                return;
                
            case CustomBottomNavController.NAV_CALENDAR:
                Log.d("MessagesActivity", "Navigating to CalendarActivity");
                intent = new Intent(getApplicationContext(), CalendarActivity.class);
                break;
        }
        
        if (intent != null) {
            Log.d("MessagesActivity", "Starting intent: " + intent.getComponent().getClassName());
            startActivity(intent);
            finish();
        } else {
            Log.e("MessagesActivity", "Intent was null for itemId: " + itemId);
        }
    }

    private ColorStateList createColorStateList(int selectedColor, int unselectedColor) {
        int[][] states = new int[][] {
                new int[] { android.R.attr.state_checked }, // selected
                new int[] { -android.R.attr.state_checked }  // unselected
        };
        int[] colors = new int[] {
                selectedColor,
                unselectedColor
        };
        return new ColorStateList(states, colors);
    }

    private void showJoinProjectDialog() {
        // Create dialog for joining project with project code
        android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(this);
        builder.setTitle("Join Project");
        
        // Create input field
        final EditText input = new EditText(this);
        input.setHint("Enter project code");
        builder.setView(input);
        
        // Set positive button
        builder.setPositiveButton("Join", (dialog, which) -> {
            String projectCode = input.getText().toString().trim();
            if (projectCode.isEmpty()) {
                Toast.makeText(this, "Please enter a project code", Toast.LENGTH_SHORT).show();
                return;
            }
            
            joinProjectWithCode(projectCode);
        });
        
        // Set negative button
        builder.setNegativeButton("Cancel", (dialog, which) -> dialog.cancel());
        
        builder.show();
    }

    private void joinProjectWithCode(String projectCode) {
        Log.d("MessagesActivity", "Attempting to join project with code: " + projectCode);
        
        // Search for project by code
        db.collection("projects")
                .whereEqualTo("projectCode", projectCode)
                .get()
                .addOnSuccessListener(queryDocumentSnapshots -> {
                    if (queryDocumentSnapshots.isEmpty()) {
                        Toast.makeText(this, "Invalid project code", Toast.LENGTH_LONG).show();
                        return;
                    }
                    
                    DocumentSnapshot projectDoc = queryDocumentSnapshots.getDocuments().get(0);
                    String projectId = projectDoc.getId();
                    String projectName = projectDoc.getString("title");
                    String leaderId = projectDoc.getString("leaderId");
                    List<String> teamMembers = (List<String>) projectDoc.get("teamMembers");
                    
                    // Check if user is already in project
                    boolean isAlreadyMember = leaderId != null && leaderId.equals(currentUserId) ||
                            (teamMembers != null && teamMembers.contains(currentUserId));
                    
                    if (isAlreadyMember) {
                        Toast.makeText(this, "You are already a member of this project", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    
                    // Add user to project
                    db.collection("projects").document(projectId)
                            .update("teamMembers", com.google.firebase.firestore.FieldValue.arrayUnion(currentUserId))
                            .addOnSuccessListener(aVoid -> {
                                // Log the activity
                                String logMessage = "joined the project.";
                                LogHelper.logActivity(projectId, logMessage, ActivityLog.EventType.MEMBER_JOINED);
                                
                                Toast.makeText(this, "Successfully joined project: " + projectName, Toast.LENGTH_SHORT).show();
                                
                                // Refresh the chat list
                                loadUserChats();
                            })
                            .addOnFailureListener(e -> {
                                Log.e("MessagesActivity", "Failed to join project", e);
                                Toast.makeText(this, "Failed to join project", Toast.LENGTH_SHORT).show();
                            });
                })
                .addOnFailureListener(e -> {
                    Log.e("MessagesActivity", "Failed to search for project", e);
                    Toast.makeText(this, "Failed to search for project", Toast.LENGTH_SHORT).show();
                });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (projectsListener != null) {
            projectsListener.remove();
        }
    }
}
