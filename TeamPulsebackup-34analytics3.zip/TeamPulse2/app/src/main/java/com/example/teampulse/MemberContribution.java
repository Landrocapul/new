package com.example.teampulse;

import java.io.Serializable;
import java.util.List;

public class MemberContribution implements Serializable {
    private String memberId;
    private String memberName;
    private int completedTasks;
    private int totalTasks;
    private int totalPoints;
    private double contributionPercentage;
    private List<String> taskIds;
    
    public MemberContribution() {} // Empty constructor for Firestore
    
    public MemberContribution(String memberId, String memberName) {
        this.memberId = memberId;
        this.memberName = memberName;
        this.completedTasks = 0;
        this.totalTasks = 0;
        this.totalPoints = 0;
        this.contributionPercentage = 0.0;
    }
    
    // Getters and Setters
    public String getMemberId() { return memberId; }
    public void setMemberId(String memberId) { this.memberId = memberId; }
    
    public String getMemberName() { return memberName; }
    public void setMemberName(String memberName) { this.memberName = memberName; }
    
    public int getCompletedTasks() { return completedTasks; }
    public void setCompletedTasks(int completedTasks) { this.completedTasks = completedTasks; }
    
    public int getTotalTasks() { return totalTasks; }
    public void setTotalTasks(int totalTasks) { this.totalTasks = totalTasks; }
    
    public int getTotalPoints() { return totalPoints; }
    public void setTotalPoints(int totalPoints) { this.totalPoints = totalPoints; }
    
    public double getContributionPercentage() { return contributionPercentage; }
    public void setContributionPercentage(double contributionPercentage) { this.contributionPercentage = contributionPercentage; }
    
    public List<String> getTaskIds() { return taskIds; }
    public void setTaskIds(List<String> taskIds) { this.taskIds = taskIds; }
    
    public void incrementCompletedTasks() { this.completedTasks++; }
    
    public void incrementTotalTasks() { this.totalTasks++; }
    
    public void addPoints(int points) { this.totalPoints += points; }
    
    public void calculateContributionPercentage(int projectTotalPoints) {
        if (projectTotalPoints > 0) {
            this.contributionPercentage = (double) this.totalPoints / projectTotalPoints * 100;
        } else {
            this.contributionPercentage = 0.0;
        }
    }
}
