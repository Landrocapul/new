package com.example.teampulse;

import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.widget.SwitchCompat;
import androidx.fragment.app.Fragment;

import com.google.android.material.navigation.NavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;

public class NavigationDrawerFragment extends Fragment {

    private NavigationView navigationView;
    private ThemeHelper themeHelper;
    private FirebaseAuth mAuth;
    private FirebaseFirestore db;

    public interface NavigationListener {
        void onLogout();
        void onProfile();
        void onActivityLog();
        void onAnalytics();
    }

    private NavigationListener listener;

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        if (context instanceof NavigationListener) {
            listener = (NavigationListener) context;
        } else {
            throw new RuntimeException(context.toString() + " must implement NavigationListener");
        }
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_navigation_drawer, container, false);
        navigationView = view.findViewById(R.id.nav_view);

        themeHelper = new ThemeHelper(requireContext());
        mAuth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();

        setupNavigationView();
        return view;
    }

    private void setupNavigationView() {
        fetchHeaderData();
        setupThemeSwitch();

        navigationView.setNavigationItemSelectedListener(item -> {
            int id = item.getItemId();

            if (id == R.id.nav_drawer_logout) {
                listener.onLogout();
            } else if (id == R.id.nav_drawer_profile) {
                listener.onProfile();
            } else if (id == R.id.nav_drawer_activity_log) {
                listener.onActivityLog();
            } else if (id == R.id.nav_drawer_analytics) {
                listener.onAnalytics();
            }

            // Close drawer for navigation items, not for switch
            if (id != R.id.nav_drawer_dark_mode) {
                // Close drawer via activity
                if (getActivity() instanceof DrawerActivity) {
                    ((DrawerActivity) getActivity()).closeDrawer();
                }
            }
            return true;
        });
    }

    private void fetchHeaderData() {
        FirebaseUser user = mAuth.getCurrentUser();
        if (user != null) {
            View headerView = navigationView.getHeaderView(0);
            TextView headerUserName = headerView.findViewById(R.id.header_user_name);
            TextView headerUserEmail = headerView.findViewById(R.id.header_user_email);
            TextView headerUserRole = headerView.findViewById(R.id.header_user_role);
            TextView headerUserInitials = headerView.findViewById(R.id.header_user_initials);

            headerUserEmail.setText(user.getEmail());

            db.collection("users").document(user.getUid()).get().addOnSuccessListener(doc -> {
                if (doc.exists()) {
                    String name = doc.getString("name");
                    String role = doc.getString("role");

                    headerUserName.setText(name != null ? name : "User");

                    // Set user initials for profile circle
                    if (name != null && !name.trim().isEmpty()) {
                        String[] nameParts = name.trim().split("\\s+");
                        StringBuilder initials = new StringBuilder();
                        for (String part : nameParts) {
                            if (!part.isEmpty()) {
                                initials.append(part.charAt(0));
                                if (initials.length() >= 2) break; // Max 2 initials
                            }
                        }
                        headerUserInitials.setText(initials.toString().toUpperCase());
                    } else {
                        headerUserInitials.setText("U"); // Default for unknown user
                    }

                    // Format and display role
                    if (role != null) {
                        String formattedRole = role.toUpperCase();
                        if ("Teacher".equals(role)) {
                            formattedRole = "TEACHER";
                        } else if ("Student".equals(role)) {
                            formattedRole = "STUDENT";
                        }
                        headerUserRole.setText(formattedRole);
                    }
                }
            });
        }
    }

    private void setupThemeSwitch() {
        MenuItem darkModeItem = navigationView.getMenu().findItem(R.id.nav_drawer_dark_mode);
        View actionView = darkModeItem.getActionView();
        if (actionView != null) {
            SwitchCompat darkModeSwitch = actionView.findViewById(R.id.drawer_switch);

            int currentNightMode = requireContext().getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK;
            darkModeSwitch.setChecked(currentNightMode == Configuration.UI_MODE_NIGHT_YES);

            darkModeSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> {
                themeHelper.applyTheme(isChecked ? ThemeHelper.DARK_MODE : ThemeHelper.LIGHT_MODE);
            });
        }
    }

    // Interface for closing drawer
    public interface DrawerActivity {
        void closeDrawer();
    }
}
