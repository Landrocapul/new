package com.example.teampulse;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.example.teampulse.databinding.ActivityEditProjectBinding;
import com.google.android.material.datepicker.MaterialDatePicker;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class EditProjectActivity extends AppCompatActivity {
    private ActivityEditProjectBinding binding;
    private FirebaseFirestore db;
    private FirebaseAuth mAuth;
    private String projectId;
    private Project existingProject;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityEditProjectBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        mAuth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();

        projectId = getIntent().getStringExtra("PROJECT_ID");
        
        setupToolbar();
        setupClickListeners();
        
        if (projectId != null) {
            loadProjectData();
        } else {
            Toast.makeText(this, "Project ID not found", Toast.LENGTH_SHORT).show();
            finish();
        }
    }

    private void setupToolbar() {
        setSupportActionBar(binding.toolbar);
        binding.toolbar.setTitle("Edit Project");
        binding.toolbar.setNavigationOnClickListener(v -> finish());
    }

    private void setupClickListeners() {
        binding.deadlineEditText.setOnClickListener(v -> showDatePicker());
        binding.saveProjectButton.setOnClickListener(v -> saveProject());
        binding.cancelButton.setOnClickListener(v -> finish());
    }

    private void loadProjectData() {
        db.collection("projects").document(projectId).get()
                .addOnSuccessListener(documentSnapshot -> {
                    if (documentSnapshot.exists()) {
                        existingProject = documentSnapshot.toObject(Project.class);
                        existingProject.setId(documentSnapshot.getId());
                        populateFields();
                    } else {
                        Toast.makeText(this, "Project not found", Toast.LENGTH_SHORT).show();
                        finish();
                    }
                })
                .addOnFailureListener(e -> {
                    Toast.makeText(this, "Failed to load project", Toast.LENGTH_SHORT).show();
                    finish();
                });
    }

    private void populateFields() {
        if (existingProject == null) return;

        binding.projectTitleEditText.setText(existingProject.getTitle());
        binding.projectDescriptionEditText.setText(existingProject.getDescription());
        
        if (existingProject.getDeadline() != null && !existingProject.getDeadline().isEmpty()) {
            binding.deadlineEditText.setText(existingProject.getDeadline());
        }
    }

    private void showDatePicker() {
        MaterialDatePicker<Long> datePicker = MaterialDatePicker.Builder.datePicker()
                .setTitleText("Select Project Deadline")
                .setSelection(MaterialDatePicker.todayInUtcMilliseconds())
                .build();

        datePicker.addOnPositiveButtonClickListener(selection -> {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
            String formattedDate = sdf.format(new Date(selection));
            binding.deadlineEditText.setText(formattedDate);
        });

        datePicker.show(getSupportFragmentManager(), "DATE_PICKER");
    }

    private void saveProject() {
        String title = binding.projectTitleEditText.getText().toString().trim();
        String description = binding.projectDescriptionEditText.getText().toString().trim();
        String deadline = binding.deadlineEditText.getText().toString().trim();

        if (title.isEmpty()) {
            binding.projectTitleEditText.setError("Project title is required");
            return;
        }

        if (description.isEmpty()) {
            binding.projectDescriptionEditText.setError("Project description is required");
            return;
        }

        // Update project data
        existingProject.setTitle(title);
        existingProject.setDescription(description);
        existingProject.setDeadline(deadline);

        db.collection("projects").document(projectId)
                .set(existingProject)
                .addOnSuccessListener(aVoid -> {
                    Toast.makeText(this, "Project updated successfully", Toast.LENGTH_SHORT).show();
                    setResult(RESULT_OK);
                    finish();
                })
                .addOnFailureListener(e -> {
                    Toast.makeText(this, "Failed to update project", Toast.LENGTH_SHORT).show();
                });
    }
}
