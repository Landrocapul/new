package com.example.teampulse;

import android.util.Log;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;

public class FixUnreadMessages {
    private static final String LEADER_ID = "7Gn7flUNPtUXLaNzsYeXNXSlJlB2";
    private static final String MEMBER_ID = "X9JSeMmqAiQVJYWZFByZ2nfkgre2";
    
    public static void fixProject1Messages() {
        FirebaseFirestore db = FirebaseFirestore.getInstance();
        
        // Get all messages in Project 1
        db.collection("projects").document("PROJECT_ID_HERE") // Replace with actual project ID
                .collection("messages")
                .get()
                .addOnSuccessListener(queryDocumentSnapshots -> {
                    AtomicInteger fixedCount = new AtomicInteger(0);
                    List<String> messageIdsToFix = new ArrayList<>();
                    
                    for (QueryDocumentSnapshot doc : queryDocumentSnapshots) {
                        String senderId = doc.getString("senderId");
                        List<String> readBy = (List<String>) doc.get("readBy");
                        
                        // If message is from member but leader is in readBy list, fix it
                        if (MEMBER_ID.equals(senderId) && readBy != null && readBy.contains(LEADER_ID)) {
                            messageIdsToFix.add(doc.getId());
                            Log.d("FixUnread", "Found message to fix: " + doc.getId() + " from " + senderId);
                        }
                    }
                    
                    Log.d("FixUnread", "Found " + messageIdsToFix.size() + " messages to fix");
                    
                    // Fix each message by removing leader from readBy
                    for (String messageId : messageIdsToFix) {
                        Map<String, Object> updates = new HashMap<>();
                        // Remove leader from readBy list
                        updates.put("readBy", com.google.firebase.firestore.FieldValue.arrayRemove(LEADER_ID));
                        // Reset status to delivered
                        updates.put("status", "delivered");
                        
                        db.collection("projects").document("PROJECT_ID_HERE")
                                .collection("messages")
                                .document(messageId)
                                .update(updates)
                                .addOnSuccessListener(aVoid -> {
                                    Log.d("FixUnread", "Fixed message: " + messageId + " (" + fixedCount.getAndIncrement() + "/" + messageIdsToFix.size() + ")");
                                })
                                .addOnFailureListener(e -> {
                                    Log.e("FixUnread", "Failed to fix message: " + messageId, e);
                                });
                    }
                })
                .addOnFailureListener(e -> {
                    Log.e("FixUnread", "Failed to load messages", e);
                });
    }
}
