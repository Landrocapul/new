package com.example.teampulse;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;

import java.util.ArrayList;
import java.util.List;

/**
 * Projects Activity with Custom Bottom Navigation
 * Demonstrates Instagram-like bottom navigation implementation
 */
public class ProjectsActivityCustom extends AppCompatActivity implements OnProjectInteractionListener {
    
    private RecyclerView recyclerView;
    private ProjectsAdapter projectAdapter;
    private List<Project> projectList;
    private CustomBottomNavController navController;
    private FloatingActionButton fabAddProject;
    private FirebaseFirestore db;
    private FirebaseAuth mAuth;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_projects_custom);
        
        // Initialize Firebase
        mAuth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();
        
        initializeViews();
        setupRecyclerView();
        setupBottomNavigation();
        setupFab();
    }
    
    private void initializeViews() {
        recyclerView = findViewById(R.id.recyclerViewProjects);
        fabAddProject = findViewById(R.id.fab_add_project);
        ConstraintLayout bottomNav = findViewById(R.id.custom_bottom_nav);
        
        // Initialize custom bottom navigation controller
        navController = new CustomBottomNavController(this, bottomNav);
    }
    
    private void setupRecyclerView() {
        projectList = new ArrayList<>();
        // Add sample projects - using actual Project class constructor
        // Note: You'll need to check the actual Project class constructor
        // For now, let the adapter fetch real data from Firebase
        
        projectAdapter = new ProjectsAdapter(this, projectList, this);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(projectAdapter);
    }
    
    private void setupBottomNavigation() {
        // Set up navigation listener
        navController.setOnNavigationListener(new CustomBottomNavController.OnNavigationListener() {
            @Override
            public void onNavigationItemSelected(int itemId) {
                handleNavigation(itemId);
            }
            
            @Override
            public void onNavigationItemReselected(int itemId) {
                // Handle reselection (scroll to top, refresh, etc.)
                scrollToTop();
            }
        });
        
        // Set up long press listeners for shortcuts
        navController.setOnLongClickListener(CustomBottomNavController.NAV_HOME, v -> {
            showHomeShortcuts();
            return true;
        });
        
        navController.setOnLongClickListener(CustomBottomNavController.NAV_PROJECTS, v -> {
            showProjectShortcuts();
            return true;
        });
        
        // Show sample badges
        navController.showBadge(CustomBottomNavController.NAV_ANALYTICS, 5);
        navController.showBadge(CustomBottomNavController.NAV_TASKS, 3);
        navController.showDotBadge(CustomBottomNavController.NAV_CALENDAR);
        
        // Animate entry
        navController.animateEntry();
    }
    
    private void setupFab() {
        fabAddProject.setOnClickListener(v -> {
            // Handle FAB click
            Intent intent = new Intent(this, CreateProjectActivity.class);
            startActivity(intent);
            
            // Animate FAB
            fabAddProject.animate()
                .scaleX(0.8f)
                .scaleY(0.8f)
                .setDuration(100)
                .withEndAction(() -> {
                    fabAddProject.animate()
                        .scaleX(1.0f)
                        .scaleY(1.0f)
                        .setDuration(100)
                        .start();
                })
                .start();
        });
    }
    
    private void handleNavigation(int itemId) {
        Intent intent = null;
        
        switch (itemId) {
            case CustomBottomNavController.NAV_HOME:
                intent = new Intent(this, DashboardActivity.class);
                break;
                
            case CustomBottomNavController.NAV_PROJECTS:
                // Already in ProjectsActivity - just scroll to top
                scrollToTop();
                return;
                
            case CustomBottomNavController.NAV_TASKS:
                intent = new Intent(this, MyTasksActivity.class);
                break;
                
            case CustomBottomNavController.NAV_ANALYTICS:
                showProjectSelectionForAnalytics();
                break;
                
            case CustomBottomNavController.NAV_CALENDAR:
                intent = new Intent(this, CalendarActivity.class);
                break;
        }
        
        if (intent != null) {
            // Clear badges when navigating
            navController.clearAllBadges();
            
            // Navigate with transition
            startActivity(intent);
            overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
        }
    }
    
    private void scrollToTop() {
        recyclerView.smoothScrollToPosition(0);
    }
    
    private void showHomeShortcuts() {
        // Show home shortcuts (quick actions)
        // You can implement a bottom sheet or dialog here
        // For example: Quick stats, recent projects, team status
    }
    
    private void showProjectShortcuts() {
        // Show project shortcuts
        // For example: Create project, filter projects, sort options
    }
    
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_projects, menu);
        return true;
    }
    
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        
        if (id == R.id.action_search) {
            // Handle search
            return true;
        } else if (id == R.id.action_filter) {
            // Handle filter
            return true;
        } else if (id == R.id.action_sort) {
            // Handle sort
            return true;
        }
        
        return super.onOptionsItemSelected(item);
    }
    
    @Override
    protected void onResume() {
        super.onResume();
        
        // Update badges when activity resumes
        updateBadges();
    }
    
    private void updateBadges() {
        // Simulate getting real badge counts
        // In a real app, you would fetch this from your backend/database
        
        // Example: Get unread analytics count
        int unreadAnalytics = getUnreadAnalyticsCount();
        if (unreadAnalytics > 0) {
            navController.showBadge(CustomBottomNavController.NAV_ANALYTICS, unreadAnalytics);
        } else {
            navController.hideBadge(CustomBottomNavController.NAV_ANALYTICS);
        }
        
        // Example: Get pending tasks count
        int pendingTasks = getPendingTasksCount();
        if (pendingTasks > 0) {
            navController.showBadge(CustomBottomNavController.NAV_TASKS, pendingTasks);
        } else {
            navController.hideBadge(CustomBottomNavController.NAV_TASKS);
        }
    }
    
    private int getUnreadMessageCount() {
        // Simulate API call
        return 5; // Example count
    }
    
    private int getUnreadAnalyticsCount() {
        // Simulate getting unread analytics count
        // In a real app, you would fetch this from your backend/database
        return 5; // Return sample count
    }

    private int getPendingTasksCount() {
        // Simulate API call
        return 3; // Example count
    }
    
    // OnProjectInteractionListener implementation
    @Override
    public void onProjectDeleted() {
        // Handle project deletion
        // Refresh the list or show a message
        Toast.makeText(this, "Project deleted", Toast.LENGTH_SHORT).show();
    }
    
    @Override
    public void onProjectPinChanged(String newPinnedId) {
        // Handle project pin change
        // Update the pinned project in the adapter
        if (projectAdapter != null) {
            projectAdapter.setPinnedProjectId(newPinnedId);
        }
    }
    
    @Override
    public void onBackPressed() {
        // Handle back press with custom animation
        if (navController.getCurrentSelectedItem() != CustomBottomNavController.NAV_HOME) {
            // Navigate to home instead of closing app
            navController.setCurrentItem(CustomBottomNavController.NAV_HOME);
        } else {
            super.onBackPressed();
        }
    }

    private void showProjectSelectionForAnalytics() {
        // Get user's projects
        db.collection("projects").whereArrayContains("teamMembers", mAuth.getCurrentUser().getUid()).get()
                .addOnSuccessListener(querySnapshot -> {
                    List<Project> userProjects = new ArrayList<>();
                    for (QueryDocumentSnapshot doc : querySnapshot) {
                        Project project = doc.toObject(Project.class);
                        project.setId(doc.getId());
                        userProjects.add(project);
                    }
                    
                    if (userProjects.isEmpty()) {
                        Toast.makeText(this, "No projects found to analyze", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    
                    // Create dialog to select project
                    String[] projectNames = new String[userProjects.size()];
                    for (int i = 0; i < userProjects.size(); i++) {
                        projectNames[i] = userProjects.get(i).getTitle();
                    }
                    
                    new androidx.appcompat.app.AlertDialog.Builder(this)
                            .setTitle("Select Project for Analytics")
                            .setItems(projectNames, (dialog, which) -> {
                                Project selectedProject = userProjects.get(which);
                                Intent intent = new Intent(this, AnalyticsActivity.class);
                                intent.putExtra("PROJECT_ID", selectedProject.getId());
                                startActivity(intent);
                            })
                            .show();
                })
                .addOnFailureListener(e -> {
                    Toast.makeText(this, "Error loading projects", Toast.LENGTH_SHORT).show();
                });
    }
}
