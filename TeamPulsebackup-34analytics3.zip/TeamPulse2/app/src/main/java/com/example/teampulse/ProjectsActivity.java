package com.example.teampulse;

import android.content.Intent;
import android.content.res.ColorStateList;
import android.os.Bundle;
import android.text.InputType;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.content.ContextCompat;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.example.teampulse.databinding.ActivityProjectsBinding;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.ListenerRegistration;
import com.google.firebase.firestore.QueryDocumentSnapshot;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ProjectsActivity extends AppCompatActivity implements OnProjectInteractionListener, NavigationDrawerFragment.NavigationListener, NavigationDrawerFragment.DrawerActivity {

    private ActivityProjectsBinding binding;
    private FirebaseFirestore db;
    private FirebaseAuth mAuth;
    private ProjectsAdapter adapter;
    private List<Project> projectList = new ArrayList<>();
    private Map<String, Project> projectMap = new HashMap<>();

    // Drawer components
    private DrawerLayout drawerLayout;
    private ActionBarDrawerToggle toggle;
    private CustomBottomNavController navController;

    private ListenerRegistration userListener;
    private ListenerRegistration projectsListener;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityProjectsBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        db = FirebaseFirestore.getInstance();
        mAuth = FirebaseAuth.getInstance();

        setupViews();
        setupToolbarAndDrawer();
        setupRecyclerView();
        setupFab();
        setupBottomNavigation();
    }

    private void setupViews() {
        drawerLayout = findViewById(R.id.drawer_layout);
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadUserDataAndProjects();
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (userListener != null) userListener.remove();
        if (projectsListener != null) projectsListener.remove();
    }

    @Override
    public void onProjectDeleted() {
        // Listener automatically handles refresh
    }

    @Override
    public void onProjectPinChanged(String newPinnedId) {
        FirebaseUser currentUser = mAuth.getCurrentUser();
        if (currentUser == null) return;
        db.collection("users").document(currentUser.getUid())
                .update("pinnedProjectId", newPinnedId)
                .addOnSuccessListener(aVoid -> {
                    String message = newPinnedId == null ? "Project unpinned" : "Project pinned to dashboard";
                    Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
                })
                .addOnFailureListener(e -> Toast.makeText(this, "Failed to update pin.", Toast.LENGTH_SHORT).show());
    }

    private void setupToolbarAndDrawer() {
        setSupportActionBar(binding.toolbar);
        toggle = new ActionBarDrawerToggle(this, drawerLayout, binding.toolbar,
                R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawerLayout.addDrawerListener(toggle);
        toggle.syncState();

        // Host the NavigationDrawerFragment
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.drawer_fragment_container, new NavigationDrawerFragment())
                .commit();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.projects_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.action_join_project) {
            showJoinProjectDialog();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }


    private void logoutUser() {
        mAuth.signOut();
        startActivity(new Intent(this, SignInActivity.class).setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK));
        finish();
    }

    private void setupRecyclerView() {
        adapter = new ProjectsAdapter(this, projectList, this);
        binding.projectsRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        binding.projectsRecyclerView.setAdapter(adapter);
        binding.projectsRecyclerView.setItemAnimator(new androidx.recyclerview.widget.DefaultItemAnimator());
    }

    private void loadUserDataAndProjects() {
        FirebaseUser currentUser = mAuth.getCurrentUser();
        if (currentUser == null) {
            finish();
            return;
        }
        String currentUserId = currentUser.getUid();
        userListener = db.collection("users").document(currentUserId).addSnapshotListener((snapshot, e) -> {
            if (snapshot != null && snapshot.exists()) {
                String role = snapshot.getString("role");
                String pinnedId = snapshot.getString("pinnedProjectId");
                if (adapter != null) {
                    adapter.setPinnedProjectId(pinnedId);
                }
                binding.fabAddProject.setVisibility(View.VISIBLE);
            }
        });
        loadAllProjects(currentUserId);
    }

    private void loadAllProjects(String currentUserId) {
        projectsListener = db.collection("projects")
                .whereArrayContains("teamMembers", currentUserId)
                .addSnapshotListener((snapshots, e) -> {
                    if (e != null) {
                        Toast.makeText(this, "Error fetching projects.", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    if (snapshots != null) {
                        projectMap.clear();
                        for (QueryDocumentSnapshot doc : snapshots) {
                            Project project = doc.toObject(Project.class);
                            project.setId(doc.getId());
                            projectMap.put(doc.getId(), project);
                        }
                        projectList.clear();
                        projectList.addAll(projectMap.values());
                        adapter.notifyDataSetChanged();
                    }
                });
    }

    private void setupFab() {
        binding.fabAddProject.setOnClickListener(v ->
                startActivity(new Intent(ProjectsActivity.this, CreateProjectActivity.class)));
    }

    private void setupBottomNavigation() {
        ConstraintLayout bottomNav = findViewById(R.id.custom_bottom_nav);
        navController = new CustomBottomNavController(this, bottomNav);
        
        // Set up navigation listener
        navController.setOnNavigationListener(new CustomBottomNavController.OnNavigationListener() {
            @Override
            public void onNavigationItemSelected(int itemId) {
                handleNavigation(itemId);
            }
            
            @Override
            public void onNavigationItemReselected(int itemId) {
                // Handle reselection - scroll to top or refresh
                if (itemId == CustomBottomNavController.NAV_PROJECTS) {
                    // Refresh projects data
                    loadUserDataAndProjects();
                }
            }
        });
        
        // Set current item to projects
        navController.setCurrentItem(CustomBottomNavController.NAV_PROJECTS);
        
        // Show sample badges
        navController.showBadge(CustomBottomNavController.NAV_ANALYTICS, 2);
        navController.showBadge(CustomBottomNavController.NAV_TASKS, 7);
        
        // Animate entry
        navController.animateEntry();
    }
    
    private void handleNavigation(int itemId) {
        switch (itemId) {
            case CustomBottomNavController.NAV_HOME:
                navigateToDashboard();
                break;
                
            case CustomBottomNavController.NAV_PROJECTS:
                // Already in ProjectsActivity - just refresh
                loadUserDataAndProjects();
                break;
                
            case CustomBottomNavController.NAV_TASKS:
                startActivity(new Intent(getApplicationContext(), MyTasksActivity.class));
                finish();
                break;
                
            case CustomBottomNavController.NAV_ANALYTICS:
                showProjectSelectionForAnalytics();
                finish();
                break;
                
            case CustomBottomNavController.NAV_CALENDAR:
                startActivity(new Intent(getApplicationContext(), CalendarActivity.class));
                finish();
                break;
        }
    }

    private ColorStateList createColorStateList(int selectedColor, int unselectedColor) {
        int[][] states = new int[][] {
            new int[] { android.R.attr.state_checked }, // selected
            new int[] { -android.R.attr.state_checked }  // unselected
        };
        int[] colors = new int[] {
            selectedColor,
            unselectedColor
        };
        return new ColorStateList(states, colors);
    }

    private void navigateToDashboard() {
        FirebaseUser user = mAuth.getCurrentUser();
        if (user != null) {
            db.collection("users").document(user.getUid()).get().addOnSuccessListener(doc -> {
                if (doc.exists()) {
                    Intent intent;
                    String role = doc.getString("role");
                    if ("Teacher".equals(role)) {
                        intent = new Intent(getApplicationContext(), TeacherDashboardActivity.class);
                    } else {
                        intent = new Intent(getApplicationContext(), DashboardActivity.class);
                    }
                    startActivity(intent);
                    finish();
                }
            });
        }
    }

    @Override
    public void onLogout() {
        logoutUser();
    }

    @Override
    public void onProfile() {
        startActivity(new Intent(this, ProfileActivity.class));
    }

    @Override
    public void onActivityLog() {
        startActivity(new Intent(this, GlobalLogActivity.class));
    }

    @Override
    public void onAnalytics() {
        // Show project selection for analytics
        showProjectSelectionForAnalytics();
    }

    private void showProjectSelectionForAnalytics() {
        if (projectList.isEmpty()) {
            Toast.makeText(this, "No projects found to analyze", Toast.LENGTH_SHORT).show();
            return;
        }
        
        // Create dialog to select project
        String[] projectNames = new String[projectList.size()];
        for (int i = 0; i < projectList.size(); i++) {
            projectNames[i] = projectList.get(i).getTitle();
        }
        
        new androidx.appcompat.app.AlertDialog.Builder(this)
                .setTitle("Select Project for Analytics")
                .setItems(projectNames, (dialog, which) -> {
                    Project selectedProject = projectList.get(which);
                    Intent intent = new Intent(this, AnalyticsActivity.class);
                    intent.putExtra("PROJECT_ID", selectedProject.getId());
                    startActivity(intent);
                })
                .show();
    }

    @Override
    public void closeDrawer() {
        drawerLayout.closeDrawer(GravityCompat.START);
    }

    private void showJoinProjectDialog() {
        // Create dialog for joining project with project code
        android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(this);
        builder.setTitle("Join Project");
        
        // Create input field
        final EditText input = new EditText(this);
        input.setHint("Enter project code");
        builder.setView(input);
        
        // Set positive button
        builder.setPositiveButton("Join", (dialog, which) -> {
            String projectCode = input.getText().toString().trim();
            if (projectCode.isEmpty()) {
                Toast.makeText(this, "Please enter a project code", Toast.LENGTH_SHORT).show();
                return;
            }
            
            joinProjectWithCode(projectCode);
        });
        
        // Set negative button
        builder.setNegativeButton("Cancel", (dialog, which) -> dialog.cancel());
        
        builder.show();
    }
    private void joinProjectWithCode(String projectCode) {
        // Search for project by code
        db.collection("projects")
                .whereEqualTo("joinCode", projectCode)
                .get()
                .addOnSuccessListener(queryDocumentSnapshots -> {
                    if (queryDocumentSnapshots.isEmpty()) {
                        Toast.makeText(this, "Invalid project code", Toast.LENGTH_LONG).show();
                        return;
                    }
                    
                    DocumentSnapshot projectDoc = queryDocumentSnapshots.getDocuments().get(0);
                    String projectId = projectDoc.getId();
                    String projectName = projectDoc.getString("title");
                    String leaderId = projectDoc.getString("leaderId");
                    List<String> teamMembers = (List<String>) projectDoc.get("teamMembers");
                    
                    // Get current user ID
                    String currentUserId = mAuth.getCurrentUser().getUid();
                    
                    // Check if user is already in project
                    boolean isAlreadyMember = leaderId != null && leaderId.equals(currentUserId) ||
                            (teamMembers != null && teamMembers.contains(currentUserId));
                    
                    if (isAlreadyMember) {
                        Toast.makeText(this, "You are already a member of this project", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    
                    // Add user to project
                    db.collection("projects").document(projectId)
                            .update("teamMembers", com.google.firebase.firestore.FieldValue.arrayUnion(currentUserId))
                            .addOnSuccessListener(aVoid -> {
                                // Log the activity
                                String logMessage = "joined the project.";
                                LogHelper.logActivity(projectId, logMessage, ActivityLog.EventType.MEMBER_JOINED);
                                
                                Toast.makeText(this, "Successfully joined project: " + projectName, Toast.LENGTH_SHORT).show();
                                
                                // Refresh the projects list
                                loadAllProjects(currentUserId);
                            })
                            .addOnFailureListener(e -> {
                                Toast.makeText(this, "Failed to join project", Toast.LENGTH_SHORT).show();
                            });
                })
                .addOnFailureListener(e -> {
                    Toast.makeText(this, "Failed to search for project", Toast.LENGTH_SHORT).show();
                });
    }
}