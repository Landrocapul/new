package com.example.teampulse;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.example.teampulse.databinding.ActivitySignUpBinding;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class SignUpActivity extends AppCompatActivity {

    private ActivitySignUpBinding binding;
    private FirebaseAuth mAuth;
    private FirebaseFirestore db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivitySignUpBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        setSupportActionBar(binding.toolbar);
        binding.toolbar.setNavigationOnClickListener(v -> finish());

        mAuth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();

        String[] roles = {"Teacher", "Student"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, roles);
        binding.roleAutoCompleteTextView.setAdapter(adapter);

        binding.signUpButton.setOnClickListener(v -> handleSignUp());
        binding.signInPrompt.setOnClickListener(v -> navigateTo(SignInActivity.class));
        binding.welcomePageButton.setOnClickListener(v -> {
            // Reset onboarding preference and go to welcome page
            SharedPreferences prefs = getSharedPreferences("OnboardingPrefs", MODE_PRIVATE);
            SharedPreferences.Editor editor = prefs.edit();
            editor.putBoolean("isFirstTime", true);
            editor.apply();
            
            Intent intent = new Intent(SignUpActivity.this, WelcomeActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            startActivity(intent);
            finish();
        });

        // Add role selection listener to show/hide year level field
        binding.roleAutoCompleteTextView.setOnItemClickListener((parent, view, position, id) -> {
            String selectedRole = (String) parent.getItemAtPosition(position);
            if ("Teacher".equals(selectedRole)) {
                // Hide year level for teachers
                binding.yearLevelInputLayout.setVisibility(View.GONE);
            } else {
                // Show year level for students
                binding.yearLevelInputLayout.setVisibility(View.VISIBLE);
            }
        });
    }

    private void handleSignUp() {
        String name = binding.nameEditText.getText().toString().trim();
        String email = binding.emailEditText.getText().toString().trim();
        String password = binding.passwordEditText.getText().toString().trim();
        String confirmPassword = binding.confirmPasswordEditText.getText().toString().trim();
        String department = binding.departmentEditText.getText().toString().trim();
        String yearLevel = binding.yearLevelEditText.getText().toString().trim();
        String role = binding.roleAutoCompleteTextView.getText().toString().trim();

        // Validate required fields - year level is optional for teachers
        if (name.isEmpty() || email.isEmpty() || password.isEmpty() || confirmPassword.isEmpty() || department.isEmpty() || role.isEmpty()) {
            showToast("Please fill out all required fields.");
            return;
        }
        
        // Additional validation for students - year level is required for students
        if (!"Teacher".equals(role) && yearLevel.isEmpty()) {
            showToast("Year level is required for students.");
            return;
        }
        
        if (!password.equals(confirmPassword)) {
            showToast("Passwords do not match.");
            return;
        }
        if (password.length() < 6) {
            showToast("Password must be at least 6 characters.");
            return;
        }

        registerUser(name, email, password, role, department, yearLevel, null);
    }

    private void registerUser(String name, String email, String password, String role, String department, String yearLevel, @Nullable String teacherId) {
        mAuth.createUserWithEmailAndPassword(email, password)
                .addOnSuccessListener(authResult -> {
                    String userId = mAuth.getCurrentUser().getUid();

                    Map<String, Object> user = new HashMap<>();
                    user.put("name", name);
                    user.put("email", email);
                    user.put("role", role);
                    user.put("department", department);
                    user.put("yearLevel", yearLevel);
                    user.put("uid", userId);

                    if (teacherId != null) {
                        user.put("teacherId", teacherId);
                    }

                    if ("Teacher".equals(role)) {
                        String newTeacherCode = "PROF-" + UUID.randomUUID().toString().substring(0, 4).toUpperCase();
                        user.put("teacherCode", newTeacherCode);
                    }

                    db.collection("users").document(userId).set(user)
                            .addOnSuccessListener(unused -> {
                                showToast("Registered successfully!");
                                navigateTo(SignInActivity.class);
                                finish();
                            })
                            .addOnFailureListener(e -> showToast("Failed to save user data: " + e.getMessage()));
                })
                .addOnFailureListener(e -> showToast("Registration failed: " + e.getMessage()));
    }

    private void navigateTo(Class<?> destination) {
        Intent intent = new Intent(SignUpActivity.this, destination);
        startActivity(intent);
    }

    private void showToast(String message) {
        Toast.makeText(SignUpActivity.this, message, Toast.LENGTH_LONG).show(); // Increased duration for better readability
    }
}