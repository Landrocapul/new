package com.example.teampulse;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.teampulse.databinding.ItemMessageChatBinding;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class MessageChatAdapter extends RecyclerView.Adapter<MessageChatAdapter.MessageChatViewHolder> {

    private List<MessageChatItem> chatList;
    private OnChatClickListener listener;
    private Context context;

    public interface OnChatClickListener {
        void onChatClicked(MessageChatItem chatItem);
    }

    public MessageChatAdapter(List<MessageChatItem> chatList, OnChatClickListener listener) {
        this.chatList = chatList;
        this.listener = listener;
    }

    @NonNull
    @Override
    public MessageChatViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        context = parent.getContext();
        ItemMessageChatBinding binding = ItemMessageChatBinding.inflate(LayoutInflater.from(context), parent, false);
        return new MessageChatViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull MessageChatViewHolder holder, int position) {
        MessageChatItem chatItem = chatList.get(position);
        
        holder.binding.tvProjectName.setText(chatItem.getProjectName());
        holder.binding.tvLastMessage.setText(chatItem.getLastMessage());
        
        // Set last message time
        if (chatItem.getLastMessageTime() > 0) {
            String timeText = formatTimestamp(chatItem.getLastMessageTime());
            holder.binding.tvMessageTime.setText(timeText);
        } else {
            holder.binding.tvMessageTime.setText("");
        }
        
        // Set last message sender
        if (chatItem.getLastMessageSender() != null && !chatItem.getLastMessageSender().isEmpty()) {
            holder.binding.tvLastMessageSender.setText(chatItem.getLastMessageSender() + ": ");
        } else {
            holder.binding.tvLastMessageSender.setText("");
        }
        
        // Set unread count
        Log.d("MessageChatAdapter", "Setting unread count for " + chatItem.getProjectName() + ": " + chatItem.getUnreadCount());
        
        if (chatItem.getUnreadCount() > 0) {
            holder.binding.tvUnreadCount.setVisibility(View.VISIBLE);
            String countText = chatItem.getUnreadCount() > 99 ? "99+" : String.valueOf(chatItem.getUnreadCount());
            holder.binding.tvUnreadCount.setText(countText);
            Log.d("MessageChatAdapter", "Unread count badge shown: " + countText);
        } else {
            holder.binding.tvUnreadCount.setVisibility(View.GONE);
            Log.d("MessageChatAdapter", "Unread count badge hidden");
        }
        
        holder.binding.getRoot().setOnClickListener(v -> {
            if (listener != null) {
                listener.onChatClicked(chatItem);
            }
        });
    }

    @Override
    public int getItemCount() {
        return chatList.size();
    }

    private String formatTimestamp(long timestamp) {
        SimpleDateFormat sdf;
        long now = System.currentTimeMillis();
        long diff = now - timestamp;
        
        // If less than 24 hours, show time
        if (diff < 24 * 60 * 60 * 1000) {
            sdf = new SimpleDateFormat("HH:mm", Locale.getDefault());
        } else if (diff < 7 * 24 * 60 * 60 * 1000) {
            // If less than a week, show day name
            sdf = new SimpleDateFormat("EEE", Locale.getDefault());
        } else {
            // Otherwise show date
            sdf = new SimpleDateFormat("MMM dd", Locale.getDefault());
        }
        
        return sdf.format(new Date(timestamp));
    }

    static class MessageChatViewHolder extends RecyclerView.ViewHolder {
        ItemMessageChatBinding binding;

        public MessageChatViewHolder(@NonNull ItemMessageChatBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }
    }
}
