package com.example.teampulse;

/**
 * This interface defines a contract for communication between the ProjectsAdapter
 * and its host (like ProjectsActivity). It allows the adapter to report
 * important events back to the activity so the UI can be updated.
 */
public interface OnProjectInteractionListener {


    void onProjectDeleted();


    void onProjectPinChanged(String newPinnedId);
}