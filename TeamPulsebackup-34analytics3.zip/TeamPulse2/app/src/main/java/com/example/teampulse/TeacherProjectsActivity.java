package com.example.teampulse;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.example.teampulse.databinding.ActivityTeacherProjectsBinding;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.ListenerRegistration;
import com.google.firebase.firestore.QueryDocumentSnapshot;

import java.util.ArrayList;
import java.util.List;

public class TeacherProjectsActivity extends AppCompatActivity implements OnProjectInteractionListener {

    private ActivityTeacherProjectsBinding binding;
    private FirebaseAuth mAuth;
    private FirebaseFirestore db;

    private ProjectsAdapter adapter;
    private List<Project> projectList = new ArrayList<>();
    private CustomBottomNavController navController;
    private ListenerRegistration projectsListener;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityTeacherProjectsBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        mAuth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();

        setSupportActionBar(binding.toolbar);
        setupRecyclerView();
        setupBottomNavigation();
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadTeacherProjects();
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (projectsListener != null) {
            projectsListener.remove();
        }
    }

    private void setupRecyclerView() {
        adapter = new ProjectsAdapter(this, projectList, this);
        binding.teacherProjectsRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        binding.teacherProjectsRecyclerView.setAdapter(adapter);
        binding.teacherProjectsRecyclerView.setItemAnimator(new androidx.recyclerview.widget.DefaultItemAnimator());
    }

    private void loadTeacherProjects() {
        FirebaseUser currentUser = mAuth.getCurrentUser();
        if (currentUser == null) {
            finish();
            return;
        }

        projectsListener = db.collection("projects")
                .whereEqualTo("teacherId", currentUser.getUid())
                .addSnapshotListener((snapshots, e) -> {
                    if (e != null) {
                        Toast.makeText(this, "Error fetching projects.", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    if (snapshots != null) {
                        projectList.clear();
                        for (QueryDocumentSnapshot doc : snapshots) {
                            Project project = doc.toObject(Project.class);
                            project.setId(doc.getId());
                            projectList.add(project);
                        }
                        adapter.notifyDataSetChanged();

                        if (projectList.isEmpty()) {
                            binding.teacherProjectsRecyclerView.setVisibility(View.GONE);
                            binding.tvNoProjects.setVisibility(View.VISIBLE);
                        } else {
                            binding.teacherProjectsRecyclerView.setVisibility(View.VISIBLE);
                            binding.tvNoProjects.setVisibility(View.GONE);
                        }
                    }
                });
    }

    @Override
    public void onProjectDeleted() {
        // Teachers cannot delete projects, so this is intentionally blank.
    }

    @Override
    public void onProjectPinChanged(String newPinnedId) {
        Toast.makeText(this, "Pinning is not available in the teacher view.", Toast.LENGTH_SHORT).show();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.dashboard_menu, menu);
        return true;
    }



    private void setupBottomNavigation() {
        ConstraintLayout bottomNav = findViewById(R.id.custom_bottom_nav);
        navController = new CustomBottomNavController(this, bottomNav);
        
        // Set up navigation listener
        navController.setOnNavigationListener(new CustomBottomNavController.OnNavigationListener() {
            @Override
            public void onNavigationItemSelected(int itemId) {
                handleNavigation(itemId);
            }
            
            @Override
            public void onNavigationItemReselected(int itemId) {
                // Handle reselection - refresh projects
                if (itemId == CustomBottomNavController.NAV_PROJECTS) {
                    // Refresh projects data
                    loadTeacherProjects();
                }
            }
        });
        
        // Set current item to projects
        navController.setCurrentItem(CustomBottomNavController.NAV_PROJECTS);
        
        // Show sample badges
        navController.showBadge(CustomBottomNavController.NAV_ANALYTICS, 1);
        navController.showBadge(CustomBottomNavController.NAV_TASKS, 3);
        
        // Animate entry (disabled)
        navController.animateEntry();
    }
    
    private void handleNavigation(int itemId) {
        Intent intent = null;
        
        switch (itemId) {
            case CustomBottomNavController.NAV_HOME:
                intent = new Intent(getApplicationContext(), TeacherDashboardActivity.class);
                break;
                
            case CustomBottomNavController.NAV_PROJECTS:
                // Already in TeacherProjectsActivity - just refresh
                loadTeacherProjects();
                return;
                
            case CustomBottomNavController.NAV_TASKS:
                intent = new Intent(getApplicationContext(), TeacherTasksActivity.class);
                break;
                
            case CustomBottomNavController.NAV_ANALYTICS:
                showProjectSelectionForAnalytics();
                break;
                
            case CustomBottomNavController.NAV_CALENDAR:
                intent = new Intent(getApplicationContext(), CalendarActivity.class);
                break;
        }
        
        if (intent != null) {
            startActivity(intent);
            finish();
        }
    }

    private void showProjectSelectionForAnalytics() {
        // Get user's projects
        db.collection("projects").whereArrayContains("teamMembers", mAuth.getCurrentUser().getUid()).get()
                .addOnSuccessListener(querySnapshot -> {
                    List<Project> userProjects = new ArrayList<>();
                    for (QueryDocumentSnapshot doc : querySnapshot) {
                        Project project = doc.toObject(Project.class);
                        project.setId(doc.getId());
                        userProjects.add(project);
                    }
                    
                    if (userProjects.isEmpty()) {
                        Toast.makeText(this, "No projects found to analyze", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    
                    // Create dialog to select project
                    String[] projectNames = new String[userProjects.size()];
                    for (int i = 0; i < userProjects.size(); i++) {
                        projectNames[i] = userProjects.get(i).getTitle();
                    }
                    
                    new androidx.appcompat.app.AlertDialog.Builder(this)
                            .setTitle("Select Project for Analytics")
                            .setItems(projectNames, (dialog, which) -> {
                                Project selectedProject = userProjects.get(which);
                                Intent intent = new Intent(this, AnalyticsActivity.class);
                                intent.putExtra("PROJECT_ID", selectedProject.getId());
                                startActivity(intent);
                            })
                            .show();
                })
                .addOnFailureListener(e -> {
                    Toast.makeText(this, "Error loading projects", Toast.LENGTH_SHORT).show();
                });
    }
}
