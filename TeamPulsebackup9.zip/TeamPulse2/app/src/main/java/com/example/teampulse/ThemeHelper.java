package com.example.teampulse;

import android.content.Context;
import android.content.SharedPreferences;

import androidx.appcompat.app.AppCompatDelegate;

public class ThemeHelper {

    private static final String PREFS_NAME = "ThemePrefs";
    private static final String KEY_THEME = "theme_mode";

    // Using integers for modes to match AppCompatDelegate constants
    public static final int LIGHT_MODE = AppCompatDelegate.MODE_NIGHT_NO;
    public static final int DARK_MODE = AppCompatDelegate.MODE_NIGHT_YES;
    public static final int SYSTEM_DEFAULT = AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM;

    private final SharedPreferences sharedPreferences;

    public ThemeHelper(Context context) {
        sharedPreferences = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
    }

    public void applyTheme(int themeMode) {
        AppCompatDelegate.setDefaultNightMode(themeMode);
        saveTheme(themeMode);
    }

    public void saveTheme(int themeMode) {
        sharedPreferences.edit().putInt(KEY_THEME, themeMode).apply();
    }

    public int getSavedTheme() {
        // Return System Default if no theme has been saved yet
        return sharedPreferences.getInt(KEY_THEME, SYSTEM_DEFAULT);
    }
}