package com.example.teampulse;

import com.google.firebase.firestore.ServerTimestamp;
import java.util.Date;

public class ActivityLog {

    // An enum to define the different types of loggable events
    public enum EventType {
        PROJECT_CREATED,
        TASK_CREATED,
        TASK_STATUS_CHANGED,
        TASK_DELETED,
        MEMBER_JOINED
    }

    private String logMessage;
    private EventType eventType;
    private String authorName;
    private String authorUid;
    private String projectId;
    private @ServerTimestamp Date timestamp; // Firestore will automatically set the server time

    // Required empty constructor for Firestore
    public ActivityLog() {}

    public ActivityLog(String logMessage, EventType eventType, String authorName, String authorUid) {
        this.logMessage = logMessage;
        this.eventType = eventType;
        this.authorName = authorName;
        this.authorUid = authorUid;
    }

    // --- Getters and Setters ---
    public String getLogMessage() { return logMessage; }
    public void setLogMessage(String logMessage) { this.logMessage = logMessage; }

    public EventType getEventType() { return eventType; }
    public void setEventType(EventType eventType) { this.eventType = eventType; }

    public String getAuthorName() { return authorName; }
    public void setAuthorName(String authorName) { this.authorName = authorName; }

    public String getAuthorUid() { return authorUid; }
    public void setAuthorUid(String authorUid) { this.authorUid = authorUid; }
    public String getProjectId() { return projectId; }
    public void setProjectId(String projectId) { this.projectId = projectId; }

    public Date getTimestamp() { return timestamp; }
    public void setTimestamp(Date timestamp) { this.timestamp = timestamp; }
}