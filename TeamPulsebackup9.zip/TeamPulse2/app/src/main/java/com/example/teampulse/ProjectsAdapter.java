package com.example.teampulse;

import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.example.teampulse.databinding.ProjectCardBinding;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;

import java.util.List;

public class ProjectsAdapter extends RecyclerView.Adapter<ProjectsAdapter.ProjectViewHolder> {

    private final Context context;
    private final List<Project> projectList;
    private final FirebaseFirestore db;
    private String pinnedProjectId;
    private final OnProjectInteractionListener listener;

    public ProjectsAdapter(Context context, List<Project> projectList, OnProjectInteractionListener listener) {
        this.context = context;
        this.projectList = projectList;
        this.db = FirebaseFirestore.getInstance();
        this.listener = listener;
    }

    public void setPinnedProjectId(String pinnedProjectId) {
        this.pinnedProjectId = pinnedProjectId;
        notifyDataSetChanged();
    }

    interface OnProgressFetchedListener {
        void onFetched();
    }

    @NonNull
    @Override
    public ProjectViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        ProjectCardBinding binding = ProjectCardBinding.inflate(
                LayoutInflater.from(parent.getContext()), parent, false);
        return new ProjectViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull ProjectViewHolder holder, int position) {
        Project project = projectList.get(position);
        holder.bind(project);
    }

    @Override
    public void onViewRecycled(@NonNull ProjectViewHolder holder) {
        super.onViewRecycled(holder);
        holder.cancelTimer();
    }

    @Override
    public int getItemCount() {
        return projectList.size();
    }

    class ProjectViewHolder extends RecyclerView.ViewHolder {
        private final ProjectCardBinding binding;
        private final Handler detailsHandler = new Handler(Looper.getMainLooper());
        private Runnable hideDetailsRunnable;

        public ProjectViewHolder(ProjectCardBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }

        void bind(Project project) {
            binding.tvLeaderName.setText("Led by " + project.getLeaderName());
            binding.projectTitleText.setText(project.getTitle());
            binding.tvJoinCode.setText("Join Code: " + project.getJoinCode());

            // ✅ SET THE TEXT FOR THE NEW TEXTVIEW
            binding.tvTotalPoints.setText(project.getTotalPoints() + " Total Points");

            binding.projectDescriptionText.setText(project.getDescription());
            binding.projectDeadlineText.setText("Deadline: " + project.getDeadline());

            int progress = (int) project.getProgress();
            binding.projectProgressText.setText(progress + "%");
            binding.defaultProgressBar.setProgress(progress);

            cancelTimer();
            binding.progressBarSegmentsContainer.removeAllViews();
            binding.legendContainer.setVisibility(View.GONE);
            binding.btnShowDetails.setText("Show Progress");
            binding.btnShowDetails.setEnabled(true);

            binding.btnShowDetails.setOnClickListener(v -> {
                cancelTimer();
                if (binding.legendContainer.getVisibility() == View.VISIBLE) {
                    binding.progressBarSegmentsContainer.removeAllViews();
                    binding.legendContainer.setVisibility(View.GONE);
                    binding.btnShowDetails.setText("Show Progress");
                    return;
                }
                hideDetailsRunnable = () -> {
                    binding.progressBarSegmentsContainer.removeAllViews();
                    binding.legendContainer.setVisibility(View.GONE);
                    binding.btnShowDetails.setText("Show Progress");
                };
                if (binding.progressBarSegmentsContainer.getChildCount() == 0) {
                    binding.btnShowDetails.setText("Loading...");
                    binding.btnShowDetails.setEnabled(false);
                    fetchAndDisplaySegmentedProgress(project.getId(), binding.progressBarSegmentsContainer, binding.legendContainer, project.getTotalPoints(), () -> {
                        binding.btnShowDetails.setText("Hide Progress");
                        binding.btnShowDetails.setEnabled(true);
                        binding.legendContainer.setVisibility(View.VISIBLE);
                        detailsHandler.postDelayed(hideDetailsRunnable, 5000);
                    });
                } else {
                    binding.btnShowDetails.setText("Hide Progress");
                    binding.legendContainer.setVisibility(View.VISIBLE);
                    detailsHandler.postDelayed(hideDetailsRunnable, 5000);
                }
            });

            String currentUserId = FirebaseAuth.getInstance().getCurrentUser().getUid();
            binding.btnDeleteProject.setVisibility(currentUserId.equals(project.getLeaderId()) ? View.VISIBLE : View.GONE);
            binding.btnDeleteProject.setOnClickListener(v -> showDeleteConfirmation(project));

            binding.openProjectButton.setOnClickListener(v -> {
                Intent intent = new Intent(context, ProjectDetailsActivity.class);
                intent.putExtra("PROJECT_ID", project.getId());
                context.startActivity(intent);
            });

            if (project.getId().equals(pinnedProjectId)) {
                binding.btnPinProject.setImageResource(R.drawable.ic_pin_filled);
                binding.btnPinProject.setColorFilter(ContextCompat.getColor(context, R.color.blue));
            } else {
                binding.btnPinProject.setImageResource(R.drawable.ic_pin);
                binding.btnPinProject.setColorFilter(ContextCompat.getColor(context, R.color.gray));
            }
            binding.btnPinProject.setOnClickListener(v -> {
                String newPinnedId = project.getId().equals(pinnedProjectId) ? null : project.getId();
                if (listener != null) listener.onProjectPinChanged(newPinnedId);
            });
        }

        public void cancelTimer() {
            if (hideDetailsRunnable != null) {
                detailsHandler.removeCallbacks(hideDetailsRunnable);
            }
        }

        private void fetchAndDisplaySegmentedProgress(String projectId, LinearLayout progressBarContainer, com.google.android.flexbox.FlexboxLayout legendContainer, int totalProjectPoints, OnProgressFetchedListener onCompleteListener) {
            db.collection("projects").document(projectId).collection("tasks").get()
                    .addOnSuccessListener(taskSnapshots -> {
                        if (taskSnapshots.isEmpty()) {
                            if (onCompleteListener != null) onCompleteListener.onFetched();
                            return;
                        }
                        int completedResearchPoints = 0, completedDevPoints = 0, completedDocsPoints = 0, completedPresentPoints = 0;
                        for (QueryDocumentSnapshot doc : taskSnapshots) {
                            Task task = doc.toObject(Task.class);
                            if (task.getStatusEnum() == TaskStatus.DONE) {
                                int points = task.getPoints();
                                String type = task.getType() != null ? task.getType() : "";
                                switch (type) {
                                    case "Research": completedResearchPoints += points; break;
                                    case "Development": completedDevPoints += points; break;
                                    case "Documentation": completedDocsPoints += points; break;
                                    case "Presentation": completedPresentPoints += points; break;
                                }
                            }
                        }
                        if (totalProjectPoints == 0) {
                            if (onCompleteListener != null) onCompleteListener.onFetched();
                            return;
                        }
                        int researchPct = (int) (((double) completedResearchPoints / totalProjectPoints) * 100);
                        int devPct = (int) (((double) completedDevPoints / totalProjectPoints) * 100);
                        int docsPct = (int) (((double) completedDocsPoints / totalProjectPoints) * 100);
                        int presentPct = (int) (((double) completedPresentPoints / totalProjectPoints) * 100);
                        updateSegmentedProgressBar(progressBarContainer, researchPct, devPct, docsPct, presentPct);
                        updateLegend(legendContainer, researchPct, devPct, docsPct, presentPct);
                        if (onCompleteListener != null) onCompleteListener.onFetched();
                    })
                    .addOnFailureListener(e -> {
                        if (onCompleteListener != null) onCompleteListener.onFetched();
                    });
        }

        private void updateSegmentedProgressBar(LinearLayout container, int... percentages) {
            container.removeAllViews();
            int[] colors = {R.color.progress_research, R.color.progress_development, R.color.progress_documentation, R.color.progress_presentation};
            for (int i = 0; i < percentages.length; i++) {
                if (percentages[i] > 0) {
                    View view = new View(context);
                    LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, percentages[i]);
                    view.setLayoutParams(params);
                    GradientDrawable drawable = (GradientDrawable) ContextCompat.getDrawable(context, R.drawable.progress_bar_segment).mutate();
                    drawable.setColor(ContextCompat.getColor(context, colors[i]));
                    view.setBackground(drawable);
                    container.addView(view);
                }
            }
        }

        private void updateLegend(com.google.android.flexbox.FlexboxLayout legendContainer, int researchPct, int devPct, int docsPct, int presentPct) {
            legendContainer.removeAllViews();
            if (researchPct > 0) legendContainer.addView(createLegendItem(context, "Research", R.color.progress_research));
            if (devPct > 0) legendContainer.addView(createLegendItem(context, "Development", R.color.progress_development));
            if (docsPct > 0) legendContainer.addView(createLegendItem(context, "Documentation", R.color.progress_documentation));
            if (presentPct > 0) legendContainer.addView(createLegendItem(context, "Presentation", R.color.progress_presentation));
        }

        private LinearLayout createLegendItem(Context context, String label, int colorRes) {
            LinearLayout itemLayout = new LinearLayout(context);
            itemLayout.setOrientation(LinearLayout.HORIZONTAL);
            itemLayout.setGravity(Gravity.CENTER_VERTICAL);
            com.google.android.flexbox.FlexboxLayout.LayoutParams params = new com.google.android.flexbox.FlexboxLayout.LayoutParams(
                    com.google.android.flexbox.FlexboxLayout.LayoutParams.WRAP_CONTENT,
                    com.google.android.flexbox.FlexboxLayout.LayoutParams.WRAP_CONTENT);
            final float scale = context.getResources().getDisplayMetrics().density;
            int marginEndPx = (int) (16 * scale + 0.5f);
            int marginBottomPx = (int) (4 * scale + 0.5f);
            params.setMarginEnd(marginEndPx);
            params.bottomMargin = marginBottomPx;
            itemLayout.setLayoutParams(params);
            View colorBox = new View(context);
            int boxSize = (int) (12 * scale);
            LinearLayout.LayoutParams boxParams = new LinearLayout.LayoutParams(boxSize, boxSize);
            boxParams.setMarginEnd((int)(8 * scale));
            colorBox.setLayoutParams(boxParams);
            colorBox.setBackgroundColor(ContextCompat.getColor(context, colorRes));
            itemLayout.addView(colorBox);
            TextView textView = new TextView(context);
            textView.setText(label);
            textView.setTextSize(12);
            textView.setTextColor(ContextCompat.getColor(context, R.color.gray));
            itemLayout.addView(textView);
            return itemLayout;
        }

        private void showDeleteConfirmation(Project project) {
            new AlertDialog.Builder(context)
                    .setTitle("Delete Project")
                    .setMessage("Are you sure you want to delete '" + project.getTitle() + "'? This will delete all associated tasks and cannot be undone.")
                    .setPositiveButton("Delete", (dialog, which) -> deleteProjectFromFirestore(project))
                    .setNegativeButton("Cancel", null)
                    .show();
        }

        private void deleteProjectFromFirestore(Project project) {
            db.collection("projects").document(project.getId()).delete()
                    .addOnSuccessListener(aVoid -> {
                        Toast.makeText(context, "Project deleted.", Toast.LENGTH_SHORT).show();
                        if (listener != null) listener.onProjectDeleted();
                    })
                    .addOnFailureListener(e -> Toast.makeText(context, "Error deleting project.", Toast.LENGTH_SHORT).show());
        }
    }
}