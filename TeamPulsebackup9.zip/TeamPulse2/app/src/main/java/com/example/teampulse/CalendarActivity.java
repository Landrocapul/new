package com.example.teampulse;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.NonNull; // Add this if missing
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.example.teampulse.databinding.ActivityCalendarBinding;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.jakewharton.threetenabp.AndroidThreeTen;
import com.prolificinteractive.materialcalendarview.CalendarDay;
import com.prolificinteractive.materialcalendarview.MaterialCalendarView;
import com.prolificinteractive.materialcalendarview.OnDateSelectedListener;

import java.text.DateFormatSymbols;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.stream.Collectors;

public class CalendarActivity extends AppCompatActivity {

    private ActivityCalendarBinding binding;
    private FirebaseAuth mAuth;
    private FirebaseFirestore db;
    private String userRole;

    private List<Task> allTasks = new ArrayList<>();
    private Map<String, String> projectIdToTitleMap = new HashMap<>();
    private MyTasksAdapter tasksAdapter;
    private List<MyTasksListItem> displayedTasks = new ArrayList<>();

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        AndroidThreeTen.init(this);
        binding = ActivityCalendarBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        mAuth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();

        setSupportActionBar(binding.toolbar);

        setupRecyclerView();
        fetchUserRoleAndData();

        // ✅ CORRECTED METHOD: Use setOnDateChangedListener
        binding.calendarView.setOnDateChangedListener((widget, date, selected) -> {
            // In this version, the 'selected' boolean is part of the listener.
            // When a date is clicked, it's always considered selected.
            updateTasksForSelectedDate(date);
        });
    }

    private void setupRecyclerView() {
        tasksAdapter = new MyTasksAdapter(displayedTasks, this);
        binding.tasksRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        binding.tasksRecyclerView.setAdapter(tasksAdapter);
    }

    private void fetchUserRoleAndData() {
        FirebaseUser currentUser = mAuth.getCurrentUser();
        if (currentUser == null) {
            finish();
            return;
        }

        db.collection("users").document(currentUser.getUid()).get()
                .addOnSuccessListener(documentSnapshot -> {
                    if (documentSnapshot.exists()) {
                        userRole = documentSnapshot.getString("role");
                    }
                    setupBottomNavigation();
                    loadAllRelevantData();
                });
    }

    private void loadAllRelevantData() {
        FirebaseUser currentUser = mAuth.getCurrentUser();
        if (currentUser == null) return;

        db.collection("projects")
                .whereArrayContains("teamMembers", currentUser.getUid())
                .get()
                .addOnSuccessListener(projectSnapshots -> {
                    projectIdToTitleMap.clear();
                    List<String> projectIds = new ArrayList<>();
                    for (QueryDocumentSnapshot doc : projectSnapshots) {
                        projectIds.add(doc.getId());
                        projectIdToTitleMap.put(doc.getId(), doc.getString("title"));
                    }

                    if (projectIds.isEmpty() && !"Teacher".equals(userRole)) {
                        return;
                    }

                    fetchAllTasks(currentUser.getUid(), projectIds);
                });
    }

    private void fetchAllTasks(String userId, List<String> memberProjectIds) {
        Query.Direction direction = Query.Direction.ASCENDING;

        Query tasksQuery;
        if ("Teacher".equals(userRole)) {
            tasksQuery = db.collectionGroup("tasks").whereEqualTo("teacherId", userId);
        } else {
            tasksQuery = db.collectionGroup("tasks").whereEqualTo("assigneeUid", userId);
        }

        tasksQuery.orderBy("dueDate", direction).get()
                .addOnSuccessListener(taskSnapshots -> {
                    allTasks.clear();
                    for (QueryDocumentSnapshot doc : taskSnapshots) {
                        Task task = doc.toObject(Task.class);
                        task.setId(doc.getId());
                        String parentProjectId = doc.getReference().getParent().getParent().getId();
                        task.setProjectId(parentProjectId);
                        allTasks.add(task);
                    }

                    decorateCalendar();

                    // By default, show tasks for today
                    binding.calendarView.setSelectedDate(CalendarDay.today());
                    updateTasksForSelectedDate(CalendarDay.today());
                });
    }

    private void decorateCalendar() {
        HashSet<CalendarDay> eventDates = new HashSet<>();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");

        for (Task task : allTasks) {
            if (task.getDueDate() != null && !task.getDueDate().isEmpty()) {
                try {
                    LocalDate date = LocalDate.parse(task.getDueDate(), formatter);
                    // ✅ CORRECTED: The month is now 1-based (1-12)
                    eventDates.add(CalendarDay.from(date.getYear(), date.getMonthValue(), date.getDayOfMonth()));
                } catch (Exception e) {
                    // Ignore tasks with invalid date formats
                }
            }
        }

        binding.calendarView.addDecorator(new EventDecorator(Color.RED, eventDates));
    }

    private void updateTasksForSelectedDate(CalendarDay date) {
        // ✅ CORRECTED: The getMonth() method is now 1-based.
        String selectedDateString = String.format(Locale.US, "%04d-%02d-%02d", date.getYear(), date.getMonth(), date.getDay());

        // Format the date using the CalendarDay's date components
        String formattedDate = String.format(Locale.getDefault(), "%s %d, %d", 
            new DateFormatSymbols().getMonths()[date.getMonth() - 1],
            date.getDay(), 
            date.getYear());
        binding.tvSelectedDate.setText("Tasks for " + formattedDate);

        List<Task> tasksForDay = allTasks.stream()
                .filter(task -> selectedDateString.equals(task.getDueDate()))
                .collect(Collectors.toList());

        displayedTasks.clear();
        if (!tasksForDay.isEmpty()) {
            Map<String, List<Task>> tasksByProject = tasksForDay.stream()
                    .collect(Collectors.groupingBy(Task::getProjectId));

            for (String projectId : tasksByProject.keySet()) {
                String projectTitle = projectIdToTitleMap.get(projectId);
                if (projectTitle != null) {
                    displayedTasks.add(new ProjectHeaderItem(projectTitle));
                    tasksByProject.get(projectId).forEach(task -> displayedTasks.add(new TaskItem(task)));
                }
            }
        }

        tasksAdapter.notifyDataSetChanged();
    }

    private void clearTaskList() {
        binding.tvSelectedDate.setText("No date selected");
        displayedTasks.clear();
        tasksAdapter.notifyDataSetChanged();
    }

    private void setupBottomNavigation() {
        if ("Teacher".equals(userRole)) {
            binding.bottomNavigation.inflateMenu(R.menu.teacher_bottom_nav_menu);
        } else {
            binding.bottomNavigation.inflateMenu(R.menu.bottom_nav_menu);
        }

        binding.bottomNavigation.setSelectedItemId(R.id.nav_calendar);

        binding.bottomNavigation.setOnItemSelectedListener(item -> {
            int itemId = item.getItemId();
            if (itemId == R.id.nav_calendar) return true;
            if (itemId == R.id.nav_home) {
                Intent intent = new Intent(getApplicationContext(), "Teacher".equals(userRole) ? TeacherDashboardActivity.class : DashboardActivity.class);
                startActivity(intent);
                overridePendingTransition(0, 0);
                finish();
                return true;
            }
            if (itemId == R.id.nav_projects) {
                Intent intent = new Intent(getApplicationContext(), "Teacher".equals(userRole) ? TeacherProjectsActivity.class : ProjectsActivity.class);
                startActivity(intent);
                overridePendingTransition(0, 0);
                finish();
                return true;
            }
            if (itemId == R.id.nav_my_tasks) {
                startActivity(new Intent(getApplicationContext(), MyTasksActivity.class));
                overridePendingTransition(0, 0);
                finish();
                return true;
            }
            return false;
        });
    }
}