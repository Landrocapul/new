package com.example.teampulse;

import android.content.Context;
import android.content.Intent;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.SpannableString;
import android.text.style.StyleSpan;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.example.teampulse.databinding.ActivityProjectDetailsBinding;
import com.google.android.material.tabs.TabLayoutMediator;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class ProjectDetailsActivity extends AppCompatActivity implements OnTaskUpdatedListener {

    private ActivityProjectDetailsBinding binding;
    private FirebaseFirestore db;
    private FirebaseAuth mAuth;
    private String projectId;
    private Project currentProject;
    private List<Task> allTasks = new ArrayList<>();
    private KanbanPagerAdapter pagerAdapter;
    private String currentUserRole = "Member";

    interface OnTasksFetchedListener {
        void onFetched();
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityProjectDetailsBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        mAuth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();
        projectId = getIntent().getStringExtra("PROJECT_ID");
        if (projectId == null) {
            Toast.makeText(this, "No project ID provided", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }
        setupToolbar();
        binding.btnViewMembers.setOnClickListener(v -> showProjectMenuDialog());
    }

    @Override
    protected void onResume() {
        super.onResume();
        fetchCurrentUserRoleAndData();
    }

    private void setupToolbar() {
        setSupportActionBar(binding.toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle(null);
        }
    }

    private void setupFabBasedOnRole() {
        binding.fabAddTask.setVisibility("Leader".equals(currentUserRole) ? View.VISIBLE : View.GONE);
        binding.fabAddTask.setOnClickListener(v -> {
            Intent intent = new Intent(this, CreateTaskActivity.class);
            intent.putExtra("PROJECT_ID", projectId);
            startActivity(intent);
        });
    }

    @Override
    public void onTaskUpdated() {
        int currentTab = binding.viewPager.getCurrentItem();
        fetchProjectTasks(() -> {
            binding.viewPager.post(() -> binding.viewPager.setCurrentItem(currentTab, false));
        });
    }

    private void fetchProjectDetails() {
        db.collection("projects").document(projectId).get()
                .addOnSuccessListener(documentSnapshot -> {
                    if (documentSnapshot.exists()) {
                        currentProject = documentSnapshot.toObject(Project.class);
                        if (currentProject != null) {
                            populateHeader(currentProject);
                        }
                    } else {
                        Toast.makeText(this, "Project data not found.", Toast.LENGTH_SHORT).show();
                    }
                })
                .addOnFailureListener(e -> Toast.makeText(this, "Error fetching project details.", Toast.LENGTH_SHORT).show());
    }

    private void populateHeader(Project project) {
        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle(project.getTitle());
        }
        binding.headerProjectTitle.setText(project.getTitle());
        binding.headerProjectJoinCode.setText("Join Code: " + project.getJoinCode());
        binding.headerProjectDescription.setText(project.getDescription());
        binding.headerProjectDeadline.setText("Deadline: " + project.getDeadline());
    }

    private void fetchProjectTasks(OnTasksFetchedListener listener) {
        db.collection("projects").document(projectId).collection("tasks").get()
                .addOnSuccessListener(queryDocumentSnapshots -> {
                    allTasks.clear();
                    for (QueryDocumentSnapshot doc : queryDocumentSnapshots) {
                        Task task = doc.toObject(Task.class);
                        task.setId(doc.getId());
                        allTasks.add(task);
                    }
                    setupViewPagerAndTabs();
                    calculateAndDisplayProgress();
                    if (listener != null) {
                        listener.onFetched();
                    }
                })
                .addOnFailureListener(e -> Toast.makeText(this, "Failed to load tasks: " + e.getMessage(), Toast.LENGTH_SHORT).show());
    }

    private void setupViewPagerAndTabs() {
        List<Task> planningTasks = allTasks.stream().filter(t -> t.getStatusEnum() == TaskStatus.PLANNING).collect(Collectors.toList());
        List<Task> inProgressTasks = allTasks.stream().filter(t -> t.getStatusEnum() == TaskStatus.IN_PROGRESS).collect(Collectors.toList());
        List<Task> forReviewTasks = allTasks.stream().filter(t -> t.getStatusEnum() == TaskStatus.FOR_REVIEW).collect(Collectors.toList());
        List<Task> doneTasks = allTasks.stream().filter(t -> t.getStatusEnum() == TaskStatus.DONE).collect(Collectors.toList());

        pagerAdapter = new KanbanPagerAdapter(this, planningTasks, inProgressTasks, forReviewTasks, doneTasks, projectId, currentUserRole);
        binding.viewPager.setAdapter(pagerAdapter);

        new TabLayoutMediator(binding.tabLayout, binding.viewPager, (tab, position) -> {
            switch (position) {
                case 0: tab.setText("PLANNING (" + planningTasks.size() + ")"); break;
                case 1: tab.setText("IN PROGRESS (" + inProgressTasks.size() + ")"); break;
                case 2: tab.setText("FOR REVIEW (" + forReviewTasks.size() + ")"); break;
                case 3: tab.setText("DONE (" + doneTasks.size() + ")"); break;
            }
        }).attach();
    }

    private void calculateAndDisplayProgress() {
        int totalProjectPoints = (currentProject != null) ? currentProject.getTotalPoints() : 0;
        String pointsText = "0 / " + totalProjectPoints + " Pts";

        if (allTasks.isEmpty() || totalProjectPoints == 0) {
            updateProjectProgressInFirestore(0);
            updateSegmentedProgressBar(0, 0, 0, 0);
            binding.headerProgressText.setText("0%");
            binding.headerPointsText.setText(pointsText); // ✅ Set default text
            updateLegend(0, 0, 0, 0);
            return;
        }

        int completedPoints = 0;
        int completedResearchPoints = 0, completedDevPoints = 0, completedDocsPoints = 0, completedPresentPoints = 0;

        for (Task task : allTasks) {
            if (task.getStatusEnum() == TaskStatus.DONE) {
                int points = task.getPoints();
                completedPoints += points;
                String type = task.getType() != null ? task.getType() : "";
                switch (type) {
                    case "Research": completedResearchPoints += points; break;
                    case "Development": completedDevPoints += points; break;
                    case "Documentation": completedDocsPoints += points; break;
                    case "Presentation": completedPresentPoints += points; break;
                }
            }
        }

        int totalPercent = (int) (((double) completedPoints / totalProjectPoints) * 100);
        pointsText = completedPoints + " / " + totalProjectPoints + " Pts"; // ✅ Update with real values

        int researchPct = (int) (((double) completedResearchPoints / totalProjectPoints) * 100);
        int devPct = (int) (((double) completedDevPoints / totalProjectPoints) * 100);
        int docsPct = (int) (((double) completedDocsPoints / totalProjectPoints) * 100);
        int presentPct = (int) (((double) completedPresentPoints / totalProjectPoints) * 100);

        updateProjectProgressInFirestore(totalPercent);
        updateSegmentedProgressBar(researchPct, devPct, docsPct, presentPct);
        binding.headerProgressText.setText(totalPercent + "%");
        binding.headerPointsText.setText(pointsText); // ✅ Set the new text
        updateLegend(researchPct, devPct, docsPct, presentPct);
    }

    private void updateProjectProgressInFirestore(int progress) {
        if (projectId != null) {
            db.collection("projects").document(projectId).update("progress", progress)
                    .addOnFailureListener(e -> System.err.println("Failed to update progress: " + e.getMessage()));
        }
    }

    private void updateSegmentedProgressBar(int... percentages) {
        binding.progressBarSegmentsContainer.removeAllViews();
        int[] colors = {R.color.progress_research, R.color.progress_development, R.color.progress_documentation, R.color.progress_presentation};
        for (int i = 0; i < percentages.length; i++) {
            if (percentages[i] > 0) {
                View view = new View(this);
                LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, percentages[i]);
                view.setLayoutParams(params);
                GradientDrawable drawable = (GradientDrawable) ContextCompat.getDrawable(this, R.drawable.progress_bar_segment).mutate();
                drawable.setColor(ContextCompat.getColor(this, colors[i]));
                view.setBackground(drawable);
                binding.progressBarSegmentsContainer.addView(view);
            }
        }
    }

    private LinearLayout createLegendItem(Context context, String label, int colorRes) {
        LinearLayout itemLayout = new LinearLayout(context);
        itemLayout.setOrientation(LinearLayout.HORIZONTAL);
        itemLayout.setGravity(Gravity.CENTER_VERTICAL);
        com.google.android.flexbox.FlexboxLayout.LayoutParams params = new com.google.android.flexbox.FlexboxLayout.LayoutParams(
                com.google.android.flexbox.FlexboxLayout.LayoutParams.WRAP_CONTENT,
                com.google.android.flexbox.FlexboxLayout.LayoutParams.WRAP_CONTENT);
        final float scale = getResources().getDisplayMetrics().density;
        int marginEndPx = (int) (16 * scale + 0.5f);
        int marginBottomPx = (int) (4 * scale + 0.5f);
        params.setMarginEnd(marginEndPx);
        params.bottomMargin = marginBottomPx;
        itemLayout.setLayoutParams(params);
        View colorBox = new View(context);
        int boxSize = (int) (12 * scale);
        LinearLayout.LayoutParams boxParams = new LinearLayout.LayoutParams(boxSize, boxSize);
        boxParams.setMarginEnd((int) (8 * scale));
        colorBox.setLayoutParams(boxParams);
        colorBox.setBackgroundColor(ContextCompat.getColor(context, colorRes));
        itemLayout.addView(colorBox);
        TextView textView = new TextView(context);
        textView.setText(label);
        textView.setTextSize(12);
        textView.setTextColor(ContextCompat.getColor(context, R.color.gray));
        itemLayout.addView(textView);
        return itemLayout;
    }

    private void updateLegend(int researchPct, int devPct, int docsPct, int presentPct) {
        binding.legendContainer.removeAllViews();
        if (researchPct > 0) binding.legendContainer.addView(createLegendItem(this, "Research", R.color.progress_research));
        if (devPct > 0) binding.legendContainer.addView(createLegendItem(this, "Development", R.color.progress_development));
        if (docsPct > 0) binding.legendContainer.addView(createLegendItem(this, "Documentation", R.color.progress_documentation));
        if (presentPct > 0) binding.legendContainer.addView(createLegendItem(this, "Presentation", R.color.progress_presentation));
    }
    private void showProjectMenuDialog() {
        final CharSequence[] options = {"View Members", "View Activity Log"};

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Project Options");
        builder.setItems(options, (dialog, item) -> {
            if (options[item].equals("View Members")) {
                // Existing logic to show members
                showMembersList();
            } else if (options[item].equals("View Activity Log")) {
                // Action to open the new ActivityLogActivity
                Intent intent = new Intent(this, ActivityLogActivity.class);
                intent.putExtra("PROJECT_ID", projectId);
                startActivity(intent);
            }
        });
        builder.show();
    }
    private void showMembersList() {
        if (currentProject == null || currentProject.getTeamMembers() == null || currentProject.getTeamMembers().isEmpty()) {
            Toast.makeText(this, "No members found for this project.", Toast.LENGTH_SHORT).show();
            return;
        }
        List<String> memberUids = currentProject.getTeamMembers();
        db.collection("users").whereIn("uid", memberUids).get()
                .addOnSuccessListener(queryDocumentSnapshots -> {
                    if (queryDocumentSnapshots.isEmpty()) {
                        Toast.makeText(this, "Could not retrieve member details.", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    List<User> members = queryDocumentSnapshots.toObjects(User.class);
                    ArrayList<CharSequence> displayList = new ArrayList<>();
                    for (User member : members) {
                        String memberInfo = member.getName() + " (" + member.getRole() + ")";
                        SpannableString spannableString = new SpannableString(memberInfo);
                        int startIndex = member.getName().length() + 2;
                        int endIndex = memberInfo.length() - 1;
                        spannableString.setSpan(new StyleSpan(Typeface.BOLD), startIndex, endIndex, 0);
                        displayList.add(spannableString);
                    }
                    new AlertDialog.Builder(this)
                            .setTitle("Project Members")
                            .setItems(displayList.toArray(new CharSequence[0]), null)
                            .setPositiveButton("Close", null)
                            .show();
                })
                .addOnFailureListener(e -> Toast.makeText(this, "Error fetching members: " + e.getMessage(), Toast.LENGTH_SHORT).show());
    }




    private void fetchCurrentUserRoleAndData() {
        FirebaseUser currentUser = mAuth.getCurrentUser();
        if (currentUser == null) {
            finish();
            return;
        }
        db.collection("users").document(currentUser.getUid()).get()
                .addOnSuccessListener(doc -> {
                    if (doc.exists()) {
                        this.currentUserRole = doc.getString("role");
                    }
                    setupFabBasedOnRole();
                    fetchProjectDetails();
                    fetchProjectTasks(null);
                })
                .addOnFailureListener(e -> {
                    setupFabBasedOnRole();
                    fetchProjectDetails();
                    fetchProjectTasks(null);
                });
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }
}