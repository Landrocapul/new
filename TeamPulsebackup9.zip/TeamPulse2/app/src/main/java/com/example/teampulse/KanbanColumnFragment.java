package com.example.teampulse;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.example.teampulse.databinding.FragmentKanbanColumnBinding;

import java.io.Serializable;
import java.util.List;

public class KanbanColumnFragment extends Fragment {

    private static final String ARG_TASKS = "tasks";
    private static final String ARG_PROJECT_ID = "projectId";
    private static final String ARG_USER_ROLE = "userRole";

    private FragmentKanbanColumnBinding binding;
    private List<Task> taskList;
    private String projectId;
    private String currentUserRole;
    private OnTaskUpdatedListener listener; // Will be set in onAttach

    // ✅ FACTORY METHOD IS NOW CORRECT (No listener argument)
    public static KanbanColumnFragment newInstance(List<Task> tasks, String projectId, String userRole) {
        KanbanColumnFragment fragment = new KanbanColumnFragment();
        Bundle args = new Bundle();
        args.putSerializable(ARG_TASKS, (Serializable) tasks);
        args.putString(ARG_PROJECT_ID, projectId);
        args.putString(ARG_USER_ROLE, userRole);
        fragment.setArguments(args);
        return fragment;
    }

    // ✅ THIS IS THE KEY: GET THE LISTENER FROM THE HOSTING ACTIVITY'S CONTEXT
    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        if (context instanceof OnTaskUpdatedListener) {
            listener = (OnTaskUpdatedListener) context;
        } else {
            throw new RuntimeException(context.toString() + " must implement OnTaskUpdatedListener");
        }
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            taskList = (List<Task>) getArguments().getSerializable(ARG_TASKS);
            projectId = getArguments().getString(ARG_PROJECT_ID);
            currentUserRole = getArguments().getString(ARG_USER_ROLE);
        }
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        binding = FragmentKanbanColumnBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        binding.tasksRecyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        // The listener is now guaranteed to be valid here
        KanbanTaskAdapter adapter = new KanbanTaskAdapter(taskList, projectId, currentUserRole, listener);
        binding.tasksRecyclerView.setAdapter(adapter);
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

    @Override
    public void onDetach() {
        super.onDetach();
        // Clean up the reference to avoid memory leaks
        listener = null;
    }
}