package com.example.teampulse;

public interface MyTasksListItem { }