package com.example.teampulse;

import android.app.DatePickerDialog;
import android.os.Bundle;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

import com.example.teampulse.databinding.ActivityCreateProjectBinding;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

public class CreateProjectActivity extends AppCompatActivity {

    private ActivityCreateProjectBinding binding;
    private FirebaseFirestore db;
    private FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityCreateProjectBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        setSupportActionBar(binding.toolbar);
        binding.toolbar.setNavigationOnClickListener(v -> finish());

        db = FirebaseFirestore.getInstance();
        mAuth = FirebaseAuth.getInstance();

        binding.projectDeadlineEditText.setOnClickListener(v -> showDatePicker());
        binding.createProjectButton.setOnClickListener(v -> createProject());
        binding.cancelProjectButton.setOnClickListener(v -> finish());
    }

    private void createProject() {
        String title = binding.projectTitleEditText.getText().toString().trim();
        String description = binding.projectDescriptionEditText.getText().toString().trim();
        String deadline = binding.projectDeadlineEditText.getText().toString().trim();
        String joinCode = binding.projectJoinCodeEditText.getText().toString().trim();
        String totalPointsStr = binding.projectTotalPointsEditText.getText().toString().trim();

        if (title.isEmpty() || description.isEmpty() || deadline.isEmpty() || totalPointsStr.isEmpty()) {
            Toast.makeText(this, "Please fill all required fields", Toast.LENGTH_SHORT).show();
            return;
        }

        int totalPoints = Integer.parseInt(totalPointsStr);
        FirebaseUser currentUser = mAuth.getCurrentUser();
        if (currentUser == null) {
            Toast.makeText(this, "User not signed in", Toast.LENGTH_SHORT).show();
            return;
        }
        String leaderId = currentUser.getUid();

        db.collection("users").document(leaderId).get()
                .addOnSuccessListener(documentSnapshot -> {
                    if (documentSnapshot.exists()) {
                        String leaderName = documentSnapshot.getString("name");
                        String teacherId = documentSnapshot.getString("teacherId");

                        String finalJoinCode = joinCode.isEmpty() ?
                                UUID.randomUUID().toString().substring(0, 6).toUpperCase() :
                                joinCode.toUpperCase();

                        Map<String, Object> project = new HashMap<>();
                        project.put("title", title);
                        project.put("description", description);
                        project.put("leaderId", leaderId);
                        project.put("leaderName", leaderName);
                        project.put("createdDate", new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date()));
                        project.put("deadline", deadline);
                        project.put("joinCode", finalJoinCode);
                        project.put("progress", 0);
                        project.put("teamMembers", java.util.Arrays.asList(leaderId));
                        project.put("totalPoints", totalPoints);

                        if (teacherId != null) {
                            project.put("teacherId", teacherId);
                        }

                        // ✅ THE CORRECTED LOGIC
                        // 1. Create a new document reference in the 'projects' collection.
                        //    This generates a unique ID on the client-side before sending data.
                        DocumentReference newProjectRef = db.collection("projects").document();
                        String newProjectId = newProjectRef.getId(); // Get the auto-generated ID

                        // 2. Set the data on that specific document reference.
                        newProjectRef.set(project)
                                .addOnSuccessListener(aVoid -> {
                                    // 3. Now that the project is saved, log the activity using the ID.
                                    String logMessage = "created the project '" + title + "'.";
                                    LogHelper.logActivity(newProjectId, logMessage, ActivityLog.EventType.PROJECT_CREATED);

                                    Toast.makeText(this, "Project created successfully!", Toast.LENGTH_SHORT).show();
                                    finish();
                                })
                                .addOnFailureListener(e -> Toast.makeText(this, "Error: " + e.getMessage(), Toast.LENGTH_SHORT).show());
                    } else {
                        Toast.makeText(this, "Failed to get leader info", Toast.LENGTH_SHORT).show();
                    }
                })
                .addOnFailureListener(e -> Toast.makeText(this, "Failed to get leader info: " + e.getMessage(), Toast.LENGTH_SHORT).show());
    }

    private void showDatePicker() {
        final Calendar calendar = Calendar.getInstance();
        DatePickerDialog datePickerDialog = new DatePickerDialog(
                this,
                (view, year, month, dayOfMonth) -> {
                    String date = String.format(Locale.getDefault(), "%04d-%02d-%02d",
                            year, month + 1, dayOfMonth);
                    binding.projectDeadlineEditText.setText(date);
                },
                calendar.get(Calendar.YEAR),
                calendar.get(Calendar.MONTH),
                calendar.get(Calendar.DAY_OF_MONTH)
        );
        datePickerDialog.show();
    }
}