package com.example.teampulse;

import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SwitchCompat;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import com.example.teampulse.databinding.ActivityMyTasksBinding;
import com.google.android.gms.tasks.Task;
import com.google.android.gms.tasks.Tasks;
import com.google.android.material.navigation.NavigationView;
import com.google.android.material.tabs.TabLayoutMediator;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

    public class MyTasksActivity extends AppCompatActivity {

        private ActivityMyTasksBinding binding;
        private FirebaseAuth mAuth;
        private FirebaseFirestore db;
        private Map<String, String> projectIdToTitleMap = new HashMap<>();
        private String currentUserRole = "";

        // ✅ Drawer components
        private DrawerLayout drawerLayout;
        private NavigationView navigationView;
        private ActionBarDrawerToggle toggle;
        private ThemeHelper themeHelper;

        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            binding = ActivityMyTasksBinding.inflate(getLayoutInflater());
            setContentView(binding.getRoot());

            mAuth = FirebaseAuth.getInstance();
            db = FirebaseFirestore.getInstance();
            themeHelper = new ThemeHelper(this);

            setupViews();
            setupToolbarAndDrawer();
            setupBottomNavigation();
        }

        // ✅ NEW method to initialize drawer views
        private void setupViews() {
            drawerLayout = findViewById(R.id.drawer_layout);
            navigationView = findViewById(R.id.nav_view);
        }

        // ✅ NEW method to set up the drawer
        private void setupToolbarAndDrawer() {
            setSupportActionBar(binding.toolbar);
            toggle = new ActionBarDrawerToggle(this, drawerLayout, binding.toolbar,
                    R.string.navigation_drawer_open, R.string.navigation_drawer_close);
            drawerLayout.addDrawerListener(toggle);
            toggle.syncState();

            fetchHeaderData();
            setupThemeSwitch();

            navigationView.setNavigationItemSelectedListener(item -> {
                int id = item.getItemId();
                if (id == R.id.nav_drawer_logout) {
                    logoutUser();
                } else if (id == R.id.nav_drawer_profile) {
                    startActivity(new Intent(this, ProfileActivity.class));
                } else if (id == R.id.nav_drawer_activity_log) {
                    startActivity(new Intent(this, GlobalLogActivity.class));
                } else if (id == R.id.nav_drawer_settings) {
                    Toast.makeText(this, "Settings screen coming soon!", Toast.LENGTH_SHORT).show();
                }
                if (id != R.id.nav_drawer_dark_mode) {
                    drawerLayout.closeDrawer(GravityCompat.START);
                }
                return true;
            });
        }

        private void fetchHeaderData() {
            FirebaseUser user = mAuth.getCurrentUser();
            if (user != null) {
                View headerView = navigationView.getHeaderView(0);
                TextView headerUserName = headerView.findViewById(R.id.header_user_name);
                TextView headerUserEmail = headerView.findViewById(R.id.header_user_email);
                headerUserEmail.setText(user.getEmail());
                db.collection("users").document(user.getUid()).get().addOnSuccessListener(doc -> {
                    if (doc.exists()) {
                        headerUserName.setText(doc.getString("name"));
                    }
                });
            }
        }

        private void setupThemeSwitch() {
            MenuItem darkModeItem = navigationView.getMenu().findItem(R.id.nav_drawer_dark_mode);
            View actionView = darkModeItem.getActionView();
            if (actionView != null) {
                SwitchCompat darkModeSwitch = actionView.findViewById(R.id.drawer_switch);
                int currentNightMode = getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK;
                darkModeSwitch.setChecked(currentNightMode == Configuration.UI_MODE_NIGHT_YES);
                darkModeSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> {
                    themeHelper.applyTheme(isChecked ? ThemeHelper.DARK_MODE : ThemeHelper.LIGHT_MODE);
                });
            }
        }

        private void logoutUser() {
            mAuth.signOut();
            Intent intent = new Intent(this, SignInActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            finish();
        }

        // ✅ NEW methods to handle the toolbar menu
        @Override
        public boolean onCreateOptionsMenu(Menu menu) {
            getMenuInflater().inflate(R.menu.dashboard_menu, menu);
            return true;
        }

        @Override
        public boolean onPrepareOptionsMenu(Menu menu) {
            FirebaseUser currentUser = mAuth.getCurrentUser();
            if (currentUser != null) {
                db.collection("users").document(currentUser.getUid()).get()
                        .addOnSuccessListener(documentSnapshot -> {
                            if (documentSnapshot.exists()) {
                                String name = documentSnapshot.getString("name");
                                MenuItem profileItem = menu.findItem(R.id.action_profile);
                                if (profileItem != null) {
                                    View actionView = profileItem.getActionView();
                                    if (actionView != null) {
                                        TextView avatarTextView = actionView.findViewById(R.id.avatar_text);
                                        if (name != null && !name.isEmpty()) {
                                            String[] names = name.split(" ");
                                            String initials = "";
                                            if (names.length > 0) initials += names[0].charAt(0);
                                            if (names.length > 1) initials += names[names.length - 1].charAt(0);
                                            avatarTextView.setText(initials.toUpperCase());
                                        }
                                        actionView.setOnClickListener(v -> onOptionsItemSelected(profileItem));
                                    }
                                }
                            }
                        });
            }
            return super.onPrepareOptionsMenu(menu);
        }

        @Override
        public boolean onOptionsItemSelected(@NonNull MenuItem item) {
            if (toggle.onOptionsItemSelected(item)) {
                return true;
            }
            int itemId = item.getItemId();
            if (itemId == R.id.action_profile) {
                startActivity(new Intent(this, ProfileActivity.class));
                return true;
            }
            return super.onOptionsItemSelected(item);
        }

        // --- (The rest of your existing MyTasksActivity methods are unchanged) ---

        @Override
        protected void onResume() {
            super.onResume();
            loadProjectMapAndUserData();
        }

    private void loadProjectMapAndUserData() {
        FirebaseUser currentUser = mAuth.getCurrentUser();
        if (currentUser == null) {
            startActivity(new Intent(this, SignInActivity.class));
            finish();
            return;
        }

        db.collection("users").document(currentUser.getUid()).get()
                .addOnSuccessListener(userDoc -> {
                    if (userDoc.exists()) {
                        currentUserRole = userDoc.getString("role");
                    }

                    db.collection("projects").whereArrayContains("teamMembers", currentUser.getUid()).get()
                            .addOnSuccessListener(projectSnapshots -> {
                                projectIdToTitleMap.clear();
                                for (com.google.firebase.firestore.QueryDocumentSnapshot doc : projectSnapshots) {
                                    projectIdToTitleMap.put(doc.getId(), doc.getString("title"));
                                }
                                loadAllRelevantTasks(currentUser.getUid());
                            })
                            .addOnFailureListener(e -> Toast.makeText(this, "Could not load project list.", Toast.LENGTH_SHORT).show());
                })
                .addOnFailureListener(e -> {
                    Toast.makeText(this, "Could not load user data.", Toast.LENGTH_SHORT).show();
                    loadAllRelevantTasks(currentUser.getUid());
                });
    }

    private void loadAllRelevantTasks(String uid) {
        Task<QuerySnapshot> assignedTasksQuery = db.collectionGroup("tasks")
                .whereEqualTo("assigneeUid", uid)
                .get();

        List<Task<QuerySnapshot>> allQueries = new ArrayList<>();
        allQueries.add(assignedTasksQuery);

        if ("Leader".equals(currentUserRole)) {
            List<String> leaderProjectIds = new ArrayList<>();
            db.collection("projects").whereEqualTo("leaderId", uid).get()
                    .addOnSuccessListener(projectSnapshots -> {
                        for (com.google.firebase.firestore.QueryDocumentSnapshot doc : projectSnapshots) {
                            leaderProjectIds.add(doc.getId());
                        }

                        if (!leaderProjectIds.isEmpty()) {
                            Task<QuerySnapshot> reviewTasksQuery = db.collectionGroup("tasks")
                                    .whereIn("projectId", leaderProjectIds)
                                    .whereEqualTo("status", "FOR_REVIEW")
                                    .get();
                            allQueries.add(reviewTasksQuery);
                        }
                        processTaskQueries(allQueries);
                    });
        } else {
            processTaskQueries(allQueries);
        }
    }

    private void processTaskQueries(List<Task<QuerySnapshot>> queries) {
        Tasks.whenAllSuccess(queries).addOnSuccessListener(results -> {
            Map<String, com.example.teampulse.Task> uniqueTasksMap = new HashMap<>();

            for (Object result : results) {
                QuerySnapshot snapshot = (QuerySnapshot) result;
                for (com.google.firebase.firestore.QueryDocumentSnapshot doc : snapshot) {
                    com.example.teampulse.Task task = doc.toObject(com.example.teampulse.Task.class);
                    task.setId(doc.getId());
                    task.setProjectId(doc.getReference().getParent().getParent().getId());
                    uniqueTasksMap.put(task.getId(), task);
                }
            }

            List<com.example.teampulse.Task> allTasks = new ArrayList<>(uniqueTasksMap.values());
            filterAndDisplayTasks(allTasks);

        }).addOnFailureListener(e -> {
            Toast.makeText(this, "Failed to load tasks. Check Firestore index.", Toast.LENGTH_LONG).show();
            System.err.println("Firestore Query Error: " + e.getMessage());
        });
    }

    private void filterAndDisplayTasks(List<com.example.teampulse.Task> allTasks) {
        List<com.example.teampulse.Task> ongoingTasks = allTasks.stream()
                .filter(t -> t.getStatusEnum() == TaskStatus.PLANNING || t.getStatusEnum() == TaskStatus.IN_PROGRESS)
                .collect(Collectors.toList());

        List<com.example.teampulse.Task> reviewTasks = allTasks.stream()
                .filter(t -> t.getStatusEnum() == TaskStatus.FOR_REVIEW)
                .collect(Collectors.toList());

        List<com.example.teampulse.Task> completedTasks = allTasks.stream()
                .filter(t -> t.getStatusEnum() == TaskStatus.DONE)
                .collect(Collectors.toList());

        setupViewPagerAndTabs(ongoingTasks, reviewTasks, completedTasks);
    }

    private void setupViewPagerAndTabs(List<com.example.teampulse.Task> ongoing, List<com.example.teampulse.Task> review, List<com.example.teampulse.Task> completed) {
        MyTasksPagerAdapter pagerAdapter = new MyTasksPagerAdapter(this, ongoing, review, completed, projectIdToTitleMap);
        binding.viewPager.setAdapter(pagerAdapter);

        new TabLayoutMediator(binding.tabLayout, binding.viewPager, (tab, position) -> {
            switch (position) {
                case 0:
                    tab.setText("Ongoing (" + ongoing.size() + ")");
                    break;
                case 1:
                    tab.setText("To Review (" + review.size() + ")");
                    break;
                case 2:
                    tab.setText("Completed (" + completed.size() + ")");
                    break;
            }
        }).attach();
    }

    private void setupBottomNavigation() {
        binding.bottomNavigation.setSelectedItemId(R.id.nav_my_tasks);
        binding.bottomNavigation.setOnItemSelectedListener(item -> {
            int itemId = item.getItemId();
            if (itemId == R.id.nav_my_tasks) {
                return true;
            }
            if (itemId == R.id.nav_projects) {
                startActivity(new Intent(getApplicationContext(), ProjectsActivity.class));
                overridePendingTransition(0, 0);
                finish();
                return true;
            }
            if (itemId == R.id.nav_home) {
                FirebaseUser user = mAuth.getCurrentUser();
                if (user != null) {
                    db.collection("users").document(user.getUid()).get().addOnSuccessListener(doc -> {
                        Intent intent;
                        String role = doc.getString("role");
                        // ✅ CORRECTED LOGIC
                        if ("Leader".equals(role) || "Member".equals(role)) {
                            // Both roles now go to the unified DashboardActivity
                            intent = new Intent(getApplicationContext(), DashboardActivity.class);
                        }
//                        else if (itemId == R.id.nav_calendar) {
//                            startActivity(new Intent(getApplicationContext(), CalendarActivity.class));
//                            overridePendingTransition(0, 0);
//                            finish();
//                            return true;
//                        }
                        else {
                            // Fallback for any other role (like Teacher)
                            intent = new Intent(getApplicationContext(), TeacherDashboardActivity.class);
                        }
                        startActivity(intent);
                        overridePendingTransition(0, 0);
                        finish();
                    });
                }
                return true;
            }
            return false;
        });
    }
}