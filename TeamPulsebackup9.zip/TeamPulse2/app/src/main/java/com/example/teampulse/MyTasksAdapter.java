package com.example.teampulse;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.example.teampulse.databinding.ListItemMyTaskBinding;
import com.example.teampulse.databinding.ListItemProjectHeaderBinding;

import java.util.List;

public class MyTasksAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private static final int TYPE_HEADER = 0;
    private static final int TYPE_TASK = 1;

    private final List<MyTasksListItem> items;
    private final Context context;

    public MyTasksAdapter(List<MyTasksListItem> items, Context context) {
        this.items = items;
        this.context = context;
    }

    @Override
    public int getItemViewType(int position) {
        if (items.get(position) instanceof ProjectHeaderItem) {
            return TYPE_HEADER;
        } else {
            return TYPE_TASK;
        }
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        if (viewType == TYPE_HEADER) {
            ListItemProjectHeaderBinding binding = ListItemProjectHeaderBinding.inflate(
                    LayoutInflater.from(parent.getContext()), parent, false);
            return new ProjectHeaderViewHolder(binding);
        } else {
            ListItemMyTaskBinding binding = ListItemMyTaskBinding.inflate(
                    LayoutInflater.from(parent.getContext()), parent, false);
            return new TaskViewHolder(binding);
        }
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        if (holder.getItemViewType() == TYPE_HEADER) {
            ProjectHeaderItem headerItem = (ProjectHeaderItem) items.get(position);
            ((ProjectHeaderViewHolder) holder).bind(headerItem);
        } else {
            TaskItem taskItem = (TaskItem) items.get(position);
            ((TaskViewHolder) holder).bind(taskItem);
        }
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    // ViewHolder for Project Headers
    static class ProjectHeaderViewHolder extends RecyclerView.ViewHolder {
        private final ListItemProjectHeaderBinding binding;
        ProjectHeaderViewHolder(ListItemProjectHeaderBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }
        void bind(ProjectHeaderItem headerItem) {
            binding.tvProjectTitle.setText(headerItem.getProjectTitle());
        }
    }

    // ViewHolder for Task Items
    class TaskViewHolder extends RecyclerView.ViewHolder {
        private final ListItemMyTaskBinding binding;
        TaskViewHolder(ListItemMyTaskBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }
        void bind(TaskItem taskItem) {
            Task task = taskItem.getTask();
            binding.tvTaskTitle.setText(task.getTitle());
            binding.tvTaskDueDate.setText("Due: " + task.getDueDate());

            // Set status text and color
            String statusText = task.getStatus().replace("_", " ");
            binding.chipTaskStatus.setText(statusText);

            int colorRes = R.color.done_green;
            switch(task.getStatusEnum()) {
                case PLANNING: colorRes = R.color.planning_blue; break;
                case IN_PROGRESS: colorRes = R.color.inprogress_pink; break;
                case FOR_REVIEW: colorRes = R.color.yellow; break;
            }
            binding.chipTaskStatus.setChipBackgroundColorResource(colorRes);

            itemView.setOnClickListener(v -> {
                Intent intent = new Intent(context, ProjectDetailsActivity.class);
                intent.putExtra("PROJECT_ID", task.getProjectId());
                context.startActivity(intent);
            });
        }
    }
}