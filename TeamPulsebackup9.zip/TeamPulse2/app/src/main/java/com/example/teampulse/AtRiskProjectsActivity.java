package com.example.teampulse;

import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.example.teampulse.databinding.ActivityAtRiskProjectsBinding;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class AtRiskProjectsActivity extends AppCompatActivity implements OnProjectInteractionListener {

    private ActivityAtRiskProjectsBinding binding;
    private ProjectsAdapter adapter;
    private List<Project> atRiskProjectList;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityAtRiskProjectsBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        setSupportActionBar(binding.toolbar);
        binding.toolbar.setNavigationOnClickListener(v -> finish());

        // Get the list of projects passed from the dashboard
        atRiskProjectList = (List<Project>) getIntent().getSerializableExtra("AT_RISK_PROJECTS");
        if (atRiskProjectList == null) {
            atRiskProjectList = new ArrayList<>(); // Avoid null pointer exception
        }

        setupRecyclerView();
        updateUI();
    }

    private void setupRecyclerView() {
        adapter = new ProjectsAdapter(this, atRiskProjectList, this);
        binding.atRiskRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        binding.atRiskRecyclerView.setAdapter(adapter);
    }

    private void updateUI() {
        if (atRiskProjectList.isEmpty()) {
            binding.atRiskRecyclerView.setVisibility(View.GONE);
            binding.tvNoAtRiskProjects.setVisibility(View.VISIBLE);
        } else {
            binding.atRiskRecyclerView.setVisibility(View.VISIBLE);
            binding.tvNoAtRiskProjects.setVisibility(View.GONE);
        }
    }

    // Since this is a view-only list for the teacher, these interactions
    // are less critical, but we implement them for consistency.
    @Override
    public void onProjectDeleted() {
        // This won't be called as the delete button is hidden for teachers.
    }

    @Override
    public void onProjectPinChanged(String newPinnedId) {
        Toast.makeText(this, "Pinning is not available in this view.", Toast.LENGTH_SHORT).show();
    }
}