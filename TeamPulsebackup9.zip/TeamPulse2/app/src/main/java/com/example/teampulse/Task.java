package com.example.teampulse;

import java.io.Serializable;

public class Task implements Serializable {
    private String id;
    private String title;
    private String description;
    private String assigneeUid;
    private String assigneeName;
    private String dueDate;
    private String createdDate; // ✅ FIELD ADDED
    private int difficulty;
    private String projectId;
    private String type;
    private int points;
    private double weight;
    private String status = TaskStatus.PLANNING.name();
    private String completionNote;

    // Required empty constructor for Firestore
    public Task() {}

    // --- Getters and Setters ---

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public int getPoints() { return points; }
    public void setPoints(int points) { this.points = points; }

    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public String getAssigneeUid() { return assigneeUid; }
    public void setAssigneeUid(String assigneeUid) { this.assigneeUid = assigneeUid; }

    public String getAssigneeName() { return assigneeName; }
    public void setAssigneeName(String assigneeName) { this.assigneeName = assigneeName; }

    public String getDueDate() { return dueDate; }
    public void setDueDate(String dueDate) { this.dueDate = dueDate; }

    // ✅ GETTER AND SETTER ADDED
    public String getCreatedDate() { return createdDate; }
    public void setCreatedDate(String createdDate) { this.createdDate = createdDate; }

    public int getDifficulty() { return difficulty; }
    public void setDifficulty(int difficulty) { this.difficulty = difficulty; }

    public String getProjectId() { return projectId; }
    public void setProjectId(String projectId) { this.projectId = projectId; }

    public String getType() { return type; }
    public void setType(String type) { this.type = type; }



    public String getCompletionNote() { return completionNote; }
    public void setCompletionNote(String completionNote) { this.completionNote = completionNote; }

    // --- Status-related methods ---

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public TaskStatus getStatusEnum() { return TaskStatus.fromString(this.status); }
}