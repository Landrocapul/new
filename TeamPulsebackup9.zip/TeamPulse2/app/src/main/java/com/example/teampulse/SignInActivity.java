package com.example.teampulse;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.teampulse.databinding.ActivitySignInBinding;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;

public class SignInActivity extends AppCompatActivity {

    private ActivitySignInBinding binding;
    private FirebaseAuth mAuth;
    private FirebaseFirestore db;
    private static final String PREFS_NAME = "TeamPulsePrefs";
    private static final String PREF_USER_EMAIL = "user_email";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivitySignInBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        binding.toolbar.setNavigationOnClickListener(v -> {
            Intent intent = new Intent(SignInActivity.this, WelcomeActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            startActivity(intent);
            finish();
        });

        mAuth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();
        loadSavedEmail();

        binding.signInButton.setOnClickListener(v -> handleSignIn());
        binding.signUpPrompt.setOnClickListener(v ->
                startActivity(new Intent(SignInActivity.this, SignUpActivity.class)));
    }

    private void handleSignIn() {
        String email = binding.emailEditText.getText().toString().trim();
        String password = binding.passwordEditText.getText().toString().trim();

        if (email.isEmpty() || password.isEmpty()) {
            showToast("Please fill in all fields");
            return;
        }



        mAuth.signInWithEmailAndPassword(email, password)
                .addOnSuccessListener(authResult -> {
                    saveEmail(email);
                    FirebaseUser user = mAuth.getCurrentUser();
                    if (user == null) {
                        showToast("User not found after login.");
                        return;
                    }

                    db.collection("users").document(user.getUid()).get()
                            .addOnSuccessListener(documentSnapshot -> {
                                if (documentSnapshot.exists()) {
                                    String role = documentSnapshot.getString("role");
                                    showToast("Welcome back!");

                                    Intent intent;

                                    switch (role != null ? role : "") {
                                        case "Leader":
                                        case "Member":

                                            intent = new Intent(SignInActivity.this, DashboardActivity.class);
                                            break;
                                        case "Teacher":
                                            intent = new Intent(SignInActivity.this, TeacherDashboardActivity.class);
                                            break;
                                        default:
                                            showToast("User role not found.");
                                            mAuth.signOut();
                                            return;
                                    }
                                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                                    startActivity(intent);
                                    finish();
                                } else {
                                    showToast("User data not found in Firestore. Please contact support.");
                                    mAuth.signOut();
                                }
                            })
                            .addOnFailureListener(e -> {
                                showToast("Failed to fetch user info: " + e.getMessage());
                                mAuth.signOut();
                            });
                })
                .addOnFailureListener(e -> showToast("Login failed: " + e.getMessage()));
    }

    private void saveEmail(String email) {
        SharedPreferences sharedPreferences = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString(PREF_USER_EMAIL, email);
        editor.apply();
    }

    private void loadSavedEmail() {
        SharedPreferences sharedPreferences = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        String savedEmail = sharedPreferences.getString(PREF_USER_EMAIL, null);
        if (savedEmail != null) {
            binding.emailEditText.setText(savedEmail);
            binding.passwordEditText.requestFocus();
        }
    }

    private void showToast(String message) {
        Toast.makeText(SignInActivity.this, message, Toast.LENGTH_SHORT).show();
    }
}