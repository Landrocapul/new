package com.example.teampulse;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.viewpager2.adapter.FragmentStateAdapter;

import java.util.List;
import java.util.Map;

public class MyTasksPagerAdapter extends FragmentStateAdapter {

    private final List<Task> ongoingTasks;
    private final List<Task> reviewTasks;
    private final List<Task> completedTasks;
    private final Map<String, String> projectMap;

    public MyTasksPagerAdapter(@NonNull FragmentActivity fragmentActivity,
                               List<Task> ongoingTasks,
                               List<Task> reviewTasks,
                               List<Task> completedTasks,
                               Map<String, String> projectMap) {
        super(fragmentActivity);
        this.ongoingTasks = ongoingTasks;
        this.reviewTasks = reviewTasks;
        this.completedTasks = completedTasks;
        this.projectMap = projectMap;
    }

    @NonNull
    @Override
    public Fragment createFragment(int position) {
        switch (position) {
            case 0:
                return MyTasksColumnFragment.newInstance(ongoingTasks, projectMap);
            case 1:
                return MyTasksColumnFragment.newInstance(reviewTasks, projectMap);
            case 2:
                return MyTasksColumnFragment.newInstance(completedTasks, projectMap);
            default:
                return new Fragment(); // Should not happen
        }
    }

    @Override
    public int getItemCount() {
        return 3; // We have three tabs
    }
}