package com.example.teampulse;

import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Typeface;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.example.teampulse.databinding.ActivityCalendarBinding;
import com.example.teampulse.databinding.ItemCalendarDayBinding;
import com.example.teampulse.databinding.ItemCalendarMonthHeaderBinding;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.kizitonwose.calendar.core.CalendarDay;
import com.kizitonwose.calendar.core.CalendarMonth;
import com.kizitonwose.calendar.core.DayPosition;
import com.kizitonwose.calendar.view.MonthDayBinder;
import com.kizitonwose.calendar.view.MonthHeaderFooterBinder;
import com.kizitonwose.calendar.view.ViewContainer;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.YearMonth;
import java.time.format.DateTimeFormatter;
import java.time.format.TextStyle;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.time.temporal.WeekFields;

public class CalendarActivity extends AppCompatActivity {

    private ActivityCalendarBinding binding;
    private FirebaseAuth mAuth;
    private FirebaseFirestore db;
    private String userRole;

    private final List<Task> allTasks = new ArrayList<>();
    private final Map<String, String> projectIdToTitleMap = new HashMap<>();
    private final List<MyTasksListItem> displayedTasks = new ArrayList<>();
    private final Map<LocalDate, List<Task>> tasksByDate = new HashMap<>();

    private CalendarTaskItemAdapter tasksAdapter;
    private LocalDate selectedDate = LocalDate.now();
    private final LocalDate today = LocalDate.now();

    private final DateTimeFormatter storageFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
    private final DateTimeFormatter displayFormatter = DateTimeFormatter.ofPattern("MMMM d, yyyy", Locale.getDefault());
    private final DateTimeFormatter monthTitleFormatter = DateTimeFormatter.ofPattern("MMMM yyyy", Locale.getDefault());

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityCalendarBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        mAuth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();

        setSupportActionBar(binding.toolbar);

        setupRecyclerView();
        setupCalendar();
        fetchUserRoleAndData();
    }
    private void setupCalendar() {
        YearMonth currentMonth = YearMonth.from(selectedDate);
        YearMonth startMonth = currentMonth.minusMonths(12);
        YearMonth endMonth = currentMonth.plusMonths(12);
        final DayOfWeek firstDayOfWeek = WeekFields.of(Locale.getDefault()).getFirstDayOfWeek();

        binding.calendarView.setDayViewResource(R.layout.item_calendar_day);
        binding.calendarView.setMonthHeaderResource(R.layout.item_calendar_month_header);
        binding.calendarView.setup(startMonth, endMonth, firstDayOfWeek);
        binding.calendarView.scrollToMonth(currentMonth);

        binding.calendarView.setDayBinder(new MonthDayBinder<DayViewContainer>() {
            @NonNull
            @Override
            public DayViewContainer create(@NonNull View view) {
                return new DayViewContainer(view);
            }

            @Override
            public void bind(@NonNull DayViewContainer container, @NonNull CalendarDay day) {
                container.day = day;
                LocalDate date = day.getDate();
                ItemCalendarDayBinding dayBinding = container.dayBinding;

                dayBinding.dayText.setText(String.valueOf(date.getDayOfMonth()));

                boolean isCurrentMonth = day.getPosition() == DayPosition.MonthDate;
                dayBinding.getRoot().setAlpha(isCurrentMonth ? 1f : 0.4f);

                List<Task> tasksForDay = tasksByDate.getOrDefault(date, Collections.emptyList());
                int taskCount = tasksForDay.size();

                if (taskCount == 0) {
                    dayBinding.dot.setVisibility(View.GONE);
                    dayBinding.taskOverflowBadge.setVisibility(View.GONE);
                } else {
                    dayBinding.dot.setVisibility(View.GONE);
                    dayBinding.taskOverflowBadge.setText(String.valueOf(taskCount));
                    dayBinding.taskOverflowBadge.setVisibility(View.VISIBLE);
                }

                if (date.equals(selectedDate)) {
                    dayBinding.dayText.setBackgroundResource(R.drawable.bg_calendar_selected);
                    dayBinding.dayText.setTextColor(ContextCompat.getColor(CalendarActivity.this, android.R.color.white));
                } else {
                    dayBinding.dayText.setBackgroundResource(0);
                    int textColor = ContextCompat.getColor(CalendarActivity.this,
                            isCurrentMonth ? R.color.text_primary : R.color.text_secondary);
                    dayBinding.dayText.setTextColor(textColor);
                    if (date.equals(today)) {
                        dayBinding.dayText.setTextColor(ContextCompat.getColor(CalendarActivity.this, R.color.blue));
                    }
                }
            }
        });

        binding.calendarView.setMonthHeaderBinder(new MonthHeaderFooterBinder<MonthHeaderViewContainer>() {
            @NonNull
            @Override
            public MonthHeaderViewContainer create(@NonNull View view) {
                return new MonthHeaderViewContainer(view);
            }

            @Override
            public void bind(@NonNull MonthHeaderViewContainer container, @NonNull CalendarMonth month) {
                container.headerBinding.monthTitle.setText(month.getYearMonth().format(monthTitleFormatter));

                LinearLayout dayTitles = container.headerBinding.dayTitlesLayout;
                if (dayTitles.getChildCount() == 0) {
                    dayTitles.setWeightSum(7f);
                    DayOfWeek dayOfWeek = firstDayOfWeek;
                    for (int i = 0; i < 7; i++) {
                        TextView textView = new TextView(dayTitles.getContext());
                        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
                        textView.setLayoutParams(params);
                        textView.setGravity(Gravity.CENTER);
                        textView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f);
                        textView.setTextColor(ContextCompat.getColor(CalendarActivity.this, R.color.text_secondary));
                        String label = dayOfWeek.getDisplayName(TextStyle.SHORT, Locale.getDefault()).toUpperCase(Locale.getDefault());
                        textView.setText(label);
                        dayTitles.addView(textView);
                        dayOfWeek = dayOfWeek.plus(1);
                    }
                }
            }
        });

        selectDate(selectedDate, false);
    }

    private void setupRecyclerView() {
        tasksAdapter = new CalendarTaskItemAdapter(displayedTasks, this);
        binding.tasksRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        binding.tasksRecyclerView.setAdapter(tasksAdapter);
    }

    private void fetchUserRoleAndData() {
        FirebaseUser currentUser = mAuth.getCurrentUser();
        if (currentUser == null) {
            finish();
            return;
        }

        db.collection("users").document(currentUser.getUid()).get()
                .addOnSuccessListener(documentSnapshot -> {
                    if (documentSnapshot.exists()) {
                        userRole = documentSnapshot.getString("role");
                    }
                    setupBottomNavigation();
                    loadAllRelevantData();
                });
    }

    private void loadAllRelevantData() {
        FirebaseUser currentUser = mAuth.getCurrentUser();
        if (currentUser == null) return;

        db.collection("projects")
                .whereArrayContains("teamMembers", currentUser.getUid())
                .get()
                .addOnSuccessListener(projectSnapshots -> {
                    projectIdToTitleMap.clear();
                    List<String> projectIds = new ArrayList<>();
                    for (QueryDocumentSnapshot doc : projectSnapshots) {
                        projectIds.add(doc.getId());
                        projectIdToTitleMap.put(doc.getId(), doc.getString("title"));
                    }

                    if (projectIds.isEmpty() && !"Teacher".equals(userRole)) {
                        binding.calendarView.notifyCalendarChanged();
                        selectDate(selectedDate, false);
                        return;
                    }

                    fetchAllTasks(currentUser.getUid(), projectIds);
                });
    }

    private void fetchAllTasks(String userId, List<String> memberProjectIds) {
        Query.Direction direction = Query.Direction.ASCENDING;

        if ("Teacher".equals(userRole)) {
            // For teachers, fetch all tasks in their projects
            allTasks.clear();
            final int[] completedQueries = {0};
            for (String projectId : memberProjectIds) {
                db.collection("projects").document(projectId).collection("tasks")
                        .orderBy("dueDate", direction)
                        .get()
                        .addOnSuccessListener(taskSnapshots -> {
                            for (QueryDocumentSnapshot doc : taskSnapshots) {
                                Task task = doc.toObject(Task.class);
                                task.setId(doc.getId());
                                task.setProjectId(projectId);
                                allTasks.add(task);
                            }
                            completedQueries[0]++;
                            if (completedQueries[0] == memberProjectIds.size()) {
                                rebuildTaskCollections();
                            }
                        })
                        .addOnFailureListener(e -> {
                            completedQueries[0]++;
                            if (completedQueries[0] == memberProjectIds.size()) {
                                rebuildTaskCollections();
                            }
                        });
            }
        } else {
            // For students, fetch tasks assigned to them
            Query tasksQuery = db.collectionGroup("tasks").whereEqualTo("assigneeUid", userId);
            tasksQuery.orderBy("dueDate", direction).get()
                    .addOnSuccessListener(taskSnapshots -> {
                        allTasks.clear();
                        for (QueryDocumentSnapshot doc : taskSnapshots) {
                            Task task = doc.toObject(Task.class);
                            task.setId(doc.getId());
                            String parentProjectId = doc.getReference().getParent().getParent().getId();
                            task.setProjectId(parentProjectId);
                            allTasks.add(task);
                        }
                        rebuildTaskCollections();
                    });
        }
    }

    private void rebuildTaskCollections() {
        tasksByDate.clear();
        for (Task task : allTasks) {
            String dueDate = task.getDueDate();
            if (dueDate == null || dueDate.isEmpty()) continue;
            try {
                LocalDate date = LocalDate.parse(dueDate, storageFormatter);
                tasksByDate.computeIfAbsent(date, key -> new ArrayList<>()).add(task);
            } catch (Exception ignored) { }
        }

        if (!tasksByDate.containsKey(selectedDate) && !tasksByDate.isEmpty()) {
            tasksByDate.keySet().stream().min(LocalDate::compareTo).ifPresent(date -> selectedDate = date);
        }

        binding.calendarView.notifyCalendarChanged();
        selectDate(selectedDate, false);
    }

    private void selectDate(@NonNull LocalDate date, boolean smoothScroll) {
        LocalDate oldDate = selectedDate;
        selectedDate = date;
        updateTasksForSelectedDate(date);
        binding.calendarView.notifyDateChanged(date);
        if (oldDate != null && !oldDate.equals(date)) {
            binding.calendarView.notifyDateChanged(oldDate);
        }
        if (smoothScroll) {
            binding.calendarView.smoothScrollToMonth(YearMonth.from(date));
        }
    }

    private void updateTasksForSelectedDate(@NonNull LocalDate date) {
        List<Task> tasksForDay = tasksByDate.getOrDefault(date, Collections.emptyList());
        binding.tvSelectedDate.setText(String.format(Locale.getDefault(), "Tasks for %s", date.format(displayFormatter)));

        displayedTasks.clear();
        if (!tasksForDay.isEmpty()) {
            Map<String, List<Task>> groupedByProject = new LinkedHashMap<>();
            for (Task task : tasksForDay) {
                groupedByProject.computeIfAbsent(task.getProjectId(), key -> new ArrayList<>()).add(task);
            }

            for (Map.Entry<String, List<Task>> entry : groupedByProject.entrySet()) {
                String projectTitle = projectIdToTitleMap.get(entry.getKey());
                displayedTasks.add(new ProjectHeaderItem(projectTitle != null ? projectTitle : "Project"));
                for (Task task : entry.getValue()) {
                    displayedTasks.add(new TaskItem(task));
                }
            }
        }

        tasksAdapter.notifyDataSetChanged();
    }

    private void setupBottomNavigation() {
        if ("Teacher".equals(userRole)) {
            binding.bottomNavigation.inflateMenu(R.menu.teacher_bottom_nav_menu);
        } else {
            binding.bottomNavigation.inflateMenu(R.menu.bottom_nav_menu);
        }

        binding.bottomNavigation.setSelectedItemId(R.id.nav_calendar);

        // Set custom colors for selected/unselected states
        int selectedColor = ContextCompat.getColor(this, R.color.text_primary);
        int unselectedColor = ContextCompat.getColor(this, R.color.text_secondary);
        binding.bottomNavigation.setItemIconTintList(createColorStateList(selectedColor, unselectedColor));
        binding.bottomNavigation.setItemTextColor(createColorStateList(selectedColor, unselectedColor));

        binding.bottomNavigation.setOnItemSelectedListener(item -> {
            int itemId = item.getItemId();
            if (itemId == R.id.nav_calendar) {
                return true;
            }
            if (itemId == R.id.nav_home) {
                Intent intent;
                if ("Teacher".equals(userRole)) {
                    intent = new Intent(getApplicationContext(), TeacherDashboardActivity.class);
                } else {
                    intent = new Intent(getApplicationContext(), DashboardActivity.class);
                }
                startActivity(intent);
                overridePendingTransition(R.anim.float_down_in, R.anim.float_up_out);
                finish();
                return true;
            }
            if (itemId == R.id.nav_projects) {
                Intent intent;
                if ("Teacher".equals(userRole)) {
                    intent = new Intent(getApplicationContext(), TeacherProjectsActivity.class);
                } else {
                    intent = new Intent(getApplicationContext(), ProjectsActivity.class);
                }
                startActivity(intent);
                overridePendingTransition(R.anim.float_down_in, R.anim.float_up_out);
                finish();
                return true;
            }
            if (itemId == R.id.nav_my_tasks) {
                startActivity(new Intent(getApplicationContext(), MyTasksActivity.class));
                overridePendingTransition(R.anim.float_down_in, R.anim.float_up_out);
                finish();
                return true;
            }
            return false;
        });
    }

    private ColorStateList createColorStateList(int selectedColor, int unselectedColor) {
        int[][] states = new int[][] {
            new int[] { android.R.attr.state_checked }, // selected
            new int[] { -android.R.attr.state_checked }  // unselected
        };
        int[] colors = new int[] {
            selectedColor,
            unselectedColor
        };
        return new ColorStateList(states, colors);
    }

    private class DayViewContainer extends ViewContainer {
        final ItemCalendarDayBinding dayBinding;
        CalendarDay day;

        DayViewContainer(@NonNull View view) {
            super(view);
            dayBinding = ItemCalendarDayBinding.bind(view);
            view.setOnClickListener(v -> {
                if (day == null) return;
                if (day.getPosition() == DayPosition.MonthDate) {
                    selectDate(day.getDate(), true);
                } else {
                    binding.calendarView.smoothScrollToMonth(YearMonth.from(day.getDate()));
                }
            });
        }
    }

    private class MonthHeaderViewContainer extends ViewContainer {
        final ItemCalendarMonthHeaderBinding headerBinding;

        MonthHeaderViewContainer(@NonNull View view) {
            super(view);
            headerBinding = ItemCalendarMonthHeaderBinding.bind(view);
        }
    }
}