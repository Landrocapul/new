package com.example.teampulse;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.gms.tasks.Task;
import com.google.android.gms.tasks.Tasks;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ReviewTasksActivity extends AppCompatActivity {

    private FirebaseFirestore db;
    private FirebaseAuth mAuth;
    private RecyclerView recyclerView;
    private ReviewTasksAdapter adapter;
    private TextView tvNoTasks;
    private List<com.example.teampulse.Task> taskList = new ArrayList<>();
    private Map<String, String> projectIdToTitleMap = new HashMap<>();

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_review_tasks);

        db = FirebaseFirestore.getInstance();
        mAuth = FirebaseAuth.getInstance();

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        toolbar.setNavigationOnClickListener(v -> finish());

        recyclerView = findViewById(R.id.review_tasks_recycler_view);
        tvNoTasks = findViewById(R.id.tv_no_tasks_to_review);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        loadTasksForReview();
    }

    private void loadTasksForReview() {
        FirebaseUser currentUser = mAuth.getCurrentUser();
        if (currentUser == null) {
            Toast.makeText(this, "You must be logged in.", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }
        String leaderId = currentUser.getUid();

        // Step 1: Find all projects led by the current user
        db.collection("projects").whereEqualTo("leaderId", leaderId).get()
                .addOnSuccessListener(projectSnapshots -> {
                    if (projectSnapshots.isEmpty()) {
                        // Leader has no projects, so no tasks to review
                        updateUI();
                        return;
                    }

                    List<String> projectIds = new ArrayList<>();
                    for (QueryDocumentSnapshot doc : projectSnapshots) {
                        projectIds.add(doc.getId());
                        // While we're here, build the map of Project ID -> Project Title
                        projectIdToTitleMap.put(doc.getId(), doc.getString("title"));
                    }

                    // Step 2: Query all tasks where projectId is in our list and status is FOR_REVIEW
                    if (!projectIds.isEmpty()) {
                        db.collectionGroup("tasks")
                                .whereIn("projectId", projectIds)
                                .whereEqualTo("status", "FOR_REVIEW")
                                .get()
                                .addOnSuccessListener(taskSnapshots -> {
                                    taskList.clear();
                                    for (QueryDocumentSnapshot doc : taskSnapshots) {
                                        com.example.teampulse.Task task = doc.toObject(com.example.teampulse.Task.class);
                                        task.setId(doc.getId());
                                        taskList.add(task);
                                    }
                                    updateUI();
                                })
                                .addOnFailureListener(e -> {
                                    Toast.makeText(this, "Failed to load tasks for review.", Toast.LENGTH_SHORT).show();
                                });
                    }
                })
                .addOnFailureListener(e -> {
                    Toast.makeText(this, "Failed to load projects.", Toast.LENGTH_SHORT).show();
                });
    }

    private void updateUI() {
        if (taskList.isEmpty()) {
            recyclerView.setVisibility(View.GONE);
            tvNoTasks.setVisibility(View.VISIBLE);
        } else {
            recyclerView.setVisibility(View.VISIBLE);
            tvNoTasks.setVisibility(View.GONE);
            adapter = new ReviewTasksAdapter(this, taskList, projectIdToTitleMap);
            recyclerView.setAdapter(adapter);
        }
    }
}