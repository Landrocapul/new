package com.example.teampulse;

public enum TaskStatus {
    PLANNING,
    IN_PROGRESS,
    FOR_REVIEW,
    TO_REVIEW,
    DONE;

    // Helper to safely convert a string to an enum value
    public static TaskStatus fromString(String text) {
        if (text != null) {
            for (TaskStatus b : TaskStatus.values()) {
                if (text.equalsIgnoreCase(b.name())) {
                    return b;
                }
            }
        }
        return PLANNING; // Default to PLANNING if string is invalid or null
    }
}