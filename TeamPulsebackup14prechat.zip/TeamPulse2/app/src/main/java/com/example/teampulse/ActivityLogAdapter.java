package com.example.teampulse;

import android.content.Context;
import android.text.format.DateUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;
import com.example.teampulse.ActivityLog.EventType;

import java.util.List;

public class ActivityLogAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    // Define integer constants for our two view types
    private static final int VIEW_TYPE_GENERAL = 1;
    private static final int VIEW_TYPE_CREATION = 2;

    private final List<ActivityLog> logList;
    private final Context context;

    public ActivityLogAdapter(Context context, List<ActivityLog> logList) {
        this.context = context;
        this.logList = logList;
    }

    @Override
    public int getItemViewType(int position) {
        EventType type = logList.get(position).getEventType();
        // Return a different integer based on the event type
        if (type == EventType.PROJECT_CREATED || type == EventType.TASK_CREATED) {
            return VIEW_TYPE_CREATION;
        } else {
            return VIEW_TYPE_GENERAL;
        }
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // Inflate the correct layout based on the viewType returned by getItemViewType()
        if (viewType == VIEW_TYPE_CREATION) {
            View view = LayoutInflater.from(context).inflate(R.layout.log_item_creation, parent, false);
            return new CreationLogViewHolder(view);
        } else { // Includes VIEW_TYPE_GENERAL and any other future types
            View view = LayoutInflater.from(context).inflate(R.layout.log_item_general, parent, false);
            return new GeneralLogViewHolder(view);
        }
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        ActivityLog log = logList.get(position);
        // Bind the data using the correct ViewHolder
        if (holder.getItemViewType() == VIEW_TYPE_CREATION) {
            ((CreationLogViewHolder) holder).bind(log);
        } else {
            ((GeneralLogViewHolder) holder).bind(log);
        }
    }

    @Override
    public int getItemCount() {
        return logList.size();
    }

    // ViewHolder for the general log item layout
    static class GeneralLogViewHolder extends RecyclerView.ViewHolder {
        private final TextView tvMessage;
        private final TextView tvTimestamp;
        private final ImageView ivIcon;

        public GeneralLogViewHolder(@NonNull View itemView) {
            super(itemView);
            tvMessage = itemView.findViewById(R.id.tv_log_message);
            tvTimestamp = itemView.findViewById(R.id.tv_log_timestamp);
            ivIcon = itemView.findViewById(R.id.log_icon);
        }

        public void bind(ActivityLog log) {
            String fullMessage = "<b>" + log.getAuthorName() + "</b> " + log.getLogMessage();
            tvMessage.setText(android.text.Html.fromHtml(fullMessage));

            if (log.getTimestamp() != null) {
                // Use DateUtils for nice relative time formatting (e.g., "2 hours ago")
                CharSequence timeAgo = DateUtils.getRelativeTimeSpanString(log.getTimestamp().getTime(),
                        System.currentTimeMillis(), DateUtils.MINUTE_IN_MILLIS);
                tvTimestamp.setText(timeAgo);
            }

            // Set icon based on event type
            switch (log.getEventType()) {
                case TASK_STATUS_CHANGED:
                    ivIcon.setImageResource(R.drawable.ic_edit);
                    break;
                case MEMBER_JOINED:
                    ivIcon.setImageResource(R.drawable.ic_uncomplete); // Example icon
                    break;
                case TASK_DELETED:
                    ivIcon.setImageResource(R.drawable.ic_delete);
                    break;
                default:
                    ivIcon.setImageResource(R.drawable.ic_more_vert);
            }
        }
    }

    // ViewHolder for the creation log item layout
    static class CreationLogViewHolder extends RecyclerView.ViewHolder {
        private final TextView tvMessage;
        private final TextView tvTimestamp;
        // Icon is set in XML for this ViewHolder

        public CreationLogViewHolder(@NonNull View itemView) {
            super(itemView);
            tvMessage = itemView.findViewById(R.id.tv_log_message);
            tvTimestamp = itemView.findViewById(R.id.tv_log_timestamp);
        }

        public void bind(ActivityLog log) {
            String fullMessage = "<b>" + log.getAuthorName() + "</b> " + log.getLogMessage();
            tvMessage.setText(android.text.Html.fromHtml(fullMessage));

            if (log.getTimestamp() != null) {
                CharSequence timeAgo = DateUtils.getRelativeTimeSpanString(log.getTimestamp().getTime(),
                        System.currentTimeMillis(), DateUtils.MINUTE_IN_MILLIS);
                tvTimestamp.setText(timeAgo);
            }
        }
    }
}