package com.example.teampulse;

import java.io.Serializable;

public interface OnTaskUpdatedListener extends Serializable {
    void onTaskUpdated();
}
