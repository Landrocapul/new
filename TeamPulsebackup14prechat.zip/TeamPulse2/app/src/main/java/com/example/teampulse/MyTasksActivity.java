package com.example.teampulse;

import android.content.Intent;
import android.content.res.ColorStateList;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import com.example.teampulse.databinding.ActivityMyTasksBinding;
import com.google.android.gms.tasks.Task;
import com.google.android.gms.tasks.Tasks;
import com.google.android.material.tabs.TabLayoutMediator;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

    public class MyTasksActivity extends AppCompatActivity implements NavigationDrawerFragment.NavigationListener, NavigationDrawerFragment.DrawerActivity {

        private ActivityMyTasksBinding binding;
        private FirebaseAuth mAuth;
        private FirebaseFirestore db;
        private Map<String, String> projectIdToTitleMap = new HashMap<>();
        private String currentUserRole = "";

        // ✅ Drawer components
        private DrawerLayout drawerLayout;
        private ActionBarDrawerToggle toggle;

        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            binding = ActivityMyTasksBinding.inflate(getLayoutInflater());
            setContentView(binding.getRoot());

            mAuth = FirebaseAuth.getInstance();
            db = FirebaseFirestore.getInstance();

            setupViews();
            setupToolbarAndDrawer();
            setupBottomNavigation();
        }

        // ✅ NEW method to initialize drawer views
        private void setupViews() {
            drawerLayout = findViewById(R.id.drawer_layout);
        }

        // ✅ NEW method to set up the drawer
        private void setupToolbarAndDrawer() {
            setSupportActionBar(binding.toolbar);
            toggle = new ActionBarDrawerToggle(this, drawerLayout, binding.toolbar,
                    R.string.navigation_drawer_open, R.string.navigation_drawer_close);
            drawerLayout.addDrawerListener(toggle);
            toggle.syncState();

            // Host the NavigationDrawerFragment
            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.drawer_fragment_container, new NavigationDrawerFragment())
                    .commit();
        }


        private void logoutUser() {
            mAuth.signOut();
            Intent intent = new Intent(this, SignInActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            finish();
        }

        // ✅ NEW methods to handle the toolbar menu
        @Override
        public boolean onCreateOptionsMenu(Menu menu) {
            getMenuInflater().inflate(R.menu.dashboard_menu, menu);
            return true;
        }

        @Override
        public boolean onPrepareOptionsMenu(Menu menu) {
            FirebaseUser currentUser = mAuth.getCurrentUser();
            if (currentUser != null) {
                db.collection("users").document(currentUser.getUid()).get()
                        .addOnSuccessListener(documentSnapshot -> {
                            if (documentSnapshot.exists()) {
                                String name = documentSnapshot.getString("name");
                                MenuItem profileItem = menu.findItem(R.id.action_profile);
                                if (profileItem != null) {
                                    View actionView = profileItem.getActionView();
                                    if (actionView != null) {
                                        TextView avatarTextView = actionView.findViewById(R.id.avatar_text);
                                        if (name != null && !name.isEmpty()) {
                                            String[] names = name.split(" ");
                                            String initials = "";
                                            if (names.length > 0) initials += names[0].charAt(0);
                                            if (names.length > 1) initials += names[names.length - 1].charAt(0);
                                            avatarTextView.setText(initials.toUpperCase());
                                        }
                                        actionView.setOnClickListener(v -> onOptionsItemSelected(profileItem));
                                    }
                                }
                            }
                        });
            }
            return super.onPrepareOptionsMenu(menu);
        }

        @Override
        public boolean onOptionsItemSelected(@NonNull MenuItem item) {
            if (toggle.onOptionsItemSelected(item)) {
                return true;
            }
            int itemId = item.getItemId();
            if (itemId == R.id.action_profile) {
                startActivity(new Intent(this, ProfileActivity.class));
                return true;
            }
            return super.onOptionsItemSelected(item);
        }

        // --- (The rest of your existing MyTasksActivity methods are unchanged) ---

        @Override
        protected void onResume() {
            super.onResume();
            loadProjectMapAndUserData();
        }

    private void loadProjectMapAndUserData() {
        FirebaseUser currentUser = mAuth.getCurrentUser();
        if (currentUser == null) {
            startActivity(new Intent(this, SignInActivity.class));
            finish();
            return;
        }

        db.collection("users").document(currentUser.getUid()).get()
                .addOnSuccessListener(userDoc -> {
                    if (userDoc.exists()) {
                        currentUserRole = userDoc.getString("role");
                    }

                    db.collection("projects").whereArrayContains("teamMembers", currentUser.getUid()).get()
                            .addOnSuccessListener(projectSnapshots -> {
                                projectIdToTitleMap.clear();
                                for (com.google.firebase.firestore.QueryDocumentSnapshot doc : projectSnapshots) {
                                    projectIdToTitleMap.put(doc.getId(), doc.getString("title"));
                                }
                                loadAllRelevantTasks(currentUser.getUid());
                            })
                            .addOnFailureListener(e -> Toast.makeText(this, "Could not load project list.", Toast.LENGTH_SHORT).show());
                })
                .addOnFailureListener(e -> {
                    Toast.makeText(this, "Could not load user data.", Toast.LENGTH_SHORT).show();
                    loadAllRelevantTasks(currentUser.getUid());
                });
    }

    private void loadAllRelevantTasks(String uid) {
        if ("Leader".equals(currentUserRole)) {
            // For leaders, fetch all tasks in projects they lead
            db.collection("projects").whereEqualTo("leaderId", uid).get()
                    .addOnSuccessListener(projectSnapshots -> {
                        List<String> leaderProjectIds = new ArrayList<>();
                        for (com.google.firebase.firestore.QueryDocumentSnapshot doc : projectSnapshots) {
                            leaderProjectIds.add(doc.getId());
                        }

                        if (!leaderProjectIds.isEmpty()) {
                            List<Task<QuerySnapshot>> allQueries = new ArrayList<>();
                            for (String projectId : leaderProjectIds) {
                                Task<QuerySnapshot> projectTasksQuery = db.collection("projects").document(projectId).collection("tasks").get();
                                allQueries.add(projectTasksQuery);
                            }
                            Tasks.whenAllSuccess(allQueries).addOnSuccessListener(results -> {
                                Map<String, com.example.teampulse.Task> uniqueTasksMap = new HashMap<>();
                                for (Object result : results) {
                                    QuerySnapshot snapshot = (QuerySnapshot) result;
                                    for (com.google.firebase.firestore.QueryDocumentSnapshot doc : snapshot) {
                                        com.example.teampulse.Task task = doc.toObject(com.example.teampulse.Task.class);
                                        task.setId(doc.getId());
                                        task.setProjectId(doc.getReference().getParent().getParent().getId());
                                        uniqueTasksMap.put(task.getId(), task);
                                    }
                                }
                                List<com.example.teampulse.Task> allTasks = new ArrayList<>(uniqueTasksMap.values());
                                filterAndDisplayTasks(allTasks);
                            });
                        } else {
                            filterAndDisplayTasks(new ArrayList<>());
                        }
                    })
                    .addOnFailureListener(e -> {
                        Toast.makeText(this, "Failed to load leader projects.", Toast.LENGTH_SHORT).show();
                        filterAndDisplayTasks(new ArrayList<>());
                    });
        } else {
            // For members, fetch tasks assigned to them
            db.collectionGroup("tasks")
                    .whereEqualTo("assigneeUid", uid)
                    .get()
                    .addOnSuccessListener(snapshot -> {
                        List<com.example.teampulse.Task> allTasks = new ArrayList<>();
                        for (com.google.firebase.firestore.QueryDocumentSnapshot doc : snapshot) {
                            com.example.teampulse.Task task = doc.toObject(com.example.teampulse.Task.class);
                            task.setId(doc.getId());
                            task.setProjectId(doc.getReference().getParent().getParent().getId());
                            allTasks.add(task);
                        }
                        filterAndDisplayTasks(allTasks);
                    })
                    .addOnFailureListener(e -> Toast.makeText(this, "Failed to load tasks.", Toast.LENGTH_SHORT).show());
        }
    }

    private void filterAndDisplayTasks(List<com.example.teampulse.Task> allTasks) {
        List<com.example.teampulse.Task> ongoingTasks = allTasks.stream()
                .filter(t -> t.getStatusEnum() == TaskStatus.PLANNING || t.getStatusEnum() == TaskStatus.IN_PROGRESS)
                .collect(Collectors.toList());

        List<com.example.teampulse.Task> reviewTasks = allTasks.stream()
                .filter(t -> t.getStatusEnum() == TaskStatus.FOR_REVIEW || t.getStatusEnum() == TaskStatus.TO_REVIEW)
                .collect(Collectors.toList());

        List<com.example.teampulse.Task> completedTasks = allTasks.stream()
                .filter(t -> t.getStatusEnum() == TaskStatus.DONE)
                .collect(Collectors.toList());

        setupViewPagerAndTabs(ongoingTasks, reviewTasks, completedTasks);
    }

    private void setupViewPagerAndTabs(List<com.example.teampulse.Task> ongoing, List<com.example.teampulse.Task> review, List<com.example.teampulse.Task> completed) {
        MyTasksPagerAdapter pagerAdapter = new MyTasksPagerAdapter(this, ongoing, review, completed, projectIdToTitleMap);
        binding.viewPager.setAdapter(pagerAdapter);

        new TabLayoutMediator(binding.tabLayout, binding.viewPager, (tab, position) -> {
            switch (position) {
                case 0:
                    tab.setText("Ongoing (" + ongoing.size() + ")");
                    break;
                case 1:
                    tab.setText("To Review (" + review.size() + ")");
                    break;
                case 2:
                    tab.setText("Completed (" + completed.size() + ")");
                    break;
            }
        }).attach();
    }

    private void setupBottomNavigation() {
        binding.bottomNavigation.setSelectedItemId(R.id.nav_my_tasks);

        // Set custom colors for selected/unselected states
        int selectedColor = ContextCompat.getColor(this, R.color.text_primary);
        int unselectedColor = ContextCompat.getColor(this, R.color.text_secondary);
        binding.bottomNavigation.setItemIconTintList(createColorStateList(selectedColor, unselectedColor));
        binding.bottomNavigation.setItemTextColor(createColorStateList(selectedColor, unselectedColor));

        binding.bottomNavigation.setOnItemSelectedListener(item -> {
            int itemId = item.getItemId();
            if (itemId == R.id.nav_my_tasks) {
                return true;
            }
            if (itemId == R.id.nav_projects) {
                startActivity(new Intent(getApplicationContext(), ProjectsActivity.class));
                overridePendingTransition(R.anim.float_down_in, R.anim.float_up_out);
                finish();
                return true;
            }
            if (itemId == R.id.nav_home) {
                FirebaseUser user = mAuth.getCurrentUser();
                if (user != null) {
                    db.collection("users").document(user.getUid()).get().addOnSuccessListener(doc -> {
                        Intent intent;
                        String role = doc.getString("role");
                        // CORRECTED LOGIC
                        if ("Leader".equals(role) || "Member".equals(role)) {
                            // Both roles now go to the unified DashboardActivity
                            intent = new Intent(getApplicationContext(), DashboardActivity.class);
                        }
                        else {
                            // Fallback for any other role (like Teacher)
                            intent = new Intent(getApplicationContext(), TeacherDashboardActivity.class);
                        }
                        startActivity(intent);
                        overridePendingTransition(R.anim.float_down_in, R.anim.float_up_out);
                        finish();
                    });
                }
                return true;
            }
            if (itemId == R.id.nav_calendar) {
                startActivity(new Intent(getApplicationContext(), CalendarActivity.class));
                overridePendingTransition(R.anim.float_up_in, R.anim.float_down_out);
                finish();
                return true;
            }
            return false;
        });
    }

    private ColorStateList createColorStateList(int selectedColor, int unselectedColor) {
        int[][] states = new int[][] {
            new int[] { android.R.attr.state_checked }, // selected
            new int[] { -android.R.attr.state_checked }  // unselected
        };
        int[] colors = new int[] {
            selectedColor,
            unselectedColor
        };
        return new ColorStateList(states, colors);
    }

    @Override
    public void onLogout() {
        logoutUser();
    }

    @Override
    public void onProfile() {
        startActivity(new Intent(this, ProfileActivity.class));
    }

    @Override
    public void onActivityLog() {
        startActivity(new Intent(this, GlobalLogActivity.class));
    }

    @Override
    public void onSettings() {
        Toast.makeText(this, "Settings screen coming soon!", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void closeDrawer() {
        drawerLayout.closeDrawer(GravityCompat.START);
    }
}