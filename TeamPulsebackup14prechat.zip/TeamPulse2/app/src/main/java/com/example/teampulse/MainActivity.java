// MainActivity.java (The New Router Activity)
package com.example.teampulse;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;

public class MainActivity extends AppCompatActivity {

    private FirebaseAuth mAuth;
    private FirebaseFirestore db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        mAuth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();

        // Check if user is signed in (non-null) and update UI accordingly.
        FirebaseUser currentUser = mAuth.getCurrentUser();

        if (currentUser != null) {
            // User is already signed in, redirect to their dashboard
            redirectToDashboard(currentUser.getUid());
        } else {
            // No user is signed in, redirect to the Welcome screen
            startActivity(new Intent(MainActivity.this, WelcomeActivity.class));
            finish(); // Close this activity
        }
    }

    private void redirectToDashboard(String userId) {
        db.collection("users").document(userId).get()
                .addOnSuccessListener(documentSnapshot -> {
                    if (documentSnapshot.exists()) {
                        String role = documentSnapshot.getString("role");
                        Intent intent;

                        // ✅ MODIFIED: Both Leader and Member go to DashboardActivity
                        switch (role != null ? role : "") {
                            case "Leader":
                            case "Member":
                                intent = new Intent(MainActivity.this, DashboardActivity.class);
                                break;
                            case "Teacher":
                                intent = new Intent(MainActivity.this, TeacherDashboardActivity.class);
                                break;
                            default:
                                // Fallback to welcome screen if role is invalid
                                intent = new Intent(MainActivity.this, WelcomeActivity.class);
                                break;
                        }

                        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                        startActivity(intent);
                        finish();
                    } else {
                        // User data doesn't exist, treat as an error
                        startActivity(new Intent(MainActivity.this, WelcomeActivity.class));
                        finish();
                    }
                })
                .addOnFailureListener(e -> {
                    Toast.makeText(this, "Failed to retrieve user data.", Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(MainActivity.this, WelcomeActivity.class));
                    finish();
                });
    }
}