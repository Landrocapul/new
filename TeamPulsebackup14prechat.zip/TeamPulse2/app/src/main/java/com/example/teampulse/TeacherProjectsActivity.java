package com.example.teampulse;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.example.teampulse.databinding.ActivityTeacherProjectsBinding;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.ListenerRegistration;
import com.google.firebase.firestore.QueryDocumentSnapshot;

import java.util.ArrayList;
import java.util.List;

public class TeacherProjectsActivity extends AppCompatActivity implements OnProjectInteractionListener {

    private ActivityTeacherProjectsBinding binding;
    private FirebaseAuth mAuth;
    private FirebaseFirestore db;

    private ProjectsAdapter adapter;
    private List<Project> projectList = new ArrayList<>();
    private ListenerRegistration projectsListener;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityTeacherProjectsBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        mAuth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();

        setSupportActionBar(binding.toolbar);
        setupRecyclerView();
        setupBottomNavigation();
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadTeacherProjects();
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (projectsListener != null) {
            projectsListener.remove();
        }
    }

    private void setupRecyclerView() {
        adapter = new ProjectsAdapter(this, projectList, this);
        binding.teacherProjectsRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        binding.teacherProjectsRecyclerView.setAdapter(adapter);
        binding.teacherProjectsRecyclerView.setItemAnimator(new androidx.recyclerview.widget.DefaultItemAnimator());
    }

    private void loadTeacherProjects() {
        FirebaseUser currentUser = mAuth.getCurrentUser();
        if (currentUser == null) {
            finish();
            return;
        }

        projectsListener = db.collection("projects")
                .whereEqualTo("teacherId", currentUser.getUid())
                .addSnapshotListener((snapshots, e) -> {
                    if (e != null) {
                        Toast.makeText(this, "Error fetching projects.", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    if (snapshots != null) {
                        projectList.clear();
                        for (QueryDocumentSnapshot doc : snapshots) {
                            Project project = doc.toObject(Project.class);
                            project.setId(doc.getId());
                            projectList.add(project);
                        }
                        adapter.notifyDataSetChanged();

                        if (projectList.isEmpty()) {
                            binding.teacherProjectsRecyclerView.setVisibility(View.GONE);
                            binding.tvNoProjects.setVisibility(View.VISIBLE);
                        } else {
                            binding.teacherProjectsRecyclerView.setVisibility(View.VISIBLE);
                            binding.tvNoProjects.setVisibility(View.GONE);
                        }
                    }
                });
    }

    @Override
    public void onProjectDeleted() {
        // Teachers cannot delete projects, so this is intentionally blank.
    }

    @Override
    public void onProjectPinChanged(String newPinnedId) {
        Toast.makeText(this, "Pinning is not available in the teacher view.", Toast.LENGTH_SHORT).show();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.dashboard_menu, menu);
        return true;
    }



    private void setupBottomNavigation() {
        binding.bottomNavigation.setSelectedItemId(R.id.nav_projects);
        binding.bottomNavigation.setOnItemSelectedListener(item -> {
            int itemId = item.getItemId();
            if (itemId == R.id.nav_projects) {
                return true; // Already here
            }
            if (itemId == R.id.nav_home) {
                // Navigate back to the Teacher's main dashboard
                startActivity(new Intent(getApplicationContext(), TeacherDashboardActivity.class));
                overridePendingTransition(R.anim.float_down_in, R.anim.float_up_out);
                finish(); // Finish this activity
                return true;
            } else if (itemId == R.id.nav_calendar) {
                startActivity(new Intent(getApplicationContext(), CalendarActivity.class));
                overridePendingTransition(R.anim.float_down_in, R.anim.float_up_out);
                finish();
                return true;
            }
            return false;
        });
    }
}