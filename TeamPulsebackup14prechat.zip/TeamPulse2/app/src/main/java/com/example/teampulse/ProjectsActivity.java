package com.example.teampulse;

import android.content.Intent;
import android.content.res.ColorStateList;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.example.teampulse.databinding.ActivityProjectsBinding;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.ListenerRegistration;
import com.google.firebase.firestore.QueryDocumentSnapshot;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ProjectsActivity extends AppCompatActivity implements OnProjectInteractionListener, NavigationDrawerFragment.NavigationListener, NavigationDrawerFragment.DrawerActivity {

    private ActivityProjectsBinding binding;
    private FirebaseFirestore db;
    private FirebaseAuth mAuth;
    private ProjectsAdapter adapter;
    private List<Project> projectList = new ArrayList<>();
    private Map<String, Project> projectMap = new HashMap<>();

    // Drawer components
    private DrawerLayout drawerLayout;
    private ActionBarDrawerToggle toggle;

    private ListenerRegistration userListener;
    private ListenerRegistration projectsListener;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityProjectsBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        db = FirebaseFirestore.getInstance();
        mAuth = FirebaseAuth.getInstance();

        setupViews();
        setupToolbarAndDrawer();
        setupRecyclerView();
        setupFab();
        setupBottomNavigation();
    }

    private void setupViews() {
        drawerLayout = findViewById(R.id.drawer_layout);
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadUserDataAndProjects();
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (userListener != null) userListener.remove();
        if (projectsListener != null) projectsListener.remove();
    }

    @Override
    public void onProjectDeleted() {
        // Listener automatically handles refresh
    }

    @Override
    public void onProjectPinChanged(String newPinnedId) {
        FirebaseUser currentUser = mAuth.getCurrentUser();
        if (currentUser == null) return;
        db.collection("users").document(currentUser.getUid())
                .update("pinnedProjectId", newPinnedId)
                .addOnSuccessListener(aVoid -> {
                    String message = newPinnedId == null ? "Project unpinned" : "Project pinned to dashboard";
                    Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
                })
                .addOnFailureListener(e -> Toast.makeText(this, "Failed to update pin.", Toast.LENGTH_SHORT).show());
    }

    private void setupToolbarAndDrawer() {
        setSupportActionBar(binding.toolbar);
        toggle = new ActionBarDrawerToggle(this, drawerLayout, binding.toolbar,
                R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawerLayout.addDrawerListener(toggle);
        toggle.syncState();

        // Host the NavigationDrawerFragment
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.drawer_fragment_container, new NavigationDrawerFragment())
                .commit();
    }


    private void logoutUser() {
        mAuth.signOut();
        startActivity(new Intent(this, SignInActivity.class).setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK));
        finish();
    }

    private void setupRecyclerView() {
        adapter = new ProjectsAdapter(this, projectList, this);
        binding.projectsRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        binding.projectsRecyclerView.setAdapter(adapter);
        binding.projectsRecyclerView.setItemAnimator(new androidx.recyclerview.widget.DefaultItemAnimator());
    }

    private void loadUserDataAndProjects() {
        FirebaseUser currentUser = mAuth.getCurrentUser();
        if (currentUser == null) {
            finish();
            return;
        }
        String currentUserId = currentUser.getUid();
        userListener = db.collection("users").document(currentUserId).addSnapshotListener((snapshot, e) -> {
            if (snapshot != null && snapshot.exists()) {
                String role = snapshot.getString("role");
                String pinnedId = snapshot.getString("pinnedProjectId");
                if (adapter != null) {
                    adapter.setPinnedProjectId(pinnedId);
                }
                binding.fabAddProject.setVisibility("Leader".equals(role) ? View.VISIBLE : View.GONE);
            }
        });
        loadAllProjects(currentUserId);
    }

    private void loadAllProjects(String currentUserId) {
        projectsListener = db.collection("projects")
                .whereArrayContains("teamMembers", currentUserId)
                .addSnapshotListener((snapshots, e) -> {
                    if (e != null) {
                        Toast.makeText(this, "Error fetching projects.", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    if (snapshots != null) {
                        projectMap.clear();
                        for (QueryDocumentSnapshot doc : snapshots) {
                            Project project = doc.toObject(Project.class);
                            project.setId(doc.getId());
                            projectMap.put(doc.getId(), project);
                        }
                        projectList.clear();
                        projectList.addAll(projectMap.values());
                        adapter.notifyDataSetChanged();
                    }
                });
    }

    private void setupFab() {
        binding.fabAddProject.setOnClickListener(v ->
                startActivity(new Intent(ProjectsActivity.this, CreateProjectActivity.class)));
    }

    private void setupBottomNavigation() {
        binding.bottomNavigation.setSelectedItemId(R.id.nav_projects);

        // Set custom colors for selected/unselected states
        int selectedColor = ContextCompat.getColor(this, R.color.text_primary);
        int unselectedColor = ContextCompat.getColor(this, R.color.text_secondary);
        binding.bottomNavigation.setItemIconTintList(createColorStateList(selectedColor, unselectedColor));
        binding.bottomNavigation.setItemTextColor(createColorStateList(selectedColor, unselectedColor));

        binding.bottomNavigation.setOnItemSelectedListener(item -> {
            int itemId = item.getItemId();
            if (itemId == R.id.nav_projects) {
                return true;
            } else if (itemId == R.id.nav_home) {
                navigateToDashboard();
                return true;
            } else if (itemId == R.id.nav_my_tasks) {
                startActivity(new Intent(getApplicationContext(), MyTasksActivity.class));
                overridePendingTransition(R.anim.float_up_in, R.anim.float_down_out);
                finish();
                return true;
            }else if (itemId == R.id.nav_calendar) {
                startActivity(new Intent(getApplicationContext(), CalendarActivity.class));
                overridePendingTransition(R.anim.float_up_in, R.anim.float_down_out);
                finish();
                return true;
            }
            return false;
        });
    }

    private ColorStateList createColorStateList(int selectedColor, int unselectedColor) {
        int[][] states = new int[][] {
            new int[] { android.R.attr.state_checked }, // selected
            new int[] { -android.R.attr.state_checked }  // unselected
        };
        int[] colors = new int[] {
            selectedColor,
            unselectedColor
        };
        return new ColorStateList(states, colors);
    }

    private void navigateToDashboard() {
        FirebaseUser user = mAuth.getCurrentUser();
        if (user != null) {
            db.collection("users").document(user.getUid()).get().addOnSuccessListener(doc -> {
                if (doc.exists()) {
                    Intent intent;
                    String role = doc.getString("role");
                    if ("Leader".equals(role) || "Member".equals(role)) {
                        intent = new Intent(getApplicationContext(), DashboardActivity.class);
                    } else {
                        intent = new Intent(getApplicationContext(), TeacherDashboardActivity.class);
                    }
                    startActivity(intent);
                    overridePendingTransition(R.anim.float_down_in, R.anim.float_up_out);
                    finish();
                }
            });
        }
    }

    @Override
    public void onLogout() {
        logoutUser();
    }

    @Override
    public void onProfile() {
        startActivity(new Intent(this, ProfileActivity.class));
    }

    @Override
    public void onActivityLog() {
        startActivity(new Intent(this, GlobalLogActivity.class));
    }

    @Override
    public void onSettings() {
        Toast.makeText(this, "Settings screen coming soon!", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void closeDrawer() {
        drawerLayout.closeDrawer(GravityCompat.START);
    }
}